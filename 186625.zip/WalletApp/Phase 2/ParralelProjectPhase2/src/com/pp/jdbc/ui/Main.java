package com.pp.jdbc.ui;

public class Main {
	
	public static void main(String[] args) {
		
		InputOutputClass ioObj=new InputOutputClass();
		
		ioObj.display();
		
		/* First create a table in Oracle with the statement below.
	   	 * create table bank_account(ACCOUNT_NUMBER NUMBER(10) NOT NULL,AMOUNT FLOAT(126) NOT NULL , NAME VARCHAR2(255), AGE NUMBER(3));     
		 * 
		 * Then create a table for Transactions using below snippet.
		 * create table bank_transaction(ACCOUNT_NUMBER NUMBER(10) NOT NULL ,CREDIT FLOAT(100), DEBIT FLOAT(100), AMOUNT FLOAT(126));
		 */
		
	}

}
