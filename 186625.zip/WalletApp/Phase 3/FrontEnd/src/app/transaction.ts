export class Transaction {
    accountNumber: number;
    transactionId: number;
    balance: number;
    credit: number;
    debit: number;
}