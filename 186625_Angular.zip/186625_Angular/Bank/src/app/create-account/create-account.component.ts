import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {

  customer: Customer;
  constructor(private customerService: CustomerService) {

  }

  createCustomer(name: string, gender:string,  balance: number,mobileNo:string): void {
    if (name && gender && balance && mobileNo) {
      this.customer = new Customer(name,gender, balance, mobileNo);
      this.customerService.createCustomer(this.customer)
        .subscribe();
        alert("Added");
    } else {
      alert('Please fill all details');
    }

  }
}
