export class Customer {

  name: string;
  gender: string;
 
  balance: number;
  mobileNo: string;
  constructor(name: string,  gender: string,  balance: number, mobileNo:string) {
    this.name = name;
    
    this.gender = gender;
    this.mobileNo= mobileNo;
    this.balance = balance;
  }

}