import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  customer: Customer;
  message: string;
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }
  depositAmount(AccountNumber: number, balance: number) {
    if (AccountNumber && balance) {
      this.customer = new Customer('', '', balance,'');
      this.customerService.depositAmount(AccountNumber, this.customer).subscribe(data => {
        this.message = 'Hello ' + data.name + ' '  + ', your Current Balance is ' + data.balance;
      }, (err) => alert('Enter valid Account No'));
    } else {
      alert('Enter Account Details!');
    }

  }

}
