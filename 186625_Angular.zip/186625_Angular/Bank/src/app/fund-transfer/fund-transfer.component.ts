import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  customer: Customer;
  message: string;
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }
  fundTransfer(senderAccountNo: number, recieverAccNo: number, balance: number) {
    if (senderAccountNo && recieverAccNo && balance) {
      this.customer = new Customer('', '', balance,'');
      this.customerService.fundTransfer(senderAccountNo, recieverAccNo, this.customer).subscribe();
      alert("Fund transfer succesfully");
    } else {
      alert('Enter Account Details!');
    }
  }

}
