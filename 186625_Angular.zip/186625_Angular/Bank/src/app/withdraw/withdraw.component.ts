import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  customer: Customer;
  message: string;
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }
  withdrawAmount(accountNumber: number, balance: number) {
    if (accountNumber && balance) {
      this.customer = new Customer('', '', balance,'');
      this.customerService.withdrawAmount(accountNumber, this.customer).subscribe(data => {
        this.message = 'Hello ' + data.name + ' ' +  ', your Remaining Available is ' + data.balance;
  }, (err) => alert('Enter valid Account Number'));
} else {
  alert('Enter Account Details!');
}

  }


}
