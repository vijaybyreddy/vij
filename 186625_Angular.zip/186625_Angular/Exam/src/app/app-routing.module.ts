import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './mobile/add.component';
import { ShowComponent } from './mobile/show.component';
import { SearchComponent } from './mobile/search.component';
import { ShowsearcheddataComponent } from './mobile/showsearcheddata.component';


const routes: Routes = [
  /**
   * setting the path
   */
  {path:"add",component:AddComponent},
  {path:"show", component:ShowComponent},
  {path:'', redirectTo:'show',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
