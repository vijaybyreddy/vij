import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import{ FormsModule } from '@angular/forms';
import { AddComponent } from './mobile/add.component';
import { ShowComponent } from './mobile/show.component';
import { SearchComponent } from './mobile/search.component';
import { ShowsearcheddataComponent } from './mobile/showsearcheddata.component';

@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
    ShowComponent,
    SearchComponent,
    ShowsearcheddataComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
