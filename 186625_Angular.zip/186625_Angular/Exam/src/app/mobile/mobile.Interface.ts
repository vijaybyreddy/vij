export interface IMobile{
    /**
     * declaration of parameters in interface class
     */
    id:number;
    name:string;
    price:number;
    brand:string;
}