import { Injectable } from '@angular/core';
import { IMobile } from './mobile.Interface';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MobileService {
  /**
   * @author:lmummidi
   * This is the service class
   */
  mobiles:IMobile[]=[];
  constructor() { }
  /**
   * getting all the Mobile details in getAllMobiles
   */
  getAllMobiles():IMobile[]{
    return this.mobiles;
  }
  /**
   * adding the Mobile Details into addMobile method using push
   * @param mobile 
   */
  addMobile(mobile:IMobile){
    this.mobiles.push(mobile);
  }
  /**
   * delete method to delete the row when clicking the delete button
   * @param id 
   */
  deleteMobile(id:number){
    this.mobiles.splice(id,1);
  }
}
