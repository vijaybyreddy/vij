import { Component, OnInit } from '@angular/core';
import { IMobile } from './mobile.Interface';
import { MobileService } from './mobile.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
mobiles:IMobile[];
  constructor(private mobileService:MobileService) { }

  ngOnInit() {
    this.mobiles=this.mobileService.getAllMobiles();
  }
  /**
   * This is the delete method to delete particular Mobile Details
   * @param id 
   */
  delete(id:number){ 
    this.mobileService.deleteMobile(id);
  }
  

}
