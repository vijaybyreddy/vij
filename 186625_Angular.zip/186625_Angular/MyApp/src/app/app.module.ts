import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentlistComponent } from './student/studentlist.component';
import { AddstudentComponent } from './student/addstudent.component';
import { StartPageComponent } from './student/start-page.component';
import{ FormsModule } from '@angular/forms';
import { SearchStudentComponent } from './student/search-student.component';
import { StudentService } from './student/student.service';
import { UpdateStudentComponent } from './student/update-student.component';
import { SortstudentComponent } from './student/sort-student.component';
@NgModule({
  declarations: [
    AppComponent,
    StudentlistComponent,
    AddstudentComponent,
    StartPageComponent,
    SearchStudentComponent,
    UpdateStudentComponent,
    SortstudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
