import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit {
//students:IStudent[];
  constructor() { }

  ngOnInit() {
  }
//update(data){
 // console.log(data);
 // this.students=this.studentService.getData();
  //console.log(this.students);
  //  this.students=this.students.filter(s=>s.name==data.name);
  // console.log(this.students);
  // this.students=this.studentService.getData();
  // console.log(this.students);
  //   this.studentService=set(this.students)
}
