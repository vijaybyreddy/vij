import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddStudentComponent } from './student/add-student.component';
import { StudentListComponent } from './student/student-list.component';
import { StudentComponent } from './student/student.component';


const routes: Routes = [
  {path:'',redirectTo:'student-list',pathMatch:'full'},
  {path:'add',component:AddStudentComponent},
  {path:'student-list',component:StudentListComponent},
  {path:'student',component:StudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
