import { Component, OnInit } from '@angular/core';
import { Student } from './student.interface';
import { StudentService } from './student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  studentData:Student={"id":0,"name":'',"gender":'',"age":0,"mobile":''};
  constructor(private studentService:StudentService,private router:Router) { }

  ngOnInit() {
  }
add(){
  console.log(this.studentData.name);
  this.studentService.addStudent(this.studentData).subscribe(
    (data)=>{this.router.navigate(['student-list']);}
    );
}

}
