package com.cg.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Account;
import com.cg.exception.ApplicationException;
import com.cg.dao.AccountDAO;


@Service
@Transactional
public class AccountService implements AccountOperation {

	
	@Autowired AccountDAO dao;
	
	public void withdraw(Long mobile, double amount)  {
		// TODO Auto-generated method stub
		
		Optional<Account> ob1=dao.findById(mobile);
		Account ob = ob1.get();
		double new_balance=ob.getBalance()-amount;
		if(new_balance<1000.0 || amount<0)
		{
			new_balance=ob.getBalance();
			
			throw new ApplicationException("Insufficient fund. Can not process withdrawal"+new_balance);
		}
		
		
		ob.setBalance(new_balance);
		dao.save(ob);
		
		
	}

	
	
	public void Deposit(Long mobile, double amount)  {
		Optional<Account> ob1=dao.findById(mobile);
		Account ob = ob1.get();
		double new_balance=ob.getBalance()+amount;
		if(amount<0)
			try {
				{
					
					new_balance=ob.getBalance();
					throw new ApplicationException("Invalid amount to be added"+amount);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		ob.setBalance(new_balance);
		dao.save(ob);
	}

	

	@Transactional
	public boolean addAccount(Account ob) {
		// TODO Auto-generated method stub
	   dao.save(ob);
	   return true;
	}

	@Transactional
	public boolean deleteAccount(Long mobile) {
		// TODO Auto-generated method stub
		dao.deleteById(mobile);
		return true;
	}

	@Transactional(readOnly=true)
	public List<Account> findAccount(Long mobileno) {
		// TODO Auto-generated method stub
		List<Account> account=dao.findBymobileno(mobileno);
		return account;
	}

	@Transactional(readOnly=true)
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Transactional
	public boolean updateAccount(Account ob)  {
		// TODO Auto-generated method stub
		Long mobile=ob.getMobileno();
		
	 dao.save(ob);
		return true;
	}

	@Transactional
	public void TransferMoney(Long from, Long to, double amount)  {
		// TODO Auto-generated method stub
		Optional<Account> ob1=dao.findById(from);
		Account fromob = ob1.get();
		Optional<Account> ob2=dao.findById(to);
		Account toob = ob2.get();
		
		if(amount>0)
		{
			
			
			
			fromob.setBalance(fromob.getBalance()-amount);
			dao.save(fromob);
		   toob.setBalance(toob.getBalance()+amount);
		   dao.save(toob);
		  
		}
		
		
	}



	@Transactional
	public void deleteAll() {
		dao.deleteAll();
	}

	
	

}
