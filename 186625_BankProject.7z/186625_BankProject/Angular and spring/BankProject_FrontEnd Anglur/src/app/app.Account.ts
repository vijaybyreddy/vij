export class Account {
  acc_number: number;
  mobile_no: string;
  acc_holder: string;
  acc_Balance: number;
}
