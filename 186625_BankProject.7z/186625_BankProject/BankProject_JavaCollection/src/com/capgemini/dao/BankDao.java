package com.capgemini.dao;

import com.capgemini.bean.BankBean;

public interface BankDao {

	public BankBean checkAccount(long accountNo);

	public void setData(long  accountNo, BankBean bean);
}
