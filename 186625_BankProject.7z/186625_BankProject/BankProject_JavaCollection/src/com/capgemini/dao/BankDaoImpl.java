package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.bean.BankBean;

public class BankDaoImpl implements BankDao {


	HashMap hashmap1;

	public  BankDaoImpl() {

		hashmap1 = new HashMap();
	}

	// bean class object

	BankBean bean = new BankBean();

	// to check account already exists or not

	public BankBean checkAccount(long accNo) {

		if (hashmap1.containsKey(accNo)) {

			bean = (BankBean) hashmap1.get(accNo);
			return bean;

		} else

			return null;
	}

	// to put the data into the map

	public void setData(long accNo, BankBean bean) {

		hashmap1.put(accNo, bean);
	}

}
