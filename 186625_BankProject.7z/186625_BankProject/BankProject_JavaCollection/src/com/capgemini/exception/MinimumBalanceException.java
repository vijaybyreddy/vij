package com.capgemini.exception;

public class MinimumBalanceException {
	@Override
	public String toString() {

		return "Minimum Balance should be 1000";
	}

	public MinimumBalanceException() {

	}
}

