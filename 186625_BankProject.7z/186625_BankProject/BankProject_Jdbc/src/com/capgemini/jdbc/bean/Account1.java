package com.capgemini.jdbc.bean;

public class Account1 {

	private long accountNo;
	private String name;
	private long mobile;
	private String gender;
	private long balance;




	public Account1() {
		super();
		
	}




	public Account1(long accountNo, String name, long mobile, String gender, long balance) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.mobile = mobile;
		this.gender = gender;
		this.balance = balance;
	}




	public long getAccountNo() {
		return accountNo;
	}




	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public long getMobile() {
		return mobile;
	}




	public void setMobile(long mobile) {
		this.mobile = mobile;
	}




	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	public long getBalance() {
		return balance;
	}




	public void setBalance(long balance) {
		this.balance = balance;
	}




	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", name=" + name + ", mobile=" + mobile + ", gender=" + gender
				+ ", balance=" + balance + "]";
	}

	
}
