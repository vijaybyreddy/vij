package com.capgemini.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;

import com.capgemini.jdbc.bean.Account1;
import com.capgemini.jdbc.bean.Transaction;
import com.capgemini.jdbc.exception.AccountException;
import com.capgemini.jdbc.utility.Dbconnection;

public class AccountDaoImpl implements IAccountDao {

	PreparedStatement statement = null;
	Connection connection = null;
	ResultSet resultSet = null;
	boolean status = false;
	int row = -1;
	long accountNo = 0;
	long balance=0;
	long bal=0;
	private Connection conn = null;

	@Override
	public long addAccount(Account1 account) {
		long accountno=0;
		try (Connection connection = Dbconnection.getConnection();) {
			statement = connection.prepareStatement("select accseq.NEXTVAL from dual");
			resultSet = statement.executeQuery();
			
			if (resultSet.next()) {
				accountno=resultSet.getLong(1);
			}
				statement = connection.prepareStatement("insert into account1 values(?,?,?,?,?)");
				statement.setLong(1, accountno);
				statement.setString(2, account.getName());
				statement.setLong(3, account.getMobile());
				statement.setString(4, account.getGender());
				statement.setLong(5, account.getBalance());
			
				
				 row=statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountno;
	}

	@Override
	public long deposit(long accountNo, long depositedAmount) {
		
		Connection connection = Dbconnection.getConnection();
	
		try {
			statement = connection.prepareStatement("select balance from Account1 where accountno=?");
			statement.setLong(1, accountNo);
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				 balance=rs.getLong(1);
				 System.out.println(balance);
				statement = connection.prepareStatement("update Account1 set balance=? where accountno=?");
				bal= balance+depositedAmount;
				statement.setLong(1, bal);
				statement.setLong(2, accountNo);
				statement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bal;
	}

	@Override
	public long withdrawl(long accountNo, long amountwithdrawl) {

		Connection connection = Dbconnection.getConnection();

		try {
			statement = connection.prepareStatement("select balance from Account1 where accountno=?");
			statement.setLong(1, accountNo);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()) {
				balance=rs.getLong(1);
				statement = connection.prepareStatement("update Account1 set balance=? where accountno=?");
				bal =balance- amountwithdrawl;
				statement.setLong(1, bal);
				statement.setLong(2, accountNo);
				statement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bal;
				
	}

	@Override
	public long getBalance(long accountNo) {

		Connection connection = Dbconnection.getConnection();
		long balance = 0;
		try {
			statement = connection.prepareStatement("select balance from Account1 where accountno=?");
			statement.setLong(1, accountNo);
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				balance = rs.getLong(1);
				//balance=rs.getDouble("amount");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;

	}

	@Override
	public long transaction(long senderAccountNo, long transferAmount) throws AccountException {
		long balance, balance1 = 0, balance2 = 0;
		Connection connection = Dbconnection.getConnection();
		ResultSet rs;
		int i;
		try {
			statement = connection.prepareStatement("select * from account1 where accountno=?");
			statement.setLong(1, senderAccountNo);

			rs = statement.executeQuery();
			while (rs.next()) {
				balance = rs.getLong(1);
				
					statement = conn.prepareStatement("update Account1 set balance=? where accountno=?");
					balance1 = balance-transferAmount;
					statement.setLong(1, balance1);
					statement.setLong(2, senderAccountNo);
					
						statement.executeUpdate();
		
}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance1;
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws AccountException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Transaction> printTransaction() throws AccountException {

		return null;

	}
	/*public ResultSet getAllTransactions(int accountNumber) {
		ResultSet rs=null;
		try {
			Connection con = getConnection();
			PreparedStatement stmt = con.prepareStatement("select * from bank_transaction where account_number=?");
			stmt.setInt(1, accountNumber);
			rs=stmt.executeQuery();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;*/
	}
