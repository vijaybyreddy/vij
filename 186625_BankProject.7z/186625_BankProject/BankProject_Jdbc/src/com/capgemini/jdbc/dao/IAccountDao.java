package com.capgemini.jdbc.dao;

import java.util.Set;

import com.capgemini.jdbc.bean.Account1;
import com.capgemini.jdbc.bean.Transaction;
import com.capgemini.jdbc.exception.AccountException;

public interface IAccountDao {

	public long deposit(long accountNumber, long depositedAmount);

	public long getBalance(long accountNo);

	public long addAccount( Account1 account);

	public long withdrawl(long accountNo, long amountwithdrawl);

	public long transaction(long senderAccountNo,  long transferAmount) throws AccountException;

	boolean addTransaction(Transaction transaction) throws AccountException;
	
	 public Set<Transaction> printTransaction() throws AccountException;
}
