package com.capgemini.jdbc.presentation;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.jdbc.bean.Account1;
import com.capgemini.jdbc.bean.Transaction;
import com.capgemini.jdbc.exception.AccountException;
import com.capgemini.jdbc.service.AccountServiceImpl;

public class MainClass {

	public static void main(String[] args) throws ParseException, AccountException {

		String continueChoice;
		boolean continueValue = false;
		Set<Transaction> set = new LinkedHashSet<>();

		Scanner scanner = null;
		do {

			System.out.println("*** welcome to Bank***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			//System.out.println("6.Print Transactions");
			System.out.println("6.exit");

			AccountServiceImpl service = new AccountServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;

			do {

				scanner = new Scanner(System.in);
				System.out.println("Enter input:");

				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean flag = false;

					// String recieverAccountNo="";
					long balance = 0;
					long bal = 0;
					long amountDeposited = 0;
					long transferAmount = 0;
					long accountNo = 0;
					long accountNo2 = 0;
					long amountWithdrawl = 0;
					long mobile = 0;
					// long balanceAfterDeposition=0;

					switch (choice) {
					case 1: {

						String name = "";

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name:");
							name = scanner.next();
							try {
								service.validateName(name);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number:");
							mobile = scanner.nextLong();
							try {
								service.validateNumber(mobile);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						String gender = "";

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Gender:");
							gender = scanner.next();
							if (gender.equals("male")) {
								gender = "Male";
								flag = true;
							} else if (gender.equals("female")) {
								gender = "Female";
								flag = true;
							} else {
								System.out.println(
										"gender should be in characters and it should be either male or female");
								flag = false;
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							balance = scanner.nextInt();
							try {
								service.validateAmount(balance);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						accountNo = service.generateId();
						System.out.println("account created with the given id: " + accountNo);
						Account1 account = new Account1(accountNo, name, mobile, gender, balance);
						service.addAccount(account);
					}
						break;

					case 2:

					{

						System.out.println("Enter account number for deposit:");
						accountNo = scanner.nextLong();
						System.out.println("Enter amount to be deposited:");
						scanner = new Scanner(System.in);
						amountDeposited = scanner.nextLong();
						LocalDate date = LocalDate.now();

						long balanceAfterDeposit = service.deposit(accountNo, amountDeposited);

						System.out.println("balance after deposit is:" + balanceAfterDeposit);

						/*
						 * int transacId = service.transacId();
						 * 
						 * Transaction transaction = new Transaction(transacId, "deposit", date,
						 * accountNo,balanceAfterDeposit);
						 */
					}
						break;
//					
					case 3: {
						
						System.out.println("Enter account number for withdrawl:");
						accountNo = scanner.nextLong();
						System.out.println("Enter amount to be withdrawn:");
						scanner = new Scanner(System.in);
						amountWithdrawl = scanner.nextInt();
						LocalDate date = LocalDate.now();
						double accBalance = service.getBalance(accountNo);
						System.out.println(accBalance);
						boolean result = service.validateBalance(accBalance, amountWithdrawl);
						if (!result)
							System.err.println("Insufficient balance");
						else {
							long balanceAfterWithdrawl = service.withdrawl(accountNo, amountWithdrawl);

							System.out.println("balance after withdrawl is:" + balanceAfterWithdrawl);
						} /*
							 * int transacId = service.transacId();
							 * 
							 * Transaction transaction = new Transaction(transacId, "withdrawl", date,
							 * accountNo, balanceAfterWithdrawl);
							 */
					}
						break;
//						
					case 4: {

						System.out.println("Enter your account number:");
						scanner = new Scanner(System.in);
						long senderAccountNo = scanner.nextLong();

						System.out.println("Enter reciever's account number:");
						scanner = new Scanner(System.in);
						long recieverAccountNo = scanner.nextLong();

						

						System.out.println("Enter amount to be transferred:");
						scanner = new Scanner(System.in);
						transferAmount = scanner.nextLong();
						long remain = service.transaction(senderAccountNo, transferAmount);
						System.out.println("transferred successfully and the remaining balance is " + remain);
					

					}
						break;
					
					case 5: {

						System.out.println("Enter your account number:");
						scanner = new Scanner(System.in);
						accountNo = scanner.nextLong();
						long balance2 = service.getBalance(accountNo);
						System.out.println("Your account balance is:" + balance2);
					}
						break;
				

					case 6:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;

					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;

					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}
}
