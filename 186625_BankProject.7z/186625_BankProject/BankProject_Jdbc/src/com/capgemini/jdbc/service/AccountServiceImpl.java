package com.capgemini.jdbc.service;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jdbc.bean.Account1;
import com.capgemini.jdbc.bean.Transaction;
import com.capgemini.jdbc.dao.AccountDaoImpl;
import com.capgemini.jdbc.dao.IAccountDao;
import com.capgemini.jdbc.exception.AccountException;

public class AccountServiceImpl implements IAccountService{

	IAccountDao accountdao=new AccountDaoImpl();
	boolean status=false;
	long row=-1;
	@Override
	public boolean validateName(String name) throws AccountException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new AccountException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean validateNumber(long mobile) throws AccountException {

		boolean resultFlag = false;
		String mobileNo = String.valueOf(mobile);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobileNo);
		if (match.matches()) {
			resultFlag = true;
		} else {
			throw new AccountException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
	}

	@Override
	public boolean validateAmount(double amount) throws AccountException {
		boolean amountFlag = false;

		if (amount < 500) {
			throw new AccountException("amount should be greater than 500");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	}
	@Override
	public boolean validateBalance(double balance,double requestAmount) throws AccountException {
		boolean amountFlag = false;
		

		if (balance-requestAmount <= 0) 
			return false;
		
		return true;
	}

	@Override
	public long generateId() throws AccountException {
		long accountNo = (long) (Math.random() * 100000000L);
		return accountNo;
	}

	@Override
	public int transacId() {
		int transactionId =(int) (Math.random() * 1000); 
	return transactionId;
	}

	@Override
	public long addAccount(Account1 account) {
		return accountdao.addAccount( account);

	}

	@Override
	public long deposit(long accountNumber, long depositedAmount) {
		
		return accountdao.deposit(accountNumber, depositedAmount);
	}

	@Override
	public long getBalance(long accountNo) {

		return accountdao.getBalance(accountNo);
	}

	@Override
	public long withdrawl(long accountNo, long amountwithdrawl) {
		return accountdao.withdrawl(accountNo,amountwithdrawl);
	}

	@Override
	public long transaction(long senderAccountNo, long transferAmount) throws AccountException {
		
		return accountdao.transaction(senderAccountNo, transferAmount);
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws AccountException {
			return	accountdao.addTransaction(transaction);
	}

	@Override
public Set<Transaction> printTransaction() throws AccountException {
		
		return accountdao.printTransaction();
	}


	

	


	


}
