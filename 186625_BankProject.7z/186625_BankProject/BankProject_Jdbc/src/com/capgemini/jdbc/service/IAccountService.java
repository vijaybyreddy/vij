package com.capgemini.jdbc.service;

import java.util.Set;

import com.capgemini.jdbc.bean.Account1;
import com.capgemini.jdbc.bean.Transaction;
import com.capgemini.jdbc.exception.AccountException;

public interface IAccountService {

	public boolean validateName(String name) throws AccountException;

	public boolean validateNumber(long mobile) throws AccountException;

	public boolean validateAmount(double accountNo) throws AccountException;

	public long generateId() throws AccountException;
	
	public int transacId();

	public long deposit(long accountNumber, long depositedAmount);

	public long getBalance(long accountNo);

	public long addAccount( Account1 account);

	public long withdrawl(long accountNo, long amountwithdrawl);

	public long transaction(long senderAccountNo, long transferAmount) throws AccountException;

	public boolean addTransaction(Transaction transaction) throws AccountException;

    public	Set<Transaction> printTransaction() throws AccountException;

	boolean validateBalance(double amount, double requestAmount) throws AccountException;



	
}


