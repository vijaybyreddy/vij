package com.cg.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
@RestController
@RequestMapping("/api")
public class EmployeeController {
	@Autowired
	private EmployeeService empService;
	@GetMapping("/employees")
	/* @requestmapping(/employees)*/
 public List<Employee> getAllEmployees() throws EmployeeException {
	return empService.getAllEmployees();
	
}
	@GetMapping("/employees/{id}")
	/*
	 * if names are diff this is the way
	 * @GETMAPPING("/EMPLOYEES/{empid}")
	 * public Employee getEmployeeById(@PathVariable ("empid") int id)
	 * */
	public Employee getEmployeeById(@PathVariable int id) throws EmployeeException {
		return empService.getEmployeeById(id);
		
	}
	/*
	 *@requestmapping(value="/addEmployees",method="RequestMethod.POST") or below thing we can write
	 * */
	@PostMapping("/addEmployees")
	public List<Employee> addEmployee(@RequestBody Employee employee) throws EmployeeException {
		return empService.addEmployee(employee);
		
		
	}
	@DeleteMapping("/employees/{id}")
	public List<Employee> deleteEmployee(@PathVariable int id) throws EmployeeException {
		return empService.deleteEmployee(id);
		
	}
	 @PutMapping("/employees/{id}")
	public List<Employee> updateEmployee(@RequestBody Employee employee,@PathVariable int id) throws EmployeeException{
		return empService.updateEmployee(id,employee);
	}
	 @ExceptionHandler(Exception.class)
	 public ResponseEntity<String> handleErrors(Exception ex) {
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
		
	}
	 @GetMapping("/employees/department")
	 public List<Employee> getEmployeeByDepartment(@RequestParam String deptName) throws EmployeeException {
		return empService.getEmployeeByDepartment(deptName);
		
	}
	 @PostMapping("/add")
	 public Employee add(@RequestBody Employee employee) throws EmployeeException {
		 return empService.add(employee);
	 }
}
