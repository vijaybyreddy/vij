package com.capgemini.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.bean.Order;

@Repository/*Repository Layer*/
public interface OrderDao extends JpaRepository<Order, Integer>{
	@Query("from Order order where order.quantity between :min and :max")
	List<Order> viewOrderRange(@Param("min")int min,@Param("max")int max);
	
	@Query("from Order order where order.amount > :amt")
	List<Order> viewOrderGreater(@Param("amt")double amt);
}
