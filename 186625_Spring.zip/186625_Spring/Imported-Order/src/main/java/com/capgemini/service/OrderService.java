package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Order;
import com.capgemini.exception.OrderException;

/*Service Layer*/
public interface OrderService {
	public List<Order> createOrder(Order order) throws OrderException;
	public List<Order> updateOrder(int id,Order order) throws OrderException;
	public List<Order> viewAllOrders() throws OrderException;
	public List<Order> viewOrderRange(int min, int max) throws OrderException;
	public List<Order> viewOrderGreater(double amount) throws OrderException;
}
