package com.capgemini.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.student.dto.Student;
import com.capgemini.student.expection.StudentException;
import com.capgemini.student.service.StudentService;


@RestController
@RequestMapping("/api")

public class StudentController {
	 @Autowired
	    private StudentService studservice;
	   
	    @PostMapping("/students")
	    public List<Student> addStudent(@RequestBody Student student) throws StudentException{
	        return studservice.addStudent(student);
	    }
	   
	    @PutMapping("/students/{id}")
	    public List<Student> updateStudent(@RequestBody Student student,@PathVariable int id) throws StudentException{
	        return studservice.updateStudent(id,student);
	    }
	   
	    @GetMapping("/students")
	    public List<Student> getAllStudents() throws StudentException{
	        return studservice.getAllStudents();
	    }
	   
	    @DeleteMapping("/students/{id}")
	    public List<Student> deleteStudent(@PathVariable int id) throws StudentException{
	            return studservice.deleteStudent(id);
	}
	   
	    @GetMapping("/students/{id}")
	    public Student getStudentById(@PathVariable int id) throws StudentException {
	        return studservice.getStudentById(id);
	    }
	   
	    @ExceptionHandler(Exception.class)
	    public ResponseEntity<String> handleErrors(Exception ex)  {
	        return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	    }
	   
	   
	    @GetMapping("/students/category")
	    public List<Student> getStudentByStream(@RequestParam String streamName) throws StudentException{
	        return studservice.getStudentByStream(streamName);
	    }
}
