package com.capgemini.student.expection;

public class StudentException extends Exception {

	public StudentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
