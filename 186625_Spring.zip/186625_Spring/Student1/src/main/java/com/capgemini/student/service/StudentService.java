package com.capgemini.student.service;

import java.util.List;

import com.capgemini.student.dto.Student;
import com.capgemini.student.expection.StudentException;



public interface StudentService {
	List<Student> getAllStudents() throws StudentException ;
	List<Student> addStudent(Student student) throws StudentException;
	List<Student> deleteStudent(int id) throws StudentException;
	List<Student> updateStudent(int id,Student student) throws StudentException;
	Student getStudentById(int id)throws StudentException;
	 List<Student> getStudentByStream(String streamName)throws StudentException;
}
