package com.capgemini.student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capgemini.student.dao.StudentRepository;
import com.capgemini.student.dto.Student;
import com.capgemini.student.expection.StudentException;


@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentRepository studentDao;
	@Override
	public List<Student> getAllStudents() throws StudentException {
		
		try {
			return studentDao.findAll();
		} catch (Exception e) {
			
			throw new StudentException(e.getMessage());
		}
	}

	@Override
	public List<Student> addStudent(Student student) throws StudentException {
		try {
            
            if(student.getStream().equals("CS")||student.getStream().equals("EC")||student.getStream().equals("MECH")) {
            studentDao.save(student);
            return getAllStudents();
            }
            else {
                throw new StudentException("stream should be either CS,EC OR MECH");
            }
        } catch (Exception e) {
            throw new StudentException(e.getMessage());
        }
	}

	@Override
	public List<Student> deleteStudent(int id) throws StudentException {
		  if(studentDao.existsById(id)) {
	            studentDao.deleteById(id);
	            return getAllStudents();
	    }
	        else {
	            throw new StudentException("Cannot delete. sTUDENT with id "+id+" does not exist");
	        }
	}

	@Override
	public List<Student> updateStudent(int id, Student student) throws StudentException {
		try {
			if(studentDao.existsById(student.getId())) {
				studentDao.save(student);
				return getAllStudents();
			}
			else {
				throw new StudentException("Invalid STUDENT cant be updated");
			}
		} catch (Exception e) {
			 
			 throw new StudentException(e.getMessage());
		}
	}

	@Override
	public Student getStudentById(int id) throws StudentException {
		 try {
	            Optional<Student> data=studentDao.findById(id);
	            if(data.isPresent()) {
	                return data.get();
	            }
	            else {
	                throw new StudentException("Product with id "+id+" does not exist");
	            }
	        } catch (Exception e ) {
	            throw new StudentException(e.getMessage());
	        }
	}

	@Override
	public List<Student> getStudentByStream(String streamName) throws StudentException {
		 return studentDao.getStudentByStream(streamName);
	}

 
}
 