import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:`<h1>Welcome</h1>`,
  //styles:['h1{color:blue}']
  styleUrls: ['./app.component.css']
 })
 export class AppComponent {
  title = 'Angular Application';
  fname:string="vijay";
  lname:string="Byreddy";
  myname:string;
  status:boolean=false;
 count:number=0;
  address:string;
  getFullName():string{
  this.myname=this.fname+this.lname;
  return this.myname;
 }
 getCount():number{
  return ++this.count;
 }
 }