import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeelistComponent } from './employee/employeelist/employeelist.component';
import { AddemployeeComponent } from './employee/addemployee/addemployee.component';
import { StartPageComponent } from './employee/start-page/start-page.component';
import { SearchemployeeComponent } from './employee/searchemployee/searchemployee.component';



const routes: Routes = [
  {path:"employees",component:EmployeelistComponent},
  {path:"add",component:AddemployeeComponent},
  {path:"search",component:SearchemployeeComponent},
  {path:'',component:StartPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
