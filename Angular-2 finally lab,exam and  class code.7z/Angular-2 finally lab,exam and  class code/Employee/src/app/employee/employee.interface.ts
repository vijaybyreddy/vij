export interface IEmployee{
    id:number;
    name:string;
    gender:string;
    age:number;
    mobile:string;
}