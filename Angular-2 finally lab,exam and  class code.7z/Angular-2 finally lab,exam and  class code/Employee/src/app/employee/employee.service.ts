import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IEmployee } from './employee.interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:IEmployee[];
 
  constructor(private http:HttpClient) {
    this.getEmployees().subscribe(data=>this.employees=data);
   }
  getEmployees():Observable<IEmployee[]>{
    return this.http.get<IEmployee[]>("../../assets/employees.json");
  }
  getData(){
    return this.employees;
  }
  addEmployee(employee:IEmployee){
     this.employees.push(employee);
    

  }
  setEmployees(employees:IEmployee[]){
    this.employees=employees;
  }
  deleteEmployee(id:number){
    this.employees=this.employees.filter(s=>s.id!=id);
  }
}

