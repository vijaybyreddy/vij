import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../employee.interface';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {

 employees: IEmployee[];
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
    if(!this.employeeService.getData()){
      this.employeeService.getEmployees().subscribe(data =>{this.employees=data;
    this.employeeService.setEmployees(this.employees);
    console.log(this.employees);
  });
}
  else {
    this.employees=this.employeeService.getData();
  }
}

  onClick(id:number){
    this.employeeService.deleteEmployee(id);
    this.employees=this.employeeService.getData();
  }
  }

