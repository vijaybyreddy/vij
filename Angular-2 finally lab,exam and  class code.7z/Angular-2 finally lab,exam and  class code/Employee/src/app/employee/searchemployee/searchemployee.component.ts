import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../employee.interface';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-searchemployee',
  templateUrl: './searchemployee.component.html',
  styleUrls: ['./searchemployee.component.css']
})
export class SearchemployeeComponent implements OnInit {

  employees:IEmployee[];
  constructor(private employeeService:EmployeeService){}

  ngOnInit() {
  }
  searchEmployee(data){
    console.log(data);
    this.employees= this.employeeService.getData();
    console.log(this.employees);
    this.employees=this.employees.filter(s=>s.name==data.name);
}
}
