import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:Employee[]=[
    {eid:1218,name:"Byreddy",salary:64654544.55,gender:"male"},
    {eid:215,name:"vijay",salary:64654544.55,gender:"male"},
    {eid:216,name:"Ram",salary:64654544.55,gender:"male"},
    {eid:217,name:"navya",salary:64654544.55,gender:"female"}
  ];
  constructor() { }
  getAllEmployees():Employee[]{
    return this.employees;
  }
  addEmployee(employee:Employee){
    this.employees.push(employee);
    return true;
  }
  deleteEmployee(i:number){
    this.employees.splice(i,1)

  }
}
