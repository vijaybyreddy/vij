import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductlistComponent } from './product/productlist/productlist.component';
import { SearchProductComponent } from './product/search-product/search-product.component';

//creating path for the methods implemented

const routes: Routes = [
  {path:'',component:SearchProductComponent},
  {path:"products",component:ProductlistComponent},
  {path:"search",component:SearchProductComponent}
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
