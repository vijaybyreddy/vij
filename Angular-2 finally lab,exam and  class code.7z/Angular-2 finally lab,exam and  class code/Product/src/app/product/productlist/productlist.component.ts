import { Component, OnInit } from '@angular/core';
import { IProduct } from '../product.interface';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  products: IProduct[];
  //creating service object
  constructor(private productService:ProductService) { }

  ngOnInit() {
    if(!this.productService.getData()){
      this.productService.getProducts().subscribe(data =>{this.products=data;
    this.productService.setProducts(this.products);
    console.log(this.products);
  });
}
  else {
    this.products=this.productService.getData();
  }

}
//implementation of delete button
onClick(name:string){
  this.productService.deleteProduct(name);
  this.products=this.productService.getData();
}
}

