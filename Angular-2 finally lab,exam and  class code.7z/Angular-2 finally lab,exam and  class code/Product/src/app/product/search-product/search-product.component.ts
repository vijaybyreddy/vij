import { Component, OnInit } from '@angular/core';
import { IProduct } from '../product.interface';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {
//initialization of products 
  products:IProduct[];
 constructor(private productService:ProductService) { }
 
 ngOnInit() {
 }
 //implementation of search method 
 searchProduct(data){
 console.log(data);
 this.products=this.productService.getData().filter(p=>p.name==data.name||p.category==data.name);
 console.log(this.products);
 }
}