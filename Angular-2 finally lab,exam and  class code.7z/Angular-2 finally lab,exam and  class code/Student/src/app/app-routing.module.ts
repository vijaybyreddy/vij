import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentlistComponent } from './student/studentlist/studentlist.component';
import { AddstudentComponent } from './student/addstudent/addstudent.component';
import { StartPageComponent } from './student/start-page/start-page.component';
import { SearchStudentComponent } from './student/search-student/search-student.component';


const routes: Routes = [
  {path:"students",component:StudentlistComponent},
  {path:"add",component:AddstudentComponent},
  {path:'',component:StartPageComponent},
  {path:"search",component:SearchStudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
