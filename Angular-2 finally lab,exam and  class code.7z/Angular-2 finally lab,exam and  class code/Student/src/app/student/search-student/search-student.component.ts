import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { IStudent } from '../student.interface';

@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
  students:IStudent[];
  constructor(private studentService:StudentService){}
  

  ngOnInit() {
  }
searchStudent(data){
  console.log(data);
  this.students= this.studentService.getData();
  console.log(this.students);
  this.students=this.students.filter(s=>s.name==data.name);
 }
}
