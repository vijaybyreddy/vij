import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './components/show/show.component';
import { SearchComponent } from './components/search/search.component';
import { ShowsearcheddataComponent } from './components/showsearcheddata/showsearcheddata.component';
import { AddComponent } from './components/add/add.component';



const routes: Routes = [
  { path:'add',component:AddComponent},
  { path:'show',component:ShowComponent},
  { path:'search',component:SearchComponent},
  { path:'showsearcheddata',component:ShowsearcheddataComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
