import { Component, OnInit } from '@angular/core';

import { ProductService } from 'src/app/service/product.service';
import { Product } from 'src/app/bean/product';
 
@Component({
 selector: 'app-search',
 templateUrl: './search.component.html',
 styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
 products:Product[];
 searchProduct:string='';
 searchedData:Product[];
 
 constructor(private service:ProductService) { }
 
 ngOnInit() {
 this.service.getAllProducts().subscribe(
 (data:Product[])=>{this.products=data;
 console.log("all"+this.products)}
 );
 }
 search(value:string){
 this.searchedData=this.products.filter(product=>product.name.toLowerCase().indexOf(value.toLowerCase())!==-1);
 this.service.setSearchedData(this.searchedData);
 }
 
}