
import { Component, OnInit } from'@angular/core';
import { Product } from'src/app/bean/product';
import { ProductService } from'src/app/service/product.service';
 
@Component({
 selector: 'app-showsearcheddata',
 templateUrl: './showsearcheddata.component.html',
 styleUrls: ['./showsearcheddata.component.css']
})
export class ShowsearcheddataComponent implements OnInit {
searchedData:Product[];
 
constructor(private service:ProductService) { }
 
ngOnInit() {
this.searchedData=this.service.getSearchedData();
}
}


