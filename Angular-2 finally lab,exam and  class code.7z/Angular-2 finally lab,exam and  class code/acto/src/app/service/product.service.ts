import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../bean/product';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url:string="http://localhost:3000/product";
  filtereddata: Product[];
  constructor(private http:HttpClient) { }
  getAllProducts() {
    return this.http.get<Product[]>(this.url);
  }
  addProduct(product:Product){
  return this.http.post(this.url,product);
  }
  getShowAllproducts()
  {
  return this.http.get<Product[]>(this.url);
  }
  deleteProduct(product:Product){
  return this.http.delete<Product[]>(this.url+"/"+product.id);
  }

setSearchedData(searchedData:Product[]){
  this.filtereddata = searchedData;
  }
  getSearchedData(){
  return this.filtereddata;
  }
  }
