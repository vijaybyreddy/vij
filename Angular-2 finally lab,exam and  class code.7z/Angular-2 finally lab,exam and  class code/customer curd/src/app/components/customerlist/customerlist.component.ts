import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/model/customer';
import { CustomerService } from 'src/app/service/customer.service';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
customers:Customer[];
  constructor(private customerService:CustomerService) { }

  ngOnInit() {
    this.customerService.getAllCustomers().subscribe((data:Customer[])=>{this.customers=data; console.log("all"+this.customers)});
  }
  deleteCustomer(customer:Customer){
    this.customerService.deleteCustomer(customer).subscribe(
      (data)=>{this.customers=this.customers.filter(c=>c!==customer)}
    );
  }
}
