package com.capgemini.BankApplication.service;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;

public interface BankService {

	boolean isNameValid(String uname);

	boolean isPasswordValid(String password);

	boolean isAddressValid(String address);

	boolean isMobileValid(String mobileNo);

	boolean isAadharValid(long aadhrCardNo);

	boolean addAccount(Account account);

	HashMap<Long, Account> getAccountDetails();

	HashMap<String, String> getUnamePassword();

	HashMap<Long, Long> ShowBalance();

	boolean addTransaction(Transaction tran);
	HashMap<Long, Transaction>getTransaction();

}
