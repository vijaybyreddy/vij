package com.cg.bean;

public class Account {
private long accountNo;
private String name;
private long mobile;
private long balance;
public Account() {
	super();
	// TODO Auto-generated constructor stub
}
public Account(long accountNo, String name, long mobile, long balance) {
	super();
	this.accountNo = accountNo;
	this.name = name;
	this.mobile = mobile;
	this.balance = balance;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public double getBalance() {
	return balance;
}
public void setBalance(long balance) {
	this.balance = balance;
}
@Override
public String toString() {
	return "Account [accountNo=" + accountNo + ", name=" + name + ", mobile=" + mobile + ", balance=" + balance + "]";
}
}