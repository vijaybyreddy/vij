package com.cg.bean;

import java.time.LocalDate;

public class Transaction {
long transId;
long fromAccountNo;
long ToAccountNo;
LocalDate date = LocalDate.now();
long money;

public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}
public Transaction(long transId, long fromAccountNo, long toAccountNo, LocalDate date, long money ) {
	super();
	this.transId = transId;
	this.fromAccountNo = fromAccountNo;
	ToAccountNo = toAccountNo;
	this.date = date;
	this.money = money;
	 
}
public long getTransId() {
	return transId;
}
public void setTransId(long transId) {
	this.transId = transId;
}
public long getFromAccountNo() {
	return fromAccountNo;
}
public void setFromAccountNo(long fromAccountNo) {
	this.fromAccountNo = fromAccountNo;
}
public long getToAccountNo() {
	return ToAccountNo;
}
public void setToAccountNo(long toAccountNo) {
	ToAccountNo = toAccountNo;
}
public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}
public long getMoney() {
	return money;
}
public void setMoney(long money) {
	this.money = money;
} 
@Override
public String toString() {
	return "Transaction [transId=" + transId + ", fromAccountNo=" + fromAccountNo + ", ToAccountNo=" + ToAccountNo
			+ ", date=" + date + ", money=" + money+"]";
} 
}