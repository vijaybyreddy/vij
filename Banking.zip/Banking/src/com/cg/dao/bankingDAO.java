package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Account;
import com.cg.bean.Transaction;

public interface bankingDAO {

	public long createAccount(Account account);

	HashMap<Long, Account> accountslist = new HashMap<>();
	HashMap<Long, Transaction> translist = new HashMap<>();
	HashMap<Long, Long> showbalance = new HashMap<>();

	public long createTransaction(Transaction transaction);

	HashMap<Long, Account> getDetails();

	HashMap<Long, Long> getBalance();

	HashMap<Long, Transaction> getTransaction();

}
