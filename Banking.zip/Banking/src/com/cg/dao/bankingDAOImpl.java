package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Account;
import com.cg.bean.Transaction;

public class bankingDAOImpl implements bankingDAO {

	@Override
	 
public long createAccount(Account account) {
		accountslist.put( account.getAccountNo(), account);
		return account.getAccountNo();
	}

	@Override
	public  long createTransaction(Transaction transaction) {
		translist.put( transaction.getTransId(), transaction);
		        		
		return transaction.getTransId();
	}

	@Override
	public HashMap<Long, Account> getDetails() {
		// TODO Auto-generated method stub
		return accountslist;
	}

	@Override
	public HashMap<Long, Long> getBalance() {
		
		return showbalance;
	}

	@Override
	public HashMap<Long, Transaction> getTransaction() {
	
		return translist;
	}
}