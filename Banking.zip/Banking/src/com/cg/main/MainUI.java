package com.cg.main;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.exception.BankingException;
import com.cg.service.bankingServiceImpl;
import com.cg.utility.Utilityclass;

public class MainUI {

	private static final Account account = null;
	private static boolean accountFlag;

	@SuppressWarnings("resource")
	public static void main(String[] args) throws BankingException {
		// TODO Auto-generated method stub
		String continueChoice;
		boolean continueValue = false;

	    Scanner scanner = null;
		do {

			System.out.println("*** welcome to Banking Application");
			System.out.println("1.Create account");
			System.out.println("2.Show balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Money Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.exit");

			bankingServiceImpl service = new bankingServiceImpl();
            Utilityclass obj = new Utilityclass();
            long accno = 0;
            long accountNo = 0;
            long money = 0;
            long bal =0;
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean NameFlag = false;

					String Name = "";
					switch (choice) {

					case 1:{
						String firstName = "";
						String middleName = "";
						String lastName = "";
						do {
							 
							scanner = new Scanner(System.in);
							System.out.println("Enter First name:");
							firstName = scanner.nextLine();
							try {
								service.validateName(firstName);
								NameFlag = true;
							} catch (BankingException e) {
								NameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!NameFlag);
						do {
							 
							scanner = new Scanner(System.in);
							System.out.println("Enter Middle name:");
							middleName = scanner.nextLine();
							try {
								service.validateName(middleName);
								NameFlag = true;
							} catch (BankingException e) {
								NameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!NameFlag);
						do {
							 
							scanner = new Scanner(System.in);
							System.out.println("Enter Last name:");
							lastName = scanner.nextLine();
							try {
								service.validateName(lastName);
								NameFlag = true;
							} catch (BankingException e) {
								NameFlag = false;
								System.err.println(e.getMessage());
								
							}
							try {
								Name = firstName.concat(middleName.concat(lastName));
								service.validateName(Name);
							} catch (BankingException e) {
								
								System.err.println(e.getMessage());
							}
							
						} while (!NameFlag);
					
						long mobile = 0;
						boolean phoneFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number:");
							try {
								mobile = scanner.nextLong();
								service.validatePhone(mobile);
								phoneFlag = true;
							} catch (InputMismatchException e) {
								phoneFlag = false;
								System.err.println("Phone number should be in digits");
							} catch (BankingException e) {
								phoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!phoneFlag);
						
						Account account = new Account(0,Name,mobile,bal);
						long accountNo1=  service.createAccount(account);
						System.out.println("Account generated for the customer and your account number is =>"+accountNo1);		
			 
					}
						break;

					case 2:{
						
					/*list1 = service.getBalance();*/
					System.out.println("Your account balance is:"+bal);
						
						
					}
						break;

					case 3:
					{
						System.out.println("Enter money:");
					scanner = new Scanner(System.in);
			         money = scanner.nextLong();
			         bal = bal + money;
			         LocalDate date = LocalDate.now();
			         accno = accountNo;
			 	     Transaction transaction = new Transaction(0,accountNo,accno,date,money);
			         long transId =  service.createTransaction(transaction);
			         System.out.println("Transaction processing and your transaction id is=>"+transId);
			         System.out.println("Your account is credited with "+money+"\nYour final balance is=>"+bal);
						}

						break;
					case 4: {
						System.out.println("Enter money:");
						scanner = new Scanner(System.in);
				         money = scanner.nextLong();
				         bal = bal-money;
				         LocalDate date = LocalDate.now();
				         accno = accountNo;
				         Transaction transaction = new Transaction(0,accountNo,accno,date,money);
				       long transId =  service.createTransaction(transaction);
				         System.out.println("Transaction processing and your transaction id is=>"+transId);
				         System.out.println("Your account is debited with "+money+"\nYour final balance is=>"+bal);
					}break;
					case 5:{
						System.out.println("Enter From account number ");
						scanner = new Scanner(System.in);
						long fan = scanner.nextLong();
						try {
							service.validateAccount(fan);
							accountFlag= true;
						} catch (BankingException e) {
							accountFlag = false;
							System.err.println(e.getMessage());
						}
						System.out.println("Enter To account number ");
						long tan = scanner.nextLong();
						try {
							service.validateAccount(tan);
							accountFlag= true;
						} catch (BankingException e) {
							accountFlag = false;
							System.err.println(e.getMessage());
						}while(!accountFlag);
							
						System.out.println("Enter money:");
				         money = scanner.nextLong();
				         LocalDate date = LocalDate.now();
				         Transaction transaction = new Transaction(0,accountNo,accno,date,money);
					     long transId =  service.createTransaction(transaction);
					      System.out.println("Transaction processing and your transaction id is=>"+transId);
					      System.out.println("Account:"+fan+  "is debited with "+money+ " Account:"+tan+" is credited with "+money+"\n your final balance is:");
						}break;
					case 6: {
						
					}break;
				case 7:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}



}


