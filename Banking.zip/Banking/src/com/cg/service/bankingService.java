package com.cg.service;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.exception.BankingException;

public interface bankingService {
	public long createAccount(Account account);

	public long createTransaction(Transaction transaction);

	HashMap<Long, Account> getdetails();

	HashMap<Long, Long> getBalance();

	HashMap<Long, Transaction> getTransaction();

	public boolean validateName(String Name) throws BankingException;

	public boolean validatePhone(long phone) throws BankingException;

	boolean validateAccount(long accountNo) throws BankingException;

}
