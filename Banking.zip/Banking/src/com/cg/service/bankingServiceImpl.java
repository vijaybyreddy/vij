package com.cg.service;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.dao.bankingDAO;
import com.cg.dao.bankingDAOImpl;
import com.cg.exception.BankingException;

public class bankingServiceImpl implements bankingService {
bankingDAO dao =new bankingDAOImpl();
	 

	@Override
	public  long createTransaction(Transaction transaction) {
		 long transId = (long)(Math.random()*1000000);
		 transaction.setTransId(transId);
		return dao.createTransaction(transaction);
	}
 

	public boolean validateName(String Name) throws BankingException {

		boolean nameFlag = false;
		String nameRegEx =  "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, Name)) {
			throw new BankingException("first letter should be capital");
		} else {
			nameFlag = true;
		}
		return nameFlag;
	}

	@Override
	public boolean validatePhone(long phone) throws BankingException {

		boolean phoneFlag = false;
		String mobile = String.valueOf(phone);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			return phoneFlag = true;
		}
		return phoneFlag;
	}

	@Override
	public boolean validateAccount(long accountNo) throws BankingException {
		boolean accountFlag = false;
		String accNo = String.valueOf(accountNo);
		Pattern nameptn = Pattern.compile("^[0-9]{9}$");
		Matcher match = nameptn.matcher(accNo);
		if (match.matches()) {
			return accountFlag = true;
		}
		return accountFlag;
	}

	@Override
	public long createAccount(Account account) {
		long accountNo = (long)(Math.random()*1000000000);
		account.setAccountNo(accountNo);
		return dao.createAccount(account);
	}
	@Override
	public HashMap<Long, Account> getdetails() {
		
		return  dao.getDetails();
	}
	@Override
	public HashMap<Long, Long> getBalance() {
		 
		return  dao.getBalance();
	}
	@Override
	public HashMap<Long, Transaction> getTransaction() {
		 
		return dao.getTransaction();
	}
}
