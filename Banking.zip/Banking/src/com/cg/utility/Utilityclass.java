package com.cg.utility;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Transaction;

public class Utilityclass {
public static String name = "";
 static LocalDate date =   LocalDate.now();
public static Map<Integer, Transaction> translist = new HashMap<>();
static {
translist.put(12,new Transaction(1456789,145678902,9876543,date,1000));
translist.put(14,new Transaction(1111111,22222222,5555555,date,500));
translist.put(18,new Transaction(99998,4444444,7777777,date,18000));
translist.put(20,new Transaction(00765,888888,77112777,date,28000));
}

public static Map<Integer, Transaction> getTranslist() {
	return translist;
}
public static void setTranslist(Map<Integer, Transaction> translist) {
	Utilityclass.translist = translist;
}
}
