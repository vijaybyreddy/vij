package com.capgemini.review.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.review.bean.Review;

public interface ReviewRepository extends JpaRepository<Review, Integer>{

}
