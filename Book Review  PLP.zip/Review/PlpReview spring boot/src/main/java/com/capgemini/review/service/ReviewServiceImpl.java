package com.capgemini.review.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.review.bean.Review;
import com.capgemini.review.dao.ReviewRepository;
import com.capgemini.review.exception.ReviewException;



@Service
public class ReviewServiceImpl implements ReviewService {

	
	@Autowired
	private ReviewRepository reviewDao;
	@Override
	public List<Review> getAllReviews() throws ReviewException {
		return reviewDao.findAll();
	}

	@Override
	public List<Review> addReview(Review review) throws ReviewException {
		reviewDao.save(review);
		return getAllReviews();
	}

	@Override
	public List<Review> deleteReview(int Id) throws ReviewException {
		reviewDao.deleteById(Id);
		return getAllReviews();
	}

	@Override
	public List<Review> editReview(int Id, Review review) throws ReviewException {
		try {
			if(reviewDao.existsById(Id)) {
				Review review1=reviewDao.findById(Id).get();
				review1.setHeadline(review.getHeadline());
				reviewDao.save(review1);
				return getAllReviews();
				}else {
					throw new ReviewException("Id doesnt exist");
				}
		} catch (Exception e) {
			throw new ReviewException(e.getMessage());
		}
	}

	@Override
	public Review getReviewById(int Id) throws ReviewException {
		 
			try {
			Optional<Review> data=reviewDao.findById(Id);
			if(data.isPresent()) {
				return data.get();
			}
			else {
				throw new ReviewException("Review with id "+Id+" does not exist");
			}
		} catch (Exception e ) {
			throw new ReviewException(e.getMessage());
		
		
			}
		}



}
