import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditComponent } from './review/edit/edit.component';

import { WelcomeComponent } from './review/welcome/welcome.component';
import { ReviewlistingpageComponent } from './review/reviewlistingpage/reviewlistingpage.component';




const routes: Routes = [
  {path:'review/edit/:id',component:EditComponent},
  { path: '',component:WelcomeComponent},
  { path: 'review',component:ReviewlistingpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  
})
export class AppRoutingModule { }
