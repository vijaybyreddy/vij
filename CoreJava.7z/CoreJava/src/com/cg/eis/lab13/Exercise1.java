package com.cg.eis.lab13;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Exercise1 {
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	BiFunction<Integer, Integer, Double> bifun = (x, y) -> Math.pow(x, y);
	System.out.println("Enter base : ");
	int base  = scanner.nextInt();
	System.out.println("Enter power : ");
	int power  = scanner.nextInt();
	System.out.println(base + " to the power " +power +" is "+ bifun.apply(base, power));
	scanner.close();
}
}
