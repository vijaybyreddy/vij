package com.cg.eis.lab13;

import java.util.Scanner;
import java.util.function.Function;

public class Exercise2 {
public static void main(String[] args) {
	Function<String, String> fun1 = (input)-> {
		String output = "";
		for(int i=0;i<input.length();i++) {
			output = output + input.charAt(i)+" ";
		}
		return output;
	};
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter a string : ");
	String input = scanner.nextLine();
	System.out.println("Required output is : " + fun1.apply(input));
	scanner.close();
}
}
