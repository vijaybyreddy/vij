package com.cg.eis.lab13;

import java.util.Scanner;
import java.util.function.Function;

public class Exercise3 {
public static void main(String[] args) {
	Function<String,Boolean> fun1 = (password)-> {
	return password.equals("password");
	};
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter a password : ");
	String input = scanner.nextLine();
	System.out.println("Required output is : " + fun1.apply(input));
	scanner.close();
}
}
