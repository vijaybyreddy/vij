package com.cg.eis.lab13;

import java.util.function.Consumer;
import java.util.function.Supplier;

interface Say {
	void sayMsg();
}


public class Exercise4 {

		static void sayHi() {
			System.out.println("Welcome message from static method");
		}
		void bye() {
			System.out.println("Thank you");
		}
public static void main(String[] args) {
	Supplier<Exercise4> p1 = Exercise4::new;
	Say say = Exercise4::sayHi;
	say.sayMsg();
	Consumer<String> consumer = System.out::println;
	consumer.accept("Consumer prints hi");
}
}
