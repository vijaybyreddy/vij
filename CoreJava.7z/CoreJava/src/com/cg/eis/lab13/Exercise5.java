package com.cg.eis.lab13;

import java.util.Scanner;
import java.util.function.Supplier;

interface Factorial {
	void printFactorial(int input);
}


public class Exercise5  {
	static void printFactorial(int input) {
		int factorial = 1;
		for(int i=1;i<=input;i++) {
			factorial = factorial*i;
		}
		System.out.println("Factorial is : "+factorial);
	}
public static void main(String[] args) {
//	Supplier<Exercise5> p1 = Exercise5::new;
	System.out.println("Enter a value to calculate factorial");
	Scanner scanner = new Scanner(System.in);
	int input = scanner.nextInt();
	Factorial factorial = Exercise5::printFactorial;
	factorial.printFactorial(input);
}
}
