package com.cg.eis.lab13;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;



public class TempEx {
public static void main(String[] args) {
	Map<String, String> empl = new HashMap<>();
	empl.put("Harish", "Capgemini");
	empl.put("Parakh", "Capgemini");
	empl.put("Nikhil", "Tcs");
	empl.put("Dev", "Capgemini");
	empl.put("ABhishek", "Capgemini");
	empl.put("Poonam", "Capgemini");
	List<String> orgcap = new ArrayList<>();
	/*for (Map.Entry<String, String> entry : empl.entrySet()) {
	    if(entry.getValue().equals("Capgemini")) {
	    	orgcap.add(entry.getKey());
	    }
		//System.out.println(entry.getKey() + " = " + entry.getValue());
	}*/
	Set<String> set = empl.keySet();
	Iterator<String> iterator = set.iterator();
	while (iterator.hasNext()) {
		String string =  iterator.next();
		String orgname= empl.get(string);
		if(orgname.equals("Capgemini")) {
			orgcap.add(string);
		}
		
	}
	System.out.println(orgcap);	
	}
	
}

