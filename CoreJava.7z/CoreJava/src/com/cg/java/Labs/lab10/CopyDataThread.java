package com.cg.java.lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread {
	public CopyDataThread(String input) {
		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;

		try {

			fileInputStream = new FileInputStream(input);
			fileOutputStream = new FileOutputStream(
					"C:\\CoreJavaSpace\\CoreJava\\src\\com\\cg\\java\\lab10\\target.txt");

			int i = 0;
			while (i != -1) {
				i = fileInputStream.read();
				fileOutputStream.write(i);

				if (i % 10 == 0) {
					System.out.println("10 characters are copied");
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}

		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void run() {
		super.run();
	}
}
