package com.cg.java.lab10;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Exercise2 implements Runnable {

	@Override
	public void run() {
		
		for (int i = 0; i < 80; i++) {
			Calendar cal = Calendar. getInstance();
			Date date=cal. getTime();
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			String formattedDate=dateFormat. format(date);
			System.out.println(formattedDate);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	public static void main(String[] args) {
		Exercise2 runnable = new Exercise2();
		Thread runnableThread = new Thread(runnable);
		runnableThread.start();
	}

}
