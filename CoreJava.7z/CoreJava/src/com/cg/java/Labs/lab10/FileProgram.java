package com.cg.java.lab10;

public class FileProgram extends CopyDataThread {
public FileProgram(String input) {
		super(input);
		
	}

public static void main(String[] args) {
	FileProgram fileProgram = new FileProgram("C:\\CoreJavaSpace\\CoreJava\\src\\com\\cg\\java\\lab10\\source.txt");
	fileProgram.run();
}
}
