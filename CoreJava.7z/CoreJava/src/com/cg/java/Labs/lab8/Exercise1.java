package com.cg.java.lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Exercise1 {
	public static void main(String[] args) {
		int sum = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a string of integer separated by space : ");
		String input = scanner.nextLine();
		StringTokenizer tokens = new StringTokenizer(input);

		System.out.print("Sum of ");
		while (tokens.hasMoreTokens()) {
			int temp = Integer.parseInt(tokens.nextToken().toString());
			sum = sum + temp;
			System.out.print(temp + " ");

		}
		System.out.print(" is " + sum);
		scanner.close();
	}
}
