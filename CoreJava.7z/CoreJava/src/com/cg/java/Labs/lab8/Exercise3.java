package com.cg.java.lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Exercise3 {
	public static void main(String[] args) {
		FileInputStream fileInputStream = null;
		try {

			fileInputStream = new FileInputStream("src/com/cg/java/lab8/Exercise1.java");
			int lines = 1;
			int words = 1;
			int chars = 0;
			System.out.print("Line no : " + lines);
			while (chars != -1) {
				chars = fileInputStream.read();
				if (chars == '\n') {
					lines++;
				}
				if (chars == ' ') {
					words++;
				}
			}
			System.out.println("No of lines : " + lines);
			System.out.println("No of words : " + words);
			System.out.println("No of characters : " + lines);

		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
