package com.cg.java.lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Exercise4 {
	private static String getFileExtension(File file) {
		String extension = "";

		try {
			if (file != null && file.exists()) {
				String name = file.getName();
				extension = name.substring(name.lastIndexOf("."));
			}
		} catch (Exception e) {
			extension = "";
		}

		return extension;

	}

	public static void main(String[] args) {
		File file = null;

		System.out.println("Enter file path: ");
		Scanner scanner = new Scanner(System.in);
		String fileName = scanner.nextLine();
		file = new File(fileName);
		String extension = getFileExtension(file);
		if (file.exists()) {
			System.out.println("This file exists");
			System.out.println("This file is readable : " + file.canRead());
			System.out.println("This file is writable : " + file.canWrite());
			System.out.println("This file is executable : " + file.canExecute());
			System.out.println("This file size in bytes is : " + fileName.length());
			System.out.println("This file type is : " + extension);
		}
		scanner.close();

	}
}
