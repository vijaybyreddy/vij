package com.cg.java.lab8;

import java.util.Scanner;

public class Exercise5 {
public static void main(String[] args) {
	System.out.println("Enter a string :");
	Scanner scanner = new Scanner(System.in);
	String input = scanner.nextLine();
	int i=0;
	boolean flag = true;
	while (i<(input.length()-1)) {
		if(input.charAt(i)<input.charAt(i+1))
		{
			i++;
		}
		else {
			flag = false;
			System.out.println("This is not a positive string");
			break;
		}
	}
	if(flag) {
		System.out.println("This is a positive string");
	}
}
}
