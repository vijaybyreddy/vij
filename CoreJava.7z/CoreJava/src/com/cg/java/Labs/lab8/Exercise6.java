package com.cg.java.lab8;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Exercise6 {

	public void duration(String inputDate) {
		Date currentDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		String date = format.format(currentDate);
		System.out.println(date);
		int firstIndex1 = date.indexOf('/');
		int firstIndex2 = inputDate.indexOf('/');
		int lastIndex1 = date.lastIndexOf('/');
		int lastIndex2 = inputDate.lastIndexOf('/');
		int date1 = Integer.parseInt(date.substring(0, firstIndex1));
		int date2 = Integer.parseInt(inputDate.substring(0, firstIndex2));
		int days = Math.abs(date1 - date2);
		int month1 = Integer.parseInt(date.substring(firstIndex1 + 1, lastIndex1));
		int month2 = Integer.parseInt(inputDate.substring(firstIndex2 + 1, lastIndex2));
		int month = Math.abs(month1 - month2);
		int year1 = Integer.parseInt(date.substring(lastIndex1 + 1, lastIndex1 + 5));
		System.out.println(year1);
		int year2 = Integer.parseInt(inputDate.substring(lastIndex2 + 1, lastIndex2 + 5));
		System.out.println(year2);
		int years = Math.abs(year1 - year2);
		System.out.println("Days : " + days + "\n Months : " + month + "\n Years : " + years);
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the date in dd/mm/yyyy");
		String date = scanner.nextLine();
		Exercise6 exercise6 = new Exercise6();
		exercise6.duration(date);
		scanner.close();
	}
}