package com.cg.java.lab8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Exercise7 {

	public static void main(String[] args) {
		System.out.println("Enter a string to valdate : ");
		Scanner scanner = new Scanner(System.in);
		String name = scanner.nextLine();
		
		int substrIndex = name.lastIndexOf("_");
		String lastPart = name.substring(substrIndex,name.length());
		String firstPart = name.substring(0, substrIndex);
		Pattern nameptn = Pattern.compile("^[A-Za-z]{8,}$");
		Matcher match = nameptn.matcher(firstPart);
		if (match.matches()) {
		
			System.out.println("This is a valid string");
		}
		else 
			System.out.println("This is not a valid string");

	}

}
