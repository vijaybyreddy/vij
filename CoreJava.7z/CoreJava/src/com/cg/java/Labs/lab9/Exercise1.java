package com.cg.java.lab9;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Exercise1 {

	public static List<String> getValues(HashMap<Integer, String> hashMap){
		
		return new ArrayList<>(hashMap.values());
	}

public static void main(String[] args) {
	HashMap<Integer,String> hashMap = new HashMap<>();
	hashMap.put(10, "Ankush");
	hashMap.put(11, "Ankit");
	hashMap.put(12, "Anand");
	hashMap.put(13, "Faisal");
	hashMap.put(14, "Shubham");
	hashMap.put(15, "Shivam");
	List<String> outList = Exercise1.getValues(hashMap);
	Collections.sort(outList);
	System.out.println(outList);
	
}
}
