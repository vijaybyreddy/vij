package com.cg.java.lab9;

import java.util.HashMap;
import java.util.Scanner;

public class Exercise2 {
	public static HashMap<Character, Integer> countCharacter(char[] inputChar) {
		HashMap<Character, Integer> hash = new HashMap<>();
		for (int i = 0; i < inputChar.length; i++) {
			if (hash.containsKey(inputChar[i])) {
				hash.put(inputChar[i], (hash.get(inputChar[i])+1));
			}
			
			else{
				hash.put(inputChar[i], 1);
			}
		}
		return hash;
	}

	public static void main(String[] args) {
		System.out.println("Enter a string : ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		char[] inputChar = input.toCharArray();
		System.out.println(Exercise2.countCharacter(inputChar));
		scanner.close();
	}
}
