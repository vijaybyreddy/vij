package com.cg.java.lab9;

import java.util.HashMap;
import java.util.Scanner;

public class Exercise3 {
	public static HashMap<Integer, Integer> getSquares(int[] inputInt) {
		HashMap<Integer, Integer> hash = new HashMap<>();
		for (int i = 0; i < inputInt.length; i++) {
			hash.put(inputInt[i], (inputInt[i] * inputInt[i]));
		}
		return hash;
	}

	public static void main(String[] args) {
		System.out.println("Enter a Integers : ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		String inputStrings[] = input.split(" ");
		int[] inputInt = new int[inputStrings.length];
		for (int i = 0; i < inputInt.length; i++) {
			inputInt[i] = Integer.parseInt(inputStrings[i]);
		}
		System.out.println(Exercise3.getSquares(inputInt));
		scanner.close();
	}
}
