package com.cg.java.customexception;

import java.util.Scanner;

/*class MyException extends Exception 
{ 
    public MyException(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
} 
*/  
// A Class that uses above MyException 
public class Main 
{ 
    // Driver Program 
    public static void main(String args[]) 
    {
    	Scanner scanner = new Scanner(System.in);
    	//String input = scanner.nextLine();
//    	scanner.nextLine();
    	try
        {  
    		System.out.println("Enter First Name");
        	String first = scanner.nextLine();
        	if(first.equals(""))
        	{
            throw new MyException("Please enter a valid First Name"); 
        	}
        	System.out.println("Enter Last Name");
        	String last = scanner.nextLine();
            
        	
        	if(last.equals(""))
        	{
            throw new MyException("Please enter a valid Last Name"); 
        	}
        } 
        catch (MyException ex) 
        { 
           // System.out.println("Caught"); 
  
            // Print the message from MyException object 
            System.out.println(ex.getMessage()); 
        } 
    } 
} 
