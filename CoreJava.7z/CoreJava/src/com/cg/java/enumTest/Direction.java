package com.cg.java.enumTest;

public enum Direction {
	SOUTH,NORTH,EAST,WEST;
	void m1() {
		System.out.println("m1 called..");

}
}
