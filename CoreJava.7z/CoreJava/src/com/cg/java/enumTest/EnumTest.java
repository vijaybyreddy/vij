package com.cg.java.enumTest;

enum Directitons{
	SOUTH,NORTH,EAST,WEST;
	void m1() {
		System.out.println("m1 called..");
	}
}

public class EnumTest {
public static void main(String[] args) {
	
	Directitons directitons = Directitons.EAST;
	System.out.println(directitons.name());
	directitons.m1();
	
}
	
	
}
