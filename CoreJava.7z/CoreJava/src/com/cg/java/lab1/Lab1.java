package com.cg.java.lab1;

import java.util.Scanner;

class Exercise1{
	
	public int calculateSum(int n){
		int sum=0;
		for(int i=0;i<=n;i++) {
			if(i%3==0 || i%5==0) {
				sum=sum+i;
						
			}
		}
		
		return sum;
	}
	
}


class Exercise2{
	//solution for exercise 2
	public int calculateDifference(int n) {
		int diff=0,sumsqn=0,sumn=0;
		for(int i=0;i<=n;i++) {
			sumn=sumn+i;
			sumsqn=sumsqn+i*i;
		}
		sumn=sumn*sumn;
		diff = sumsqn-sumn;
		
		return diff;
	}
	
}


class Exercise3{
	//solution of exercise 3
	public boolean checkNumber(int n) {
		boolean ans = true;
		int temp1 = n%10;
		n=n/10;
		while(n>0) {
			int temp2 = n%10;
			n=n/10;
			if(temp1<temp2) {
				ans=false;
				break;
			}
			else {
				temp1=temp2;
				temp2=n%10;
				n=n/10;
			}
		}
		
		return ans;
	}
	
}


class Exercise4{
	//solution of exercise 4
	public boolean checkNumber(int n) {
		boolean result = true;
		while(n>0) {
			
			if(n%2==0) {
				n=n/2;
				continue;
			}
			if(n>2 && n%2!=0) {
				result=false;
				break;
			}
			
		}
		return result;
		
	}
}

public class Lab1 {
	
	public static void main(String[] args) {
				
		//taking input via scanner class
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter input");
		int input = scanner.nextInt();
		
		//implementing solution of exercise1
		Exercise1 exercise1= new Exercise1();
		int resultex1 = exercise1.calculateSum(input);
		System.out.println("Exercise1 answer = "+resultex1);
		
		//implementing solution of exercise2
		Exercise2 exercise2= new Exercise2();
		int resultex2 = exercise2.calculateDifference(input);
		System.out.println("Exercise2 answer = "+resultex2);
		
		//implementing solution of exercise2
				Exercise3 exercise3= new Exercise3();
				boolean resultex3 = exercise3.checkNumber(input);
				System.out.println("Exercise3 answer = "+resultex3);
		
				//implementing solution of exercise4
				Exercise4 exercise4= new Exercise4();
				boolean resultex4 = exercise4.checkNumber(input);
				System.out.println("Exercise4"
						+ " answer = "+resultex4);
	}
	
}
