package com.cg.java.lab2;

public class Book extends WrittenItem{
	
	
}
