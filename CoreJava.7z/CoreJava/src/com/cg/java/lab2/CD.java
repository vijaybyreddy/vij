package com.cg.java.lab2;

public class CD extends MediaItem {

}
