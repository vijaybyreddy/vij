package com.cg.java.lab2;

abstract class Item{
	private int id;
	private String title;
	private int noOfCopies;
	
	//setters and getters for id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	//setters and getters for title
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	//setters and getters for no of copies
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
	
	//abstract methods
	public void print() {
	}
	public void equals() {
	}
	public void checkIn() {
	}
	public void checkOut() {
	}
	public void addItem() {
	}
	public String toString(int s) {
		String input=null;
		return input;
	}
	//setters and getters for Author
}


