package com.cg.java.lab2;

public class JournalPaper extends WrittenItem {

	private int yearPublished;
	
}
