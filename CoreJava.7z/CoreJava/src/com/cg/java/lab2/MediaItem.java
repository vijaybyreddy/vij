package com.cg.java.lab2;

public class MediaItem extends Item {
	
	private int runtime;

	//setters and getters for runtime
	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	
}
