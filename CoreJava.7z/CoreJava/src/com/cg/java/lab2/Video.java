package com.cg.java.lab2;

public class Video extends MediaItem {

	

}
