package com.cg.java.lab2;
import com.cg.java.lab2.Item;
abstract class WrittenItem extends Item {
	private String author;
	
	//setters and getters for Author
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	
	public void print() {
		System.out.println("Author Name" + author);
	}
	
	
	
}
