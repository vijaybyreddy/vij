package com.cg.java.lab3;

import java.util.Scanner;

public class ClassTask {
	public int findEven(int n) {
		int result = 0, temp = 0;
		while (n > 0) {
			temp = n % 10;
			n = n / 10;
			if (temp % 2 == 0) {
				result = result + 1;
			}
		}
		return result;
	}

	public int findDiv3(int n) {
		int result = 0, temp = 0;
		while (n > 0) {
			temp = n % 10;
			n = n / 10;
			if (temp % 3 == 0) {
				result = result + 1;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Input number");
		int input = scanner.nextInt();
		ClassTask exercise3 = new ClassTask();
		System.out.println("No. of divisibe by 2 is : " + exercise3.findEven(input));
		System.out.println("No. of divisibe by 3 is : " + exercise3.findDiv3(input));
	}
}
