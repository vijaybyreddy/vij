package com.cg.java.lab3;

import java.util.Scanner;

public class ClassTask2 {

	public int[] getReverse(int[] arr) {
		int[] result = null;
		for (int i = 0; i < arr.length; i++) {
			int temp = 0;
			while (arr[i] > 0) {
				temp = temp * 10 + arr[i] % 10;
				arr[i] = arr[i] / 10;
			}
			arr[i] = temp;
		}
		return arr;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter size of array");
		int size = scanner.nextInt();
		int[] input = new int[size];
		System.out.println("Now enter elements of array");
		for (int i = 0; i < size; i++) {
			input[i] = scanner.nextInt();
		}

		ClassTask2 classTask2 = new ClassTask2();
		int result[] = classTask2.getReverse(input);
		System.out.println("Reversed elements are: ");
		for (int i = 0; i < size; i++) {
			System.out.println(result[i]);
		}
	}
}
