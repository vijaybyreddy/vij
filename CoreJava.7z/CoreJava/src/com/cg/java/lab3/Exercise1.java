package com.cg.java.lab3;

import java.util.Scanner;

public class Exercise1 {

	public static int calculateDifference(int[] arr) {
		int result = 0, first = 0, second = 0;
		if (arr.length < 2) {
			// with only one element second largest is not possible
			System.out.println("Invalid Input");
		}

		// iterating over an array of elements

		for (int i = 0; i < arr.length; i++) {
			// check for first largest element
			if (arr[i] > first) {
				second = first;
				first = arr[i];
			}
			// check if second largest is greater than itself and less than largest
			if (arr[i] > second && arr[i] != first) {
				second = arr[i];
			}
		}
		if (second == 0) {
			System.out.println("There exist no second largest element");
		} else {
			System.out.println("The second largest element is " + second);
		}
		return result;
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter size of array");
		int size = scanner.nextInt();
		int[] input = new int[size];
		System.out.println("Now enter elements of array");
		for (int i = 0; i < size; i++) {
			input[i] = scanner.nextInt();
		}
		int result = calculateDifference(input);

	}

}
