package com.cg.java.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter size of String array");
		int size = scanner.nextInt();
		System.out.println("Now enter string array from next line");
		scanner.nextLine();
		int lhalf = 0;
		String[] input = new String[size];
		for (int i = 0; i < size; i++) {
			input[i] = scanner.nextLine();
		}

		for (int i = 0; i < size; i++) {

			for (int j = 0; j < input.length; j++) {
				if (input[i].compareToIgnoreCase(input[j]) < 0) {
					String temp = input[i];
					input[i] = input[j];
					input[j] = temp;

				}
			}
		}

		if (size % 2 == 0) {
			lhalf = size / 2;
		} else {
			lhalf = size / 2 + 1;
		}

		for (int i = 0; i < lhalf; i++) {
			input[i] = input[i].toUpperCase();
		}
		for (int i = lhalf; i < size; i++) {
			input[i] = input[i].toLowerCase();
		}
		/*
		 * for (int i = 0; i < input.length; i++) { char[] temp1=
		 * input[i].toCharArray(); Arrays.sort(temp1); input[i]=temp1.toString();
		 * System.out.println(input[i]); }
		 */
		for (int i = 0; i < size; i++) {
			System.out.println("The resulting array is : " + input[i]);
		}

	}

}
