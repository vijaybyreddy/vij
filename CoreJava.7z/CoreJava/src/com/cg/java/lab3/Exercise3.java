package com.cg.java.lab3;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Exercise3 {
	public int[] getSorted(int[] arr) {
		int[] result = null;
		for (int i = 0; i < arr.length; i++) {
			String string = Integer.toString(arr[i]);
			StringBuffer buffer = new StringBuffer(string);
			buffer = buffer.reverse();
			String str = String.valueOf(buffer);
			arr[i] = Integer.parseInt(str);

		}
		return arr;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter size of array : ");
		int size = scanner.nextInt();
		int[] input = new int[size];
		System.out.println("Enter " + size + " elements in an array");
		for (int i = 0; i < size; i++) {
			input[i] = scanner.nextInt();
		}
		Exercise3 exercise3 = new Exercise3();
		int[] result = exercise3.getSorted(input);
		Arrays.sort(result);
		System.out.println("The reversed and sorted elemnts or arrays :");
		for (int i = 0; i < size; i++) {
			System.out.println(result[i]);
		}

	}

}
