package com.cg.java.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a string");
		String input = scanner.nextLine();
		// System.out.println(input);

		char[] arr = input.toCharArray();
		// char[] sortedarr = new char[input.length()];
		// char c = 'a';
		int j = 0;
		int count = 1;
		Arrays.sort(arr);
		System.out.println(arr);
		for (int i = 0; i < (arr.length + 1); i++) {
			if (i == arr.length)
				if (arr[i] == arr[i + 1]) {
					count++;
				} else if ((i + 2 ) == arr.length) {
					System.out.println(arr[i + 1] + " : " + count);
				} else {
					System.out.println(arr[i] + " : " + count);
					count = 1;
				}
		}
	}

	/*
	 * for (int i = 0; i < arr.length; i++) {
	 * 
	 * System.out.println(arr[i]+ " : "+ visited[i]+" : "+ freq[i]); }
	 */

	/*
	 * for (int i = 0; i < arr.length; i++) { if (freq[i] > 0) {
	 * System.out.println("The frequency of element " + arr[i] + " : is" + freq[i]);
	 * } }
	 */

}