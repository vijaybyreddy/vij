package com.cg.java.lab4;

import java.util.Scanner;

public class Exercise1 {

	public int getCubeSum(int n) {
		int sum = 0;
		while (n > 0) {
			int temp = n % 10;
			n = n / 10;
			sum = sum + temp * temp * temp;
		}
		return sum;

	}

	public static void main(String[] args) {
		int result;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter digit : " + "\n");
		int input = scanner.nextInt();

		Exercise1 exercise1 = new Exercise1();
		result = exercise1.getCubeSum(input);

		System.out.println("Sum is : " + result);

	}

}
