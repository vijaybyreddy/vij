package com.cg.java.lab5;

import java.util.Scanner;

public class Exercise3 {
static int i=1;
public int recFib(int n) {
if(n<=1) {
return 1;
}
return recFib(n-1)+recFib(n-2);
}
public int nonrecFib(int n) {
int sum =0,first=1,second = 1;
for (int i = 0; i < (n-1); i++) {
sum = first + second;
first = second;
second = sum;
}

return sum;
}
public static void main(String[] args) {
System.out.println("Enter the position of fibonacci number");
Scanner scanner = new Scanner(System.in);
int input = scanner.nextInt();
input=input-1;
Exercise2 exercise2 = new Exercise2();
System.out.println("Using recursion = "+exercise2.recFib(input));
System.out.println("Without recursion = "+ exercise2.nonrecFib(input));
}
}
