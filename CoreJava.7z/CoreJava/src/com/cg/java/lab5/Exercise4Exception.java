package com.cg.java.lab5;

class Exercise4Exception extends Exception
{ 
    public Exercise4Exception(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
}