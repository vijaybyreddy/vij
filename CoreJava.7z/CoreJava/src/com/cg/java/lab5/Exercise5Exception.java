package com.cg.java.lab5;

public class Exercise5Exception extends Exception {
	public Exercise5Exception(String s) {
		super(s);
	}
}
