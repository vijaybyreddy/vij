package test;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Program10 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number");
		String input = scanner.nextLine();
		System.out.println("Enter a number to search");
		String match = scanner.nextLine();
		char toMatch = match.charAt(0);
		char[] inputChars = input.toCharArray();
		int frequency = 0;
		for (int i = 0; i < inputChars.length; i++) {
			if(toMatch == inputChars[i]) {
				frequency++;
			}
		}
		System.out.println("The occurence of given number is : " + frequency);
	}
}
