package test;

import java.util.Scanner;

public class Program2 {
public static void main(String[] args) {

}
}
