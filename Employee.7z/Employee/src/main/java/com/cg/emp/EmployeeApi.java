package com.cg.emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApi {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeApi.class, args);
	}

}
