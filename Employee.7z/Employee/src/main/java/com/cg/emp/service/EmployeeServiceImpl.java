package com.cg.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.dto.Employee;
import com.cg.emp.excp.EmployeeException;
/**
 * @author lchandak
 *
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
private EmployeeRepository employeedao;
//	
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		 
		  try {
	            return employeedao.findAll();
	        } catch (Exception e) {
	            throw new EmployeeException(e.getMessage());
	        }
	    }
	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		 
		try {
			Optional<Employee> data = employeedao.findById(id);
					if(data.isPresent()) {
						return data.get() ;
					}else {
						 throw new EmployeeException("Employee with id"+id+"doesnot exist");
					}
			 
		} catch (Exception e) {
			 
			 throw new EmployeeException(e.getMessage());
		}
	}
	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		 try {
			 if(employee.getAge()>55) {
				 throw new EmployeeException("Age should not exceed 55");
			 }
			 if(employee.getDepartment().equals("IT")|| employee.getDepartment().equals("SALES")
					 ||employee.getDepartment().equals("HR")) {
				  
			 
			employeedao.save(employee);
			return getAllEmployees();
		} 
			 else{
				 throw new EmployeeException("Dept should be it or sales or hr");
			 }}
				  catch (Exception e) {
			 
			 
			 throw new EmployeeException(e.getMessage());
		}
	}
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(employeedao.existsById(id))
				{
			employeedao.deleteById(id);
			return getAllEmployees();
		}
		else {
			throw new EmployeeException("cannot delete employee with id "+id+" doesnot exist");
		}
		 
	}
	@Override
	public List<Employee> updateEmployee(int id,Employee employee) throws EmployeeException {
		if(employeedao.existsById(employee.getId())) {
			employeedao.save(employee);
			return getAllEmployees();
		}else {
			throw new EmployeeException("Invalid employee cant be updated");
		}
		 
	}
	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {
		 
		return employeedao.getEmployeeByDepartment(deptName);
	}

	 

	}