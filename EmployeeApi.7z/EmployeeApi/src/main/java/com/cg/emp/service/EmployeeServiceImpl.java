package com.cg.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
/**
 * 
 * @author mankurap
 *Date Of creation :21-08-2019
 *Class Employee Service Implementation
 *Description
 */
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
private EmployeeRepository empDao;
	/**
	 * Author:
	 * Date:
	 * MethodName:
	 * Parameters:
	 * Return value:List of employees
	 * purpose: To Retrieve all employees from the database
	 * 
	 */

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		try {
			return empDao.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
	
		try {
			Optional<Employee> data= empDao.findById(id);
			if(data.isPresent())
			{
				return data.get();
			}
			else {
				throw new EmployeeException("Employee with Id "+id+"does not exist");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		try {
			if(employee.getAge()>55) {
				throw new EmployeeException("Age cant be greater than 55");
			}
			if(employee.getDepartment().equals("IT")||employee.getDepartment().equals("Sales")||employee.getDepartment().equals("HR")) {
			empDao.save(employee);
			
			return getAllEmployees();
			}
			else {
				throw new EmployeeException("Department should be HR,Sales or IT");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(empDao.existsById(id))
		{
			empDao.deleteById(id);
			return getAllEmployees();
		}
		else {
			throw new EmployeeException("Cannot delete EmployeeId");
		}
		
	}

	@Override
	public List<Employee> updateEmployee(int id,Employee employee) throws EmployeeException {
		if(empDao.existsById(id))
		{
			empDao.save(employee);
			return getAllEmployees();
		}
		else {
			throw new EmployeeException("Cannot find EmployeeId");
			
		}
	
	}

	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {
		

return empDao.getEmployeeByDepartment(deptName);
	}

	@Override
	public Employee add(Employee employee) throws EmployeeException {
	try {
		if(employee.getAge()>55) {
			throw new EmployeeException("Age cant be greater than 55");
		}
		if(employee.getDepartment().equals("IT")||employee.getDepartment().equals("Sales")||employee.getDepartment().equals("HR")) {
		Employee emp=empDao.save(employee);
			return emp;
		}
		else {
			throw new EmployeeException("Department should be HR,Sales or IT");
		}
	} catch (Exception e) {
		throw new EmployeeException(e.getMessage());
	}
	}

}
