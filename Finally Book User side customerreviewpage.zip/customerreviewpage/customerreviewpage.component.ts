import { Component, OnInit } from '@angular/core';
import { Review } from '../bean/review';
import { ReviewService } from '../service/review.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customerreviewpage',
  templateUrl: './customerreviewpage.component.html',
  styleUrls: ['./customerreviewpage.component.css']
})
export class CustomerreviewpageComponent implements OnInit {

  review:Review[];
  reviewData:Review={"index":0,"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''}
  constructor(private reviewService:ReviewService, 
  private router:Router,private route:ActivatedRoute){ }
  
  ngOnInit() {
    this.route.params.subscribe(
    (params)=>{this.reviewService.getReview(params['id'])
    .subscribe((result)=>{this.reviewData=result;})}
    );
    }
    
    edit(){
    console.log(this.reviewData.id);
    this.reviewService.editReview(this.reviewData).subscribe(
    (data)=>{this.router.navigate(['']);}
    );}}