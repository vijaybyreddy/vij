import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategorylistComponent } from './category/categorylist.component';
import { AddCategoryComponent } from './category/add-category.component';
import { EditCategoryComponent } from './category/edit-category.component';
import { WelcomeComponent } from './category/welcome.component';


const routes: Routes = [
  {path: '', component: WelcomeComponent},
  {path:"category",component:WelcomeComponent},
  {path:"add",component:AddCategoryComponent},
  {path:"update/:id",component:EditCategoryComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
