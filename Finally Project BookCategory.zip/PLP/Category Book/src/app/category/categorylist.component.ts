import { Component, OnInit } from '@angular/core';
import { CategoryService } from './category.service';
import { Category } from './category.interface';

@Component({
  selector: 'app-categorylist',
  templateUrl: './categorylist.component.html',
  styleUrls: ['./categorylist.component.css']
})
export class CategorylistComponent implements OnInit {
categories:Category[];
categoryData:Category={"id":0,"categoryName":''}
  constructor(private categoryService:CategoryService) { }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe((data:Category[])=>{this.categories=data; console.log("all"+this.categories)});
  }
  deleteCategory(category:Category){
    alert("Are you sure you want to delete the category with id "+category.id);
    this.categoryService.deleteCategory(category).subscribe((data)=>{this.categories=this.categories.filter(c=>c!==category)});
  }

}
//this.categoryData.id