package com.capgemini.exception;

/*Exception class*/
public class OrderException extends Exception {
	public OrderException()
	{
		super();
	}
	public OrderException(String msg)
	{
		super(msg);
	}
}
