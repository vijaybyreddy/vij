package com.capgemini.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.Order;
import com.capgemini.dao.OrderDao;
import com.capgemini.exception.OrderException;

@Service/*Service Layer*/
public class OrderServiceImpl implements OrderService {
	@Autowired/*AutoWiring dao Layer*/
	OrderDao dao;
	
	/*
	 * Method Name	:	createOrder
	 * Arguments	:	Order
	 * Return Type	:	List<Order>
	 * Description	:	Returns a list of database after invoking
	 * 					the dao layer to create an entry
	 * */
	@Override
	public List<Order> createOrder(Order order) throws OrderException {
		// TODO Auto-generated method stub
		try {
			order=generatefields(order);
			dao.save(order);
			return dao.findAll();
		}
		catch(Exception e) {
			throw new OrderException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	updateOrder
	 * Arguments	:	Integer, Order
	 * Return Type	:	List<Order>
	 * Description	:	Updates the entry in the given id with the object
	 * */
	@Override
	public List<Order> updateOrder(int id,Order order) throws OrderException {
		// TODO Auto-generated method stub
		try {
			Optional<Order> optional = dao.findById(id);
			order=generatefields(order);
			if(optional.isPresent())
			{
				Order o=new Order();
				o.setId(id);
				o.setQuantity(order.getQuantity());
				o.setPrice(order.getPrice());
				o.setAmount(order.getAmount());
				o.setCharges(order.getCharges());
				dao.save(o);
				return dao.findAll();
			}
			else
			{
				throw new OrderException("Order with Id="+id+" does not exist");	
			}
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	viewAllOrders
	 * Return Type	:	List<Order>
	 * Description	:	Returns list of the objects after invoking dao layer
	 * */
	@Override
	public List<Order> viewAllOrders() throws OrderException {
		// TODO Auto-generated method stub
		try
		{
			return dao.findAll();
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	viewOrderRange
	 * Arguments	:	Integers
	 * Return Type	:	List<Order>
	 * Description	:	Returns list of orders between the given range
	 * 					by invoking the dao layer
	 * */
	@Override
	public List<Order> viewOrderRange(int min, int max) throws OrderException {
		// TODO Auto-generated method stub
		try {
			return dao.viewOrderRange(min, max);
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	viewOrderGreater
	 * Arguments	:	Double
	 * Return Type	:	List<Order>
	 * Description	:	Return the list of orders with amount greater than
	 * 					the given amount
	 * */
	@Override
	public List<Order> viewOrderGreater(double amount) throws OrderException {
		// TODO Auto-generated method stub
		try {
			return dao.viewOrderGreater(amount);
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	generatefields
	 * Arguments	:	Order
	 * Return Type	:	Order
	 * Description	:	Generates the amount and charges
	 * */
	public Order generatefields(Order order)
	{
		int quantity=order.getQuantity();
		double price=order.getPrice();
		double amount=quantity*price*75;
		double charges=(amount*(1.25))/100;
		order.setAmount(amount);
		order.setCharges(charges);
		return order;
	}

}
