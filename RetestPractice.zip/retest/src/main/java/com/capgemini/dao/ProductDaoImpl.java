package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.capgemini.bean.Product;
import com.capgemini.repository.ProductRepository;



public class ProductDaoImpl implements IProductDAO{
	boolean status=false;

	static Map<Integer, Product> map = ProductRepository.getAllProducts();
	@Override
	public List<Product> getAllProducts() {
		
		Collection<Product> collection=map.values();
		
		List<Product> productlist=new ArrayList<>();
		
		productlist.addAll(collection);
		
		Collections.sort(productlist);
		
		return productlist;
		
	}

	public int addProduct(Product product) {
		double randomNumber = Math.random() * 1000;

		int generatedId = (int) randomNumber;
		product.setId(generatedId);

		map.put(generatedId, product);

		return generatedId;
		
	}

	public boolean deleteCustomer(int productId) {
		
		Product product = map.remove(productId);
		if(map.get(productId)!=null)
		{
			
			System.out.println(map);
			status=true;
		}
		else {
			
			status=false;
		}
		    return status;
	}
		
	}


