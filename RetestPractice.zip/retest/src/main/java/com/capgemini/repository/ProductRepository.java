package com.capgemini.repository;

import java.util.HashMap;

import com.capgemini.bean.Product;

public class ProductRepository {
	
	
	public static HashMap<Integer,Product> map=new HashMap<>();
		
		public static HashMap<Integer,Product> getAllProducts(){
			map.put(44, new Product(44,5,"Nokia",98989,123456789L));
			map.put(33, new Product(33,4,"Samsung",44545,987654321L));
			map.put(22, new Product(22,3,"Micromax",50000,456789123L));
			map.put(55, new Product(55,2,"Xiomi",58566,234789654L));
			map.put(11, new Product(11,1,"Apple",200000,127834986L));
			return map;
		}

	}



