package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Product;
import com.capgemini.dao.ProductDaoImpl;



public class ProductServiceImpl implements IProductService{
     
	ProductDaoImpl dao=new ProductDaoImpl();
	
	public int addProduct(Product product)  {
		 
		
		return dao.addProduct(product);
	}
	
	
	
	
	
	
	
	
	
	@Override
	public List<Product> getAllProducts() {
		
		return dao.getAllProducts();
	}









	public boolean delete(int productId) {
		
			boolean status=dao.deleteCustomer(productId);
			if(status=true) {
				
				status=true;
			}
			
			
			return status;
		}
		
	}









	


