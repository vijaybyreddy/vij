package com.capgemini.ui;

import java.awt.DisplayMode;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.Product;

import com.capgemini.service.ProductServiceImpl;
import com.capgemini.utility.SortByName;
import com.capgemini.utility.SortByNumber;
import com.capgemini.utility.SortByPrice;
import com.capgemini.utility.SortBySequence;



public class MainUI {
      
	public static void main(String[] args) {
		
		
		Scanner scanner=new Scanner(System.in);
        ProductServiceImpl service=new ProductServiceImpl();
		
		List<Product> productlist=service.getAllProducts();
		for(Product product: productlist) {
			System.out.println(product);
		}
	
		boolean deleteFlag=false;
		boolean choiceFlag=false;
		boolean sequenceFlag=false;
		int choice=0;
		int sequence=0;
	do {
		do {
		System.out.println("1.Add Product\n2.Delete product\n3.Display Product\n4.Exit");
		try {
		 choice=scanner.nextInt();
		 choiceFlag=true;
		 if(choice>5) {
			 System.out.println("please enter choice less than 4");
			 choiceFlag=false;
		 }else {
			 System.out.println("proceed.....");
			 choiceFlag=true;
		 }
		}catch(InputMismatchException e) {
			System.err.println("Only Integers are permitted....");
			choiceFlag=false;
			scanner.nextLine();
		}}while(!choiceFlag);
		switch(choice) {
		case 1:{do {
			System.out.println("Enter Sequence Number");
			
			
			try {
				sequence = scanner.nextInt();
				sequenceFlag=true;
			} catch (InputMismatchException e) {
				
			System.err.println("Only numbers are permitted.....");
			sequenceFlag=false;
			scanner.nextLine();
			}
			}while(!sequenceFlag);
			System.out.println("Enter the Name of Product");
			String name=scanner.next();
			System.out.println("Enter Price of Product");
			double price=scanner.nextDouble();
			System.out.println("Enter ISBN Number");
			long isbn=scanner.nextLong();
			Product product=new Product(0,sequence,name,price,isbn);
			int productId=service.addProduct(product);
			System.out.println("product added successfully with product id:"+productId);
			
		} break;
		case 2:{
			do {
			System.out.println("Enter Product Id to delete");
			int productId=scanner.nextInt();
			boolean status=service.delete(productId);
			if(status=true) {
				System.out.println( productId+ "  Deleted Successfully......");
				deleteFlag=true;
			}else {
				System.out.println("Id not available...");
				
			}
				
		}while(!deleteFlag);
		}break;
		case 3:{
		
			System.out.println("Enter Option \n1.SortByName \n2.SortByPrice \n3.SortByNumber \n4.SortBySequence");
		    int option=scanner.nextInt();
		    switch(option) {
		
		
		
		case 1:{
			List<Product> productlistbyname=service.getAllProducts();
			Collections.sort(productlistbyname, new SortByName());
			display(productlistbyname);
		}
		break;
		case 2:{
		
			List<Product> productlistbyprice=service.getAllProducts();
			Collections.sort(productlistbyprice, new SortByPrice());
			display(productlistbyprice);
		}
		break;
		case 3:{
			List<Product> productlistbyNumber=service.getAllProducts();
			Collections.sort(productlistbyNumber, new SortByNumber());
			display(productlistbyNumber);
		}break;
		case 4:{
			List<Product> productlistbySequence=service.getAllProducts();
			Collections.sort(productlistbySequence, new SortBySequence());
			display(productlistbySequence);
		}break;
		    }
		
		}break;
		case 4:{
			System.out.println("Thanks for visiting......");
			System.exit(0);
		}

		
	}
	}while(true);
	}
	
	static void display(List<Product> productlist) {
		for(Product product: productlist) {
			System.out.println(product);
		
	
	}
	}
	}


	

	


