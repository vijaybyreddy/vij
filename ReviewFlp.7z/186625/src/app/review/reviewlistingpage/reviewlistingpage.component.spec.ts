import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewlistingpageComponent } from './reviewlistingpage.component';

describe('ReviewlistingpageComponent', () => {
  let component: ReviewlistingpageComponent;
  let fixture: ComponentFixture<ReviewlistingpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewlistingpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewlistingpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
