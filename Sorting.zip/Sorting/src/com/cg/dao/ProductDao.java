package com.cg.dao;

import java.util.List;

import com.cg.bean.Product;

public interface ProductDao {
	public List<Product>getAllProducts();

	public Product viewById(int custId);

}
