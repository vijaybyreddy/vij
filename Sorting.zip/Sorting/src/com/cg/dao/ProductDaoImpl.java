package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.cg.bean.Product;
import com.cg.repository.ProductRepository;

public class ProductDaoImpl implements ProductDao {
	Map<Integer, Product> map=ProductRepository.getAllProducts();

	@Override
	public List<Product> getAllProducts() {
		HashMap<Integer, Product> map=ProductRepository.getAllProducts();
		Collection<Product> collections=map.values();
		List<Product> productlist=new ArrayList<>();
		productlist.addAll(collections);
		Collections.sort(productlist);
		return productlist;
	}

	@Override
	public Product viewById(int custId) {
		Product view=map.get(custId);
		return view;
	}
	

}
