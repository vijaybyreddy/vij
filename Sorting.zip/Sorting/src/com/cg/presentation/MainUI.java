package com.cg.presentation;

import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.utility.SortByName;
import com.cg.utility.SortByPid;
import com.cg.utility.SortByPrice;

public class MainUI {

	public static void main(String[] args) {
		ProductDao dao=new ProductDaoImpl();
		Scanner scanner = null;
		int choice = 0;
		boolean optionFlag = false;
		boolean choiceFlag = false;
		try {
			do {
				scanner = new Scanner(System.in);
				List<Product> productlist = dao.getAllProducts();
				for (Product product : productlist) {
					System.out.println(product);
				}
				System.out.println("Enter Choice 1.SortByName2.SortByPrice3.SortByPid4.Delete5.Exit");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					List<Product> productlistbyname = dao.getAllProducts();
					Collections.sort(productlistbyname, new SortByName());
					display(productlistbyname);
					break;
				case 2:
					List<Product> productlistbyprice = dao.getAllProducts();
					Collections.sort(productlistbyprice, new SortByPrice());
					display(productlistbyprice);
					break;
				case 3:
					List<Product> productlistbypid = dao.getAllProducts();
					Collections.sort(productlistbypid, new SortByPid());
					display(productlistbypid);
					break;
				case 4:{
					System.out.println("Enter customer id to delete");
				      int custId=scanner.nextInt();
				      Product c=dao.viewById(custId);
				      System.out.println(c);
					
				}					
					break;	
				case 5:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;
				default:
					System.err.println("Enter 1, or 4 only");
					break;	
				}
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!");
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Enter only digits");
		}
	}
	static void display(List<Product>productlist) {
		for(Product product : productlist) {
			System.out.println(product);
		}
	}

}
