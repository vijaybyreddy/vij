package com.cg.repository;

import java.util.HashMap;

import com.cg.bean.Product;

public class ProductRepository {
	public static HashMap<Integer, Product> map=new HashMap<>();
	public static HashMap<Integer, Product> getAllProducts() {
		map.put(44, new Product(44,"laptop",98989));
		map.put(33, new Product(33,"computer",44545));
		map.put(22, new Product(22,"toy car",50000));
		map.put(55, new Product(55,"ball",585));
		map.put(77, new Product(77,"apple",200));
		return map;
		
	}

}
