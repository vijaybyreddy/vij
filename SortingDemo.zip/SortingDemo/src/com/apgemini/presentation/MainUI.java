package com.apgemini.presentation;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.Product;
import com.capgemini.dao.ProductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.utility.SortByName;
import com.capgemini.utility.SortByPrice;

public class MainUI {

	public static void main(String[] args) {
		String continueChoice;
		Scanner scanner = new Scanner(System.in);
		ProductDao dao = new ProductDaoImpl();
		List<Product> productList = dao.getAllProducts();
		display(productList);
		boolean choiceFlag = false;
		boolean continueValue = false;
		do {
			do {
				System.out.println("Enter option 1.Sort By Name\n2.Sort By Price\n3.Add Product\n4.Delete\n5.Display");
				int option = scanner.nextInt();
				switch (option) {
				case 1: {
					List<Product> productListByName = dao.getAllProducts();
					Collections.sort(productListByName, new SortByName());
					display(productListByName);
				}
					break;
				case 2: {
					List<Product> productListByPrice = dao.getAllProducts();
					Collections.sort(productListByPrice, new SortByPrice());
					display(productListByPrice);
				}
					break;
				case 3: {
					System.out.println("Enter product id: ");
					int productId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter product name: ");
					String productName = scanner.nextLine();
					System.out.println("Enter product price: ");
					int price = scanner.nextInt();
					Product product = new Product(productId, productName, price);
					HashMap<Integer, Product> addProduct = dao.addProducts(product);
					Iterator<Product> iterator=addProduct.values().iterator();
					while(iterator.hasNext()) {
						Product product1=iterator.next();
						System.out.println(product1);
					}
				}
					break;
				case 4: {
					System.out.println("Enter product id you want to delete: ");
					int productId = scanner.nextInt();
					HashMap<Integer, Product> deletedMap = dao.deleteProduct(productId);
					Iterator<Product> iterator=deletedMap.values().iterator();
					while(iterator.hasNext()) {
						Product product1=iterator.next();
						System.out.println(product1);
					}
				}
					break;
				case 5:{
					List<Product> productListByName = dao.getAllProducts();
					display(productListByName);
				}break;
				}
			} while (!choiceFlag);
			
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
		} while (continueValue);
	}

	static void display(List<Product> productList) {
		Iterator<Product> iterator = productList.iterator();
		while (iterator.hasNext()) {
			Product product = iterator.next();
			System.out.println(product);
		}
	}
}
