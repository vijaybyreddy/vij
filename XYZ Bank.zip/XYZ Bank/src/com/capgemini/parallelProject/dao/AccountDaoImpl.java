package com.capgemini.parallelProject.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;

public class AccountDaoImpl implements AccountDao {

	static Map<Long, Account> map = new HashMap<>();
	static Set<Transaction> set = new LinkedHashSet<>();
	
	@Override
	public long deposit(long accountNumber, long depositedAmount) {
		// TODO Auto-generated method stub
		  //boolean status = false;
		Iterator<Account> it1=map.values().iterator();
		Long balenece=4567L;
		while(it1.hasNext())
		{
			Account acc=it1.next();
			long acNo=acc.getAccountNo();
			 balenece=acc.getBalance();
			if(acNo==accountNumber)
			{
				balenece=depositedAmount+balenece;
				acc.setBalance(balenece);
			}
		}
		/*Account acc=(Account) map.values();
		long balance=acc.getBalance();
	        
	           long updatedBalance = (long) (balance + depositedAmount);
	            map.get(accountNumber).setBalance(updatedBalance);
	           //status = true;
*/	        
	        return balenece;
	}


	/*@Override
	public long createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		 map1.put( transaction.getTransactionId(), transaction);
         
	        return transaction.getTransactionId();
	}*/


	@Override
	public long getBalance(long accountNo) {
		// TODO Auto-generated method stub
		Iterator<Account> it1=map.values().iterator();
		Long balenece=4567L;
		while(it1.hasNext())
		{
			Account acc=it1.next();
			long acNo=acc.getAccountNo();
			 balenece=acc.getBalance();
			if(acNo==accountNo)
			{
				balenece=balenece;
			}
		}   
	        return balenece;
		
		
	}


	@Override
	public void addAccount(long accountNo, Account account) {
		// TODO Auto-generated method stub
		map.put(accountNo,account);
	}


	@Override
	public long withdrawl(long accountNo, long amountWithdrawl) {
		// TODO Auto-generated method stub
		
		Iterator<Account> it2=map.values().iterator();
		Long balenece=4567L;
		while(it2.hasNext())
		{
			Account acc=it2.next();
			long acNo=acc.getAccountNo();
			 balenece=acc.getBalance();
			if(acNo==accountNo)
			{
				balenece=balenece-amountWithdrawl;
				acc.setBalance(balenece);
			}
		}
		 return balenece;
	}


	@Override
	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount) {
		// TODO Auto-generated method stub
		Iterator<Account> it1=map.values().iterator();
		Long balenece1=4567L;
		Long balenece2=4567L;
		while(it1.hasNext())
		{
			Account acc1=it1.next();
			long acNo1=acc1.getAccountNo();
			 balenece1=acc1.getBalance();
			 if(acNo1==senderAccountNo) {
			 while(it1.hasNext()) {
				 Account acc2=it1.next();
					long acNo2=acc2.getAccountNo();
					 balenece2=acc2.getBalance();
			if(acNo2==recieverAccountNo)
			{
				balenece2=transferAmount+balenece2;
				balenece1=balenece1-transferAmount;
				acc2.setBalance(balenece2);
				acc1.setBalance(balenece1);
			}
		}
			 }
		}
		/*Account acc=(Account) map.values();
		long balance=acc.getBalance();
	        
	           long updatedBalance = (long) (balance + depositedAmount);
	            map.get(accountNumber).setBalance(updatedBalance);
	           //status = true;
*/	        
	        return balenece2;
	}


	@Override
	public boolean addTraansaction(Transaction transaction) throws AccountException {
		// TODO Auto-generated method stub
		set.add(transaction);
		return true;
	}


	@Override
	public long createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public Set<Transaction> printTransaction() throws AccountException {
		// TODO Auto-generated method stub
		return set;
	}

	
}
