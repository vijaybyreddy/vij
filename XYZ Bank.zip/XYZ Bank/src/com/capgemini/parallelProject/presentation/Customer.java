package com.capgemini.parallelProject.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;
import com.capgemini.parallelProject.service.AccountService;
import com.capgemini.parallelProject.service.AccountServiceImpl;

public class Customer {

	public static void main(String[] args) throws AccountException {
		
		String continueChoice;
		boolean continueValue = false;
		Set<Transaction> st11=new LinkedHashSet<>();

		Scanner scanner = new Scanner(System.in);
		do {
			
			System.out.println("*** welcome to XYZ Bank***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			System.out.println("6.Print Transactions");
			System.out.println("7.exit");
			
			AccountService service = new AccountServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;
			
			do {
				
				
				System.out.println("Enter input:");
				
				try {
					
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;
					boolean numberFlag = false;
					boolean genderFlag=false;
					boolean accountFlag=false;
					boolean amountFlag=false;
				    boolean depositAmountFlag=false;
                    boolean withdrawlAmountFlag=false;
                    boolean recieverAccountFlag=false;
                    boolean transferAmountFlag=false;
					 
					 //String recieverAccountNo="";
					 long balance=0;
					 long bal=0;
					 long amountDeposited=0;
					 long transferAmount=0;
					 long accountNo=0;
					 long accNo=0;
					 long amountWithdrawl=0;
					 //long balanceAfterDeposition=0;
                   
					switch (choice) {
					case 1:
					{
						 String firstName="";
						String middleName="";
						String lastName="";
						do {
						System.out.println("Enter First Name:");
						firstName=scanner.next();
						try {
							service.validateName(firstName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						do {
						System.out.println("Enter Middle Name:");
						middleName=scanner.next();
						try {
							service.validateName(middleName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						do {
						System.out.println("Enter Last Name:");
						lastName=scanner.next();
						try {
							service.validateName(lastName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						String name="";
						
						do {
						name=firstName.concat(middleName.concat(lastName));
						try {
							service.validateName(name);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						//System.out.println(name);
						
						String mobileNo="";
						do {
						System.out.println("Enter mobile number:");
						mobileNo=scanner.next();
						try {
							service.validateNumber(mobileNo);
							numberFlag = true;
						} catch (AccountException e) {
							numberFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!numberFlag);
						//System.out.println(name+"  "+mobileNo);
						
						String gender="";
						do {
						System.out.println("Enter Gender:");
						 gender=scanner.next();
						if(gender.equals("male")) {
							gender="Male";
							genderFlag=true;
						}
						else if(gender.equals("female")) {
							gender="Female";
							genderFlag=true;
						}
						else {
							System.out.println("gender should be in characters and it should be either male or female");
							genderFlag=false;
						}
						}while (!genderFlag);

						 balance=0;
						do {
							System.out.println("Enter balance:");
							balance=scanner.nextLong();
							try {
								service.validateAmount(balance);
								amountFlag = true;
							} catch (AccountException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
							}while (!amountFlag);
						
						accountNo = service.generateId();
						System.out.println("account created with the given id: " + accountNo);
						Account account = new Account(accountNo,balance,name,gender,mobileNo);
						service.addAccount(accountNo,account);}
						break;
					
					case 2:
						
					{
                        System.out.println("Enter amount to be deposited:");
                    scanner = new Scanner(System.in);
                     amountDeposited = scanner.nextLong();
                    LocalDate date = LocalDate.now();
							System.out.println("Enter account number for deposit:");
								accountNo=scanner.nextLong();
                     long balanceAfterDeposit=service.deposit(accountNo, amountDeposited);
                     System.out.println(balanceAfterDeposit);
                     int transacId = service.transacId();
                     LocalDate date1 = LocalDate.now();
                     Transaction transaction = new Transaction(transacId, "deposit", date1, accountNo,balanceAfterDeposit);
                     
                     service.addTransaction(transaction);
                     
                    
                        }
                        break;
					
					case 3:{
						
						System.out.println("Enter amount to be withdrawn:");
	                    scanner = new Scanner(System.in);
	                     amountWithdrawl = scanner.nextLong();
	                    LocalDate date = LocalDate.now();
								System.out.println("Enter account number for withdrawl:");
									accountNo=scanner.nextLong();
	                     long balanceAfterWithdrawl=service.withdrawl(accountNo, amountWithdrawl);
	                    
	                     System.out.println(balanceAfterWithdrawl);
	                     int transacId = service.transacId();
	                     LocalDate date1 = LocalDate.now();
	                     Transaction transaction = new Transaction(transacId, "withdrawl", date1, accountNo,balanceAfterWithdrawl);
	                     service.addTransaction(transaction);
					}
						break;
						
					case 4:{
							
							System.out.println("Enter your account number:");
								long senderAccountNo=scanner.nextLong();
  							
  							System.out.println("Enter reciever's account number:");
  							long recieverAccountNo=scanner.nextLong();
                          
                          do {
    							
    							System.out.println("Enter amount to be transferred:");
    							transferAmount=scanner.nextInt();
    							
    							try {
    								service.validateAmount(transferAmount);
    								transferAmountFlag = true;
    							} catch (AccountException e) {
    								transferAmountFlag = false;
    								System.err.println(e.getMessage());
    							}
    							
    						}while(!transferAmountFlag);
                          long balanceAfterTransaction=service.addTransaction(senderAccountNo,recieverAccountNo,transferAmount);
                          System.out.println(balanceAfterTransaction);
                          int transacId = service.transacId();
                          LocalDate date1 = LocalDate.now();
                          Transaction transaction = new Transaction(transacId, "deposit", date1, accountNo,balanceAfterTransaction);
                          service.addTransaction(transaction);
					}
						break;
						
					case 5:
					{
								System.out.println("Enter your account number:");
									accountNo=scanner.nextLong();
									bal=service.getBalance(accountNo);
									  System.out.println("Your account balance is:"+bal);
					}
						break;
						
					case 6:
						 {
                                    System.out.println("your transactions are as mentioned:");
                                  System.out.println(service.printTransaction());
                                  
                                }
						break;
						
					case 7:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
						
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
						
					}
				}catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
				
			}while(!choiceFlag);
			
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
			
		}while (continueValue);
		scanner.close();
	}

}
