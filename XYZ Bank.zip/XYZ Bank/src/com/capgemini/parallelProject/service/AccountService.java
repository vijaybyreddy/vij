package com.capgemini.parallelProject.service;

import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;

public interface AccountService {

	public boolean validateName(String name) throws AccountException;
	public boolean validateNumber(String mobileNo) throws AccountException;
	//public boolean validateAccountNumber(long accountNo) throws AccountException;
	public boolean validateAmount(double accountNo) throws AccountException;
	
	public long generateId() throws AccountException;
	public void addAccount(long accountNo, Account account) throws AccountException;
	public long deposit(long accNo, long amountDeposited) throws AccountException;
	public long withdrawl(long accountNo, long amountWithdrawl) throws AccountException;
	public long addTransaction(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException;
	public long getBalance(long accountNo);
	public int transacId();
	public boolean addTransaction(Transaction transaction) throws AccountException;
	public Set<Transaction> printTransaction() throws AccountException;
}
