

function getInputValue(){

            var inputVal = document.getElementById('search').value;
    var urltemp = "http://www.google.com/search?q=";
	var url = urltemp.concat(inputVal);
    window.open(url);
        }
