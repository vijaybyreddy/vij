$(document).ready(function(){
    $(".tab1").click(function(){
  $(this).parents('.tab').next('div#Tab1').toggle();

});

});


