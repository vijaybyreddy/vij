
var c;
function myfunction(c)
{
alert("inside method");
    var url = c;
    window.open(url);

} 

