package bank.xyz.Dao;

import java.util.List;

import bank.xyz.Model.Bank;

public interface Dao {
	void createAccount(Bank b);
	Bank showBalance(int accNo);
	void deposit(int accNo, int amt);
	void withdraw(int accNo, int amt);
	void fundTransfer(int accNo, int accNoto, int amt);
	List<String> printTrans1(int accNO);
}
