package bank.xyz.Dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bank.xyz.Exception.InsufficientBalException;
import bank.xyz.Model.Bank;

public class DaoImpl implements Dao {
	private static List<Bank> L1 = new ArrayList<Bank>();
	static{
		Bank b1 = new Bank("Ganesh",1000,1500);
		Bank b2 = new Bank("Chanti",1001,2000);
	    Bank b3 = new Bank("Sriram",1002,3000);
	    L1.add(b1);
	    L1.add(b2);
	    L1.add(b3);
	}

	
	@Override
	public void createAccount(Bank b) {
		L1.add(b);
		b.setList("Account created on  " + getdate());
		System.out.println(b);
			
	}

	@Override
	public Bank showBalance(int accNo) {
		Bank b = new Bank();
		for(Bank b1 : L1){
			if(b1.getAccNo()==accNo){
				b = b1;
				break;
			}
			
		}
		return b;
	}

	@Override
	public void deposit(int accNo, int amt) {
		Bank b = new Bank();
		for(Bank b1 : L1){
			if(b1.getAccNo()==accNo){
				b = b1;
				break;
				
			}
		}
		b.setBalance(b.getBalance()+amt);
		System.out.println("Amount succesfully deposited");
		System.out.println("New Balance :"+ b.getBalance());
		b.setList("Money deposited "+ amt + " on " + getdate());
	}

	@Override
	public void withdraw(int accNo, int amt) {
		Bank b = new Bank();
		for(Bank b1 : L1){
			if(b1.getAccNo()==accNo){
				b= b1;
				break;
			}
		}
		if(b.getBalance()>amt){
			b.setBalance(b.getBalance()- amt);
			System.out.println("Amount successfully withdraw");
			System.out.println("Your new balance :"+ b.getBalance());
			b.setList("Money Withdrawn " + amt + " on " + getdate());
			
		} else
			try {
				throw new InsufficientBalException("You have Insufficient Funds");
			} catch (InsufficientBalException e) {
				
				e.printStackTrace();
			}
			
	}

	@Override
	public void fundTransfer(int accNo, int accNoto, int amt) {
		Bank b = new Bank();
		for(Bank b1 : L1){
			if(b1.getAccNo() == accNo){
				b = b1;
				break;
			}
		}
		Bank b2 = new Bank();
		for(Bank bt : L1){
			if(bt.getAccNo()==accNoto){
				b2 = bt;
				break;
			}
		}
		if(b.getBalance()>amt){
			b.setBalance(b.getBalance()- amt);
			System.out.println("Amount succefully withdrawn and credited to recipient");
			System.out.println("New Balanc :" + b.getBalance());
			System.out.println("-------------**************--------------");
			b2.setBalance(b2.getBalance()+amt);
			System.out.println("Recipient new balance :" + b2.getBalance());
			System.out.println("Account No: " +b2.getAccNo() +"  User Name: " +b2.getUserName()+"  Balance: "+b2.getBalance());
			b.setList("Money transferred from your account of " + amt + " on " + getdate());
			
		}
		else
			System.out.println("You have insuficient funds to Transfer");
	}
	
	
	public String getdate()
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		String s = df.format(dateobj);
		return s;
	}
	@Override
	public List<String> printTrans1(int accno) {
		
		Bank b = new Bank();
		for(Bank b1 : L1) { 
			   if(b1.getAccNo()==accno)
			   {
				   b=b1;
				   break;
			   }
			}
		return b.getList();
	}


	}







































