package bank.xyz.Exception;


/*
 * Exception for insufficient fund
 */
public class InsufficientBalException extends Exception{
	
public	InsufficientBalException (String m){
	super(m);
}
	

}
