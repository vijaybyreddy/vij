package bank.xyz.Service;


import java.util.List;

import bank.xyz.Model.Bank;

public interface BankService {
	

	void createAccount();
	
	Bank showBalance();

	void deposit();

	void withdraw();

	void fundTransfer();

	List<String> printTrans();
	}
