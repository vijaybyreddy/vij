package com.cg.DAO;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Product;
import com.cg.bean.Supplier;

public interface SuperShoppeDAO {
	 Map<Integer, Product> prodList = new HashMap<>();
	    Map<Integer, Supplier> supList = new HashMap<>();
	        public int addProduct(Product product);
	        public int addSupplier(Supplier sup);
	        public HashMap<Integer, Product>getAllProducts();
	        public HashMap<Integer, Supplier>getAllSuppliers();
}
