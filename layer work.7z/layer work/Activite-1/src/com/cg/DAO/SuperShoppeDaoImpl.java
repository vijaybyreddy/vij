package com.cg.DAO;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.bean.Supplier;

public class SuperShoppeDaoImpl implements SuperShoppeDAO {

	HashMap<Integer, Product> products = new HashMap<Integer, Product>();
	HashMap<Integer, Supplier> suppliers = new HashMap<Integer, Supplier>();

	public int addProduct(Product product) {
		
		products.put(product.getProductId(), product);
		return product.getProductId();
	}

	public int addSupplier(Supplier sup) {
		// TODO Auto-generated method stub
		suppliers.put(sup.getSupplierId(), sup);
		return sup.getSupplierId();
	}

	public HashMap<Integer, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return products;
	}

	public HashMap<Integer, Supplier> getAllSuppliers() {
		// TODO Auto-generated method stub
		return suppliers;
	}

}