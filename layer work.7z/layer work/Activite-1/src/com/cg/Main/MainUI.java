package com.cg.Main;

import java.rmi.AccessException;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.SuperShoppeService.SuperShoppeServiceImpl;
import com.cg.bean.Product;
import com.cg.bean.Supplier;

public class MainUI {
	  /**
     * CustomerService object initialized to call service method
     * 
     * @param args
	 * @throws Exception 
     */

 

    public static void main(String[] args) throws Exception {

 

        SuperShoppeServiceImpl service = new SuperShoppeServiceImpl();
        /**
         * scanner is crested to take inputs
         */
        Scanner scanner = new Scanner(System.in);
        /**
         * adddetails() take inputs for customer registration
         */
        String option = null;
        do {
            System.out.println("1.ADDPRODUCT\n 2.ADDSUPPLIER\n 3.DISPLAY PRODUCT\n  4.DISPLAY SUPPLIER\n 0.Exit");
            int choice = scanner.nextInt();
            switch (choice) {
            case 0:
                System.exit(0);
                
            case 1: {
                System.out.println("Enter Name");
                String name = scanner.next();
                System.out.println("Enter Address");
                String address = scanner.next();
                System.out.println("Enter Phone");
                long phone = scanner.nextLong();
                if (!service.isNameValid(name) || !service.isPhoneValid(phone))
                    try {
                        throw new Exception("invalid credentials");
                    } catch (AccessException e) {
                        System.err.println(e.getMessage());
                    }
                Supplier supplier = new Supplier(0, name,phone, address);
                int supplierId = service.addSupplier(supplier);
                System.out.println("Supplier Registered successfully and your Id is:" + supplierId);
            }break;
                
            case 2: {
                System.out.println("Enter Name");
                String name = scanner.next();
                System.out.println("Enter Price");
                double price = scanner.nextDouble();
                System.out.println("Enter Quantity");
                int quantity = scanner.nextInt();
                if (!service.isNameValid(name))
                    try {
                        throw new Exception("invalid credentials");
                    } catch (AccessException e) {
                        System.err.println(e.getMessage());
                    }
                Product product = new Product(0, name, price, quantity);
                int productId = service.addProduct(product);
                System.out.println("Product Registered successfully and your Id is:" + productId);
            }
                break;
                
            case 3: {
                HashMap<Integer,Product> prodList = service.getAllProducts();
                System.out.println(prodList);
            }
                break;
                
            case 4: {
                HashMap<Integer,Supplier> supList = service.getAllSuppliers();
                System.out.println(supList);
            }
            }
            System.out.println("press y to continue");
            option = scanner.next();
        } while (option.equalsIgnoreCase("y"));

 

        scanner.close();
    }

}
