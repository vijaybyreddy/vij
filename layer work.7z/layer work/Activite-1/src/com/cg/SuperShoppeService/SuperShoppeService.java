package com.cg.SuperShoppeService;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Product;
import com.cg.bean.Supplier;

public interface SuperShoppeService {
	 Map<Integer, Product> prodList = new HashMap<>();
	    Map<Integer, Supplier> supList = new HashMap<>();
	public int addProduct(Product product);
	public int addSupplier(Supplier supplier);
	public Map<Integer, Product> getAllProducts();
	public Map<Integer, Supplier> getAllSuppliers();
}
