package com.cg.SuperShoppeService;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.DAO.SuperShoppeDAO;
import com.cg.DAO.SuperShoppeDaoImpl;
import com.cg.Test.ShoppeException;
import com.cg.bean.Product;
import com.cg.bean.Supplier;

public class SuperShoppeServiceImpl implements SuperShoppeService {
	 SuperShoppeDAO superShopeeDao = new SuperShoppeDaoImpl();

	    public int addProduct(Product product) {
	        // TODO Auto-generated method stub
	        int productId = (int) (Math.random() * 1000);
	        product.setProductId(productId);
	        return superShopeeDao.addProduct(product);
	    }

	    public int addSupplier(Supplier sup) {
	        // TODO Auto-generated method stub
	        int supplierId = (int) (Math.random() * 1000);
	        sup.setSupplierId(supplierId);
	        return superShopeeDao.addSupplier(sup);
	    }

	
	    public HashMap<Integer, Product> getAllProducts() {
	    
	        return superShopeeDao.getAllProducts();
	    }

	 
	    public HashMap<Integer, Supplier> getAllSuppliers() {
	        // TODO Auto-generated method stub
	        /* HashMap<Integer,Supplier> map1=new HashMap<Integer, Supplier>(); */
	        return superShopeeDao.getAllSuppliers();
	    }

	
	    public boolean isNameValid(String name)throws ShoppeException {
	        Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
	        Matcher match = nameptn.matcher(name);
	        if (match.matches()) {
	            return true;
	        }
	        return false;
	    }


	    public boolean isPhoneValid(long phone)throws ShoppeException {
	        String mobile = String.valueOf(phone);
	        Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
	        Matcher match = nameptn.matcher(mobile);
	        if (match.matches()) {
	            return true;
	        }
	        return false;
	    }

}
