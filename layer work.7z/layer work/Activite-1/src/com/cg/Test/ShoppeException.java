package com.cg.Test;

public class ShoppeException extends Exception {
	public ShoppeException(String message) {
		super(message);
	}

}
