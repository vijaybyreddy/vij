package com.cg.bean;

public class Supplier {
	 private int supplierId;
	    private String Name;
	    private double mobileNo;
	    private String address;
		@Override
		public String toString() {
			return "supplierId=" + supplierId + ", Name=" + Name + ", mobileNo=" + mobileNo + ", address="
					+ address + "]";
		}
		public int getSupplierId() {
			return supplierId;
		}
		public void setSupplierId(int supplierId) {
			this.supplierId = supplierId;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public double getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(double mobileNo) {
			this.mobileNo = mobileNo;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Supplier(int supplierId, String name, double mobileNo, String address) {
			super();
			this.supplierId = supplierId;
			Name = name;
			this.mobileNo = mobileNo;
			this.address = address;
		}
		public Supplier() {
			super();
			// TODO Auto-generated constructor stub
		}

}
