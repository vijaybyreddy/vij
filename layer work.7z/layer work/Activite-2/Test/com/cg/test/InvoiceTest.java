package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.bean.Invoice;
import com.cg.dao.InvoiceDAO;
import com.cg.dao.InvoiceDaoImpl;

class InvoiceTest extends InvoiceDaoImpl {
static InvoiceDAO dao=null;
Invoice invoice;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao=new InvoiceDaoImpl(); 
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@BeforeEach
	void setUp() throws Exception {
		invoice=new Invoice(10,2000,3000,4000,5000,6000);
	}

	@AfterEach
	void tearDown() throws Exception {
		invoice=null;
	}

	@Test
	void testAddInvoice() {
		assertEquals(10,dao.addInvoice(invoice));
	}

	@Test
	void testGetAlldetails() {
		assertNotEquals(4, dao.getAlldetails().size());
	}

}
