package com.cg.Service;

import java.util.Map;

import com.cg.bean.Invoice;
import com.cg.exception.InvoiceException;

public interface InvoiceService {
	 public int addInvoice(Invoice invoice);
	    public Map<Integer, Invoice> getAlldetails();
	    public boolean validateWeight(double weight)throws InvoiceException;
	    public void validateDistance(double distance)throws InvoiceException;

}
