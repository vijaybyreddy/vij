package com.cg.Service;

import java.util.Map;

import com.cg.bean.Invoice;
import com.cg.dao.InvoiceDAO;
import com.cg.dao.InvoiceDaoImpl;
import com.cg.exception.InvoiceException;

public class InvoiceServiceImpl implements InvoiceService {
	  InvoiceDAO invoicedao = new InvoiceDaoImpl();

	  @Override
	    public int addInvoice(Invoice invoice) {
	        int invoiceId = (int) (Math.random() * 1000);
	        invoice.setId(invoiceId);
	        return invoicedao.addInvoice(invoice);
	    }

	 

	    @Override
	    public Map<Integer, Invoice> getAlldetails() {

	 

	        return invoicedao.getAlldetails();
	    }

	 

	    public boolean validateWeight(double weight) throws InvoiceException {
	        boolean weightflag = false;
	        if (weight < 1) {
	            weightflag = true;
	            throw new InvoiceException("weight should be greater than 1 kg\n");
	        }
	        return weightflag;
	    }

	 

	    public void validateDistance(double distance) throws InvoiceException {
	        if (distance > 100) {
	            throw new InvoiceException("distance should be less than 100 km\n");
	        }
	    }

}
