package com.cg.bean;
/**
 * 
 * @author vibyredd
 *
 */
public class Invoice {
	  public Invoice(Integer id, double weight, double distance, double transportationcharge, double cgst, double sgst) {
		super();
		Id = id;
		this.weight = weight;
		this.distance = distance;
		this.transportationcharge = transportationcharge;
		this.cgst = cgst;
		this.sgst = sgst;
		this.totaltransport = totaltransport;
	}
	  
	private Integer Id;
	  private double weight;
	  private double distance;
	  private double transportationcharge;
	  private double cgst;
	  private double sgst;
	  private double totaltransport;
	@Override
	public String toString() {
		return "Invoice [Id=" + Id + ", weight=" + weight + ", distance=" + distance + ", transportationcharge="
				+ transportationcharge + ", cgst=" + cgst + ", sgst=" + sgst + ", totaltransport=" + totaltransport
				+ "]";
	}
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public double getTransportationcharge() {
		return transportationcharge;
	}
	public void setTransportationcharge(double transportationcharge) {
		this.transportationcharge = transportationcharge;
	}
	public double getCgst() {
		return cgst;
	}
	public void setCgst(double cgst) {
		this.cgst = cgst;
	}
	public double getSgst() {
		return sgst;
	}
	public void setSgst(double sgst) {
		this.sgst = sgst;
	}
	public double getTotaltransport() {
		return totaltransport;
	}
	public void setTotaltransport(double totaltransport) {
		this.totaltransport = totaltransport;
	}
	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}

}
