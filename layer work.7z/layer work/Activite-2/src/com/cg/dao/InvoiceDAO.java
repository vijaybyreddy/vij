package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Invoice;

public interface InvoiceDAO {
	  Map<Integer, Invoice> map = new HashMap<>();

	    public int addInvoice(Invoice invoice);

	    Map<Integer, Invoice> getAlldetails();
}
