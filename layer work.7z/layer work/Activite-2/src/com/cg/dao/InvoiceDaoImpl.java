package com.cg.dao;

import java.util.Map;

import com.cg.bean.Invoice;

public class InvoiceDaoImpl implements InvoiceDAO {
	   @Override
	    public int addInvoice(Invoice invoice) {
	        Invoice i = map.put(invoice.getId(), invoice);
	        return invoice.getId();
	    }

	    @Override
	    public Map<Integer, Invoice> getAlldetails() {
	    
	        return map;
	    }

}
