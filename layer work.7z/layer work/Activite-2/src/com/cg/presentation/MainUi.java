package com.cg.presentation;

import java.util.Map;
import java.util.Scanner;

import com.cg.Service.InvoiceServiceImpl;
import com.cg.bean.Invoice;
import com.cg.exception.InvoiceException;

public class MainUi {
	 static InvoiceServiceImpl service = new InvoiceServiceImpl();
	    static Scanner sc = new Scanner(System.in);
	    public static void addinginvoice() {
	    System.out.println("Enter weights in kg's=");
	    double weight = sc.nextDouble();
	    try {
	        
	        service.validateWeight(weight);
	    } catch (InvoiceException e) {
	        System.err.println(e.getMessage());
	        }

	     

	    System.out.println("Enter distance in km:");
	    double distance = sc.nextDouble();
	    try {
	        
	        service.validateDistance(distance);
	    } catch (InvoiceException e) {
	        System.err.println(e.getMessage());
	    }
	    double transportationcharge = (2*distance*weight);
	    double cgst = ((3.5)*(transportationcharge)/100);
	    double sgst = ((3.5)*(transportationcharge)/100);
	    double totaltransport = (transportationcharge + cgst + sgst);
	    Invoice invoice = new Invoice(0,weight,distance,transportationcharge,cgst,sgst);
	    int invoiceId = service.addInvoice(invoice);
	    System.out.println("Transportation charges are:"+transportationcharge+
	            "cgst is:"+cgst+"sgst is:"+sgst+"totaltransport is:"+totaltransport);
	    System.out.println("Invoice added successfully and your invoice id is:"+invoiceId);
	    }
	public static void main(String[] args) {
		   String option = null;
	        do {
	            System.out.println("Welcome to Invoice");
	            System.out.println("1.Add invoice\n2.Display records\n"); 
	            int choice = sc.nextInt();
	            switch(choice) {
	            case 0: 
	                System.out.println("Thank You");
	            System.exit(0);
	            case 1:{
	                addinginvoice();
	                }break;
	            case 2: {
	    Map<Integer, Invoice> invoicelist = service.getAlldetails();
	    System.out.println(invoicelist);
	            }
	            }
	        System.out.println("Press y to continue");
	        option = sc.next();
	            
	            }
	        while(option.equalsIgnoreCase("Choice number"));
	        sc.close();

	 

	}

	}


