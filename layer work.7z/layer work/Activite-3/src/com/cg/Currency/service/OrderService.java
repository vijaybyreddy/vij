package com.cg.Currency.service;

import java.util.Map;

import com.cg.bean.Order;
import com.cg.expection.OrderException;

public interface OrderService {
	 int calculateOrder(Order bean) throws OrderException;
	    public Map<Integer, Order> getAllOrders() throws OrderException;
	    int addProductDetails(Order bean);
	    
	    boolean validateQuantity(int quantity) throws OrderException;

}
