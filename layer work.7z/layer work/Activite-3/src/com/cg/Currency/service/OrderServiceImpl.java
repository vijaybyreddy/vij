package com.cg.Currency.service;

import java.util.Map;

import com.cg.Dao.OrderDao;
import com.cg.Dao.OrderDaoImpl;
import com.cg.bean.Order;
import com.cg.expection.OrderException;

public class OrderServiceImpl implements OrderService {
	OrderDao orderDao = new OrderDaoImpl();

	@Override
	  public int calculateOrder(Order bean) throws OrderException {
        // TODO Auto-generated method stub
        return orderDao.calculateOrder(bean);
    }
	 @Override
	    public Map<Integer, Order> getAllOrders() throws OrderException {
	        // TODO Auto-generated method stub
	        return orderDao.getAllOrders();
	    }

	 @Override
	    public int addProductDetails(Order bean) {
	        // TODO Auto-generated method stub
	        return orderDao.addProductDetails(bean);
	    }

	  @Override
	    public boolean validateQuantity(int quantity) throws OrderException {
	        // TODO Auto-generated method stub
	        boolean quantityFlag = false;

	 

	        if (quantity< 1) {
	            throw new OrderException("quantity should not be lessthan 1");
	        } else {
	            quantityFlag = true;
	        }
	        return quantityFlag;
	    }
}
