package com.cg.Dao;

import java.util.Map;

import com.cg.bean.Order;
import com.cg.expection.OrderException;

public interface OrderDao {
	int calculateOrder(Order bean) throws OrderException;
	public Map<Integer, Order> getAllOrders() throws OrderException;
	public int addProductDetails(Order bean);
}
