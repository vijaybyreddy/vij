package com.cg.Dao;

import java.util.Map;

import com.cg.Currency.utility.OrderRepo;
import com.cg.bean.Order;
import com.cg.expection.OrderException;

public class OrderDaoImpl implements OrderDao {
	Map<Integer, Order> currencies=OrderRepo.getOrders();

	public int addProductDetails(Order bean) {
		 int productId=(int)(Math.random()*1000);
	        currencies.put(productId, bean);
	        return productId;
		
	}

	@Override
	public int calculateOrder(Order bean) throws OrderException {
		// TODO Auto-generated method stub
		 int amount=0;
	        double conversionCharges=0.0125;
	        double Amount=(bean.getPrice()*bean.getQuantity()*75);
	        double conversion=(Amount*conversionCharges);
	        return amount=(int) Amount + (int)conversion;
	        
		
	}

	@Override
	public Map<Integer, Order> getAllOrders() throws OrderException {
		// TODO Auto-generated method stub
		return currencies;
	}

}
