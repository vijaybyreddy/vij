package com.cg.expection;

public class OrderException extends Exception{
	 public OrderException(String message) {
	        super(message);
	        // TODO Auto-generated constructor stub
	    }

}
