package com.cg.presenation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.Currency.service.OrderService;
import com.cg.Currency.service.OrderServiceImpl;
import com.cg.bean.Order;
import com.cg.expection.OrderException;

public class MainUi {
	  public static void main(String[] args) throws OrderException {
	        // TODO Auto-generated method stub

	 

	        String continueChoice;
	        boolean continueValue = false;
	        Scanner scanner = null;
	        do {
	        
	            System.out.println("*** welcome to currency conversion");
	            System.out.println("1.currencyConversion");
	            System.out.println("2.display all");
	            System.out.println("3.exit");

	 

	            OrderService service = new OrderServiceImpl();
	            
	            int choice = 0;
	            boolean choiceFlag = false;
	            do {
	                scanner = new Scanner(System.in);
	                System.out.println("Enter input:");
	                try {
	                    choice = scanner.nextInt();
	                    choiceFlag = true;

	 

	                    boolean vehicleNameFlag = false;
	                    switch (choice) {
	                    case 1:
	                        
	                            scanner = new Scanner(System.in);
	                            System.out.println("Enter Price in dollars:");
	                            double price = scanner.nextDouble();
	                            
	                            System.out.println("Enter quantity:");
	                        int quantity=0;
	                        try {
	                            quantity = scanner.nextInt();
	                            service.validateQuantity(quantity);
	                        } catch (OrderException e1) {
	                            // TODO Auto-generated catch block
	                            System.err.println(e1.getMessage());
	                        }
	                            double amount=0;
	                            double charges=0;
	                            int id=0;
	                            Order order1 = new Order(id,price,quantity,amount,charges);
	                            int converted= service.calculateOrder(order1);
	                            Order order = new Order(id,price,quantity,converted,charges);
	                        int genearatedId = service.addProductDetails(order);
	                        System.out.println("vehicle stored with the given id: " + genearatedId);
	                            break;
	                    case 2:
	                        try {
	                            Map<Integer, Order> orders = service.getAllOrders();

	 

	                            Iterator<Integer> iterator = orders.keySet().iterator();
	                            while (iterator.hasNext()) {
	                                int id1 = iterator.next();
	                                Order orderData = orders.get(id1);
	                                System.out.println(id1 + ": " + orderData);
	                            }

	 

	                        } catch (OrderException e) {
	                            System.err.println(e.getMessage());
	                        }
	                        break;
	                        
	                    case 3:
	                        System.exit(0);

	 

	                    }
	                }catch (InputMismatchException exception) {
	                        choiceFlag = false;
	                        System.err.println("input should contain only digits");
	                    }
	                    }while(!choiceFlag);
	                    
	                    do {
	                        scanner = new Scanner(System.in);
	                        System.out.println("do you want to continue again [yes/no]");
	                        continueChoice = scanner.nextLine();
	                        if (continueChoice.equalsIgnoreCase("yes")) {
	                            continueValue = true;
	                            break;
	                        } else if (continueChoice.equalsIgnoreCase("no")) {
	                            System.out.println("thank you");
	                            continueValue = false;
	                            break;
	                        } else {
	                            System.out.println("enter yes or no");
	                            continueValue = false;
	                            continue;
	                        }
	                    } while (!continueValue);
	        }while(continueValue);
	            scanner.close();
	    }

	 

	}
	 

