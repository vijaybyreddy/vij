package com.capgemini.customerportal.presentation;

 

import java.util.List;
import java.util.Scanner;

import com.capgemini.customerpotral.bean.Customer;
import com.capgemini.customerpotral.dao.CustomerDaoImpl;
import com.capgemini.customerpotral.service.CustomerService;
import com.capgemini.customerpotral.service.CustomerServiceImpl;

 /**
  * 
  * @author vibyredd
  * @version 1.0
  * This is the MainUI class taking user inputs
  *
  */

 

public class MainUI {

 /*
  * CustomerService object initilized to call service method4
  */

    public static void main(String[] args) {
        CustomerServiceImpl service=new CustomerServiceImpl();
        Scanner scanner=new Scanner(System.in);
        String option=null;
        do {
            System.out.println("1.Add\n2.Update\n3.Delete\n4.ViewById\n5.ViewAll\n0.Exit");
            int choice=scanner.nextInt();
            switch(choice) {
            case 0: System.exit(0);
            case 1: {
                System.out.println("Enter Name");
                String name=scanner.next();
                
                System.out.println("Enter Address");
                String address=scanner.next();
                System.out.println("Enter phone");
                long phone=scanner.nextLong();
                Customer customer=new Customer(0,name,address,phone);
                int custId=service.addCustomer(customer);
                System.out.println("Customer Registered successfully and your id is:"+custId);
            }break;
            case 2:{
            	System.out.println("Enter customer Id to update");
            	int custId=scanner.nextInt();
            	System.out.println("Enter name");
            	String name=scanner.next();
            	System.out.println("Enter address");
            	String address=scanner.next();
            	System.out.println("enter phone");
            	long phone=scanner.nextLong();
            	Customer customer=new Customer(custId,name,address,phone);
            }break;
            case 3:{
            	System.out.println("Enter Customer id to delete");
            	int custId=scanner.nextInt();
            }
            case 5:{
                List<Customer> customerList=service.getCustomers();
                System.out.println(customerList);
            }break;
            }
            System.out.println("press y to continue"); 
            option=scanner.next();    
        }while(option.equalsIgnoreCase("y"));
        
        scanner.close();

 

    }

 

}