package com.capgemini.customerpotral.dao;

 

import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.customerpotral.bean.Customer;

 

public  class CustomerDaoImpl implements CustomerDAO {
    boolean status=false;

 Logger log=Logger.getLogger("CustomerDaoImpl");

    @Override
    public int addCustomer(Customer customer) {
    	log.info("customerdao addcustomer() statred");
        customerList.put(customer.getCustomerId(),customer);
        return customer.getCustomerId();
    }

 

    @Override
    public boolean updateCustomer(Customer customer) {
        Customer c=customerList.put(customer.getCustomerId(),customer);
        if(c!=null)
            status=true;
            return status;
    }

 

    @Override
    public boolean deleteCustomer(int customerId) {
        Customer c=customerList.remove(customerId);
        if(c!=null)
            status=true;
            return status;
    }

 

    @Override
    public Customer getCustomer(int customerId) {
        return customerList.get(customerId);
    }

 

    @Override
    public Map<Integer, Customer> getCustomers() {
        // TODO Auto-generated method stub
        return customerList;
    }


 

}