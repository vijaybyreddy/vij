package com.capgemini.customerpotral.service;


import java.util.List;
import java.util.Map;

import com.capgemini.customerpotral.bean.Customer;
import com.capgemini.customerpotral.exception.CustomerPortalException;

public interface CustomerService {
	
	int addCustomer(Customer customer);
	boolean updateCustomer(Customer customer) throws CustomerPortalException;
	boolean deleteCustomer(int customerId)throws CustomerPortalException;
	Customer getCustomer(int customerId);
	List<Customer> getCustomers();
	
	


}
