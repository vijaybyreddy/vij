package com.capgemini.customerpotral;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.customerpotral.bean.Customer;
import com.capgemini.customerpotral.dao.CustomerDAO;
import com.capgemini.customerpotral.dao.CustomerDaoImpl;

class CustomerDaoImplTest {
static CustomerDAO dao;
Customer customer;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao=new CustomerDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=new CustomerDaoImpl();
	}

	@BeforeEach
	void setUp() throws Exception {
		customer=new Customer(0,"priya","bangalore",9989381077L);
	}

	@AfterEach
	void tearDown() throws Exception {
		customer=null;
	}

	@Test
	void testAddCustomer() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdateCustomer() {
		int custId=dao.addCustomer(customer);
	}

	@Test
	void testDeleteCustomer() {
		int custId=dao.addCustomer(customer);
		customer=new Customer(custId,"Dhiya","Mumbai",98490001544L);
		assertTrue(dao.deleteCustomer(custId));
	}

	@Test
	void testGetCustomer() {
		int custId=dao.addCustomer(customer);
		assertNotNull(dao.getCustomer(custId));
	}

	@Test
	void testGetCustomers() {
		dao.customerList.clear();
		int custId=dao.addCustomer(customer);
		assertEquals(1,dao.customerList.size());
	}

}
