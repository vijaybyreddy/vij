package com.capgemini.employee.Employee;

public class Employee {
	private int employeeId;
	private String employeename;
	private double employeesalary;
	private String employeedesignation;
	private String employeensuranceScheme;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String employeename, double employeesalary, String employeedesignation,
			String employeensuranceScheme) {
		super();
		this.employeeId = employeeId;
		this.employeename = employeename;
		this.employeesalary = employeesalary;
		this.employeedesignation = employeedesignation;
		this.employeensuranceScheme = employeensuranceScheme;
	}
	

}
