package com.cg.DTO;

public class FlatRegistrationDTO {
	private int id;
	private String FlatType;
	private double FlatArea;
	private double RentAmount;
	private double DepositAmount;
	@Override
	public String toString() {
		return "id=" + id + ", FlatType=" + FlatType + ", flatarea=" + FlatArea + ", rentamount=" + RentAmount + ", DepositAmount=" + DepositAmount + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFlatType() {
		return FlatType;
	}
	public void setFlatType(String flattype) {
		FlatType = flattype;
	}
	public double getFlatArea() {
		return FlatArea;
	}
	public void setFlatArea(double flatarea) {
		FlatArea = flatarea;
	}
	public double getRentAmount() {
		return RentAmount;
	}
	public void setRentAmount(double rentamount) {
		RentAmount = rentamount;
	}
	public double getDepositAmount() {
		return DepositAmount;
	}
	public void setDepositAmount(double depositamount) {
		DepositAmount = depositamount;
	}
	public FlatRegistrationDTO(int id, String flattype, double flatarea, double rentamount, double depositamount) {
		super();
		this.id = id;
		FlatType = flattype;
		FlatArea = flatarea;
		RentAmount = rentamount;
		DepositAmount = depositamount;
	}
	public FlatRegistrationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
