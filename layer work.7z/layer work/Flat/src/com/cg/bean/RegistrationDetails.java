package com.cg.bean;

public class RegistrationDetails {
	private int FlatRegistrationNumber;
	private String FlatType;
	private double FlatAmount;
	private double RentAmount;
	private double DepositAmount;
	@Override
	public String toString() {
		return "FlatRegistrationNumber=" + FlatRegistrationNumber + ", FlatType=" + FlatType + ", FlatAmount=" + FlatAmount
				+ ", RentAmount=" + RentAmount + ", DepositAmount=" + DepositAmount + "]";
	}
	public int getFlatRegistrationNumber() {
		return FlatRegistrationNumber;
	}
	public void setFlatRegistrationNumber(int flatRegistrationNumber) {
		FlatRegistrationNumber = flatRegistrationNumber;
	}
	public String getFlatType() {
		return FlatType;
	}
	public void setFlatType(String flattype) {
		FlatType= flattype;
	}
	public double getFlatAmount() {
		return FlatAmount;
	}
	public void setFlatAmount(double flatamount) {
		FlatAmount = flatamount;
	}
	public double getRentAmount() {
		return RentAmount;
	}
	public void setRentAmount(double rentamount) {
		RentAmount= rentamount;
	}
	public double getDepositAmount() {
		return DepositAmount;
	}
	public void setDepositAmount(double depositamount) {
		DepositAmount = depositamount;
	}
	public RegistrationDetails(int flatRegistrationNumber, String flattype, double flatamount, double rentamount, double depositamount) {
		super();
		FlatRegistrationNumber = flatRegistrationNumber;
		FlatType = flattype;
		FlatAmount = flatamount;
		RentAmount = rentamount;
		DepositAmount = depositamount;
	}
	public RegistrationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

}
