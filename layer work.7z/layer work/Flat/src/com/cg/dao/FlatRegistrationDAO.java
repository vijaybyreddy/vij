package com.cg.dao;

import java.util.ArrayList;

import com.cg.DTO.FlatRegistrationDTO;
import com.cg.bean.FlatOwner;
import com.cg.bean.RegistrationDetails;

public interface FlatRegistrationDAO {
	FlatRegistrationDTO registerDTO(RegistrationDetails a);
	ArrayList<FlatOwner> getAllOwnerIds();

}
