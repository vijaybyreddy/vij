package com.cg.presantation;

import java.util.Scanner;

import com.cg.bean.RegistrationDetails;
import com.cg.service.FlatRegistrationService;
import com.cg.service.FlatRegistrationServiceImpl;

public class Client {
	private static Scanner scanner = new Scanner(System.in);
	private static FlatRegistrationService service = new FlatRegistrationServiceImpl();
	public static void main(String[] args) {
		int number,number1;
		RegistrationDetails a = new RegistrationDetails();
		
		do{
		System.out.println("0.exist\n 1.Registration Details \n 2.Display Flat Registration Details");
		int select = scanner.nextInt();
		switch(select)
		{
		case 1:
		do{
		System.out.println("Existing owner id's are :- [1,2,3]");
		System.out.println("Please enter your owner id from above list");
		number=scanner.nextInt();
		}
		while(number>=3);
		System.out.println("Select Flat type(1-1BHK,2-2BHK)");
		a.setFlatType(scanner.next());
		System.out.println("Enter flat Area in sq.ft:");
		a.setFlatAmount(scanner.nextDouble());
		System.out.println("Enter desired rent amount Rs : ");
		a.setRentAmount(scanner.nextDouble());
		System.out.println("Enter desired deposit amount rs:");
		a.setDepositAmount(scanner.nextDouble());
		a.setFlatRegistrationNumber(((int) ((Math.random() * ((9999 - 1000) + 1)) + 1000)));
		service.registerFlat(a);
		break;
		case 2:
			System.out.println(service.getAllOwnerIds());
		break;
		case 3:
			System.exit(0);
			break;
			default:
		}
		System.out.println("want to continue press 1");
		number1 = scanner.nextInt();
		
		}
		while(number1==1);

	}

}
