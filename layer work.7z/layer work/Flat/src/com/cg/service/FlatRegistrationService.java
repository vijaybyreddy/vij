package com.cg.service;

import java.util.ArrayList;

import com.cg.DTO.FlatRegistrationDTO;
import com.cg.bean.FlatOwner;
import com.cg.bean.RegistrationDetails;

public interface FlatRegistrationService {
	FlatRegistrationDTO registerFlat(RegistrationDetails a);
	ArrayList<FlatOwner> getAllOwnerIds();


}
