package com.cg.service;

import java.util.ArrayList;

import com.cg.DTO.FlatRegistrationDTO;
import com.cg.bean.FlatOwner;
import com.cg.bean.RegistrationDetails;
import com.cg.dao.FlatRegistrationDAO;
import com.cg.dao.FlatRegistrationDAOImpl;

public class FlatRegistrationServiceImpl implements FlatRegistrationService {
	private FlatRegistrationDAO dao = new FlatRegistrationDAOImpl() ;

	@Override
	public ArrayList<FlatOwner> getAllOwnerIds() {
		
		return dao.getAllOwnerIds();
	}

	@Override
	public FlatRegistrationDTO registerFlat(RegistrationDetails a) {
		dao.registerDTO(a);
		return null;
	}

}
