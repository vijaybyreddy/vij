package com.cg.bean;

public class GSTBean {
	 private int productId;
	   private String productName;
	   private int productWeight;
	   private int productDistance;
	public GSTBean(String name, int weight, int distance) {
		super();
		// TODO Auto-generated constructor stub
	}
	public GSTBean(int productId, String productName, int productWeight, int productDistance) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productWeight = productWeight;
		this.productDistance = productDistance;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductWeight() {
		return productWeight;
	}
	public void setProductWeight(int productWeight) {
		this.productWeight = productWeight;
	}
	public int getProductDistance() {
		return productDistance;
	}
	public void setProductDistance(int productDistance) {
		this.productDistance = productDistance;
	}
	@Override
	public String toString() {
		return "productId=" + productId + ", productName=" + productName + ", productWeight=" + productWeight
				+ ", productDistance=" + productDistance + "]";
	}

}
