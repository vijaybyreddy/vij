package com.cg.dao;

import java.util.Map;

import com.cg.bean.GSTBean;

public interface GSTDao {
	int addProduct(GSTBean product);

	double transportCalculation(int weight, int distance);

	double gstCalculation(double transportCharge);

	Map<Integer, GSTBean> getAllProducts();

}
