package com.cg.dao;

import java.util.Map;

import com.cg.bean.GSTBean;
import com.cg.util.ProductDetails;

public class GSTDaoImpl implements GSTDao {
	Map<Integer, GSTBean> map = ProductDetails.getMap();

	@Override
	public int addProduct(GSTBean product) {
		int generatedId = (int) (Math.random() * 1000);
		product.setProductId(generatedId);
		map.put(generatedId, product);
		return generatedId;
	}

	@Override
	public double transportCalculation(int weight, int distance) {
		double result = 2 * weight * distance;
		return result;
	}

	@Override
	public double gstCalculation(double transportCharge) {
		double result = 0.07 * transportCharge;
		return result;
	}

	@Override
	public Map<Integer, GSTBean> getAllProducts() {

		/*
		 * Map<Integer, GSTBean> map= new HashMap<Integer, GSTBean>();
		 * Collection<GSTBean> col=getAllProducts().values(); map.keySet(col);
		 */
		return ProductDetails.getMap();

	}

}
