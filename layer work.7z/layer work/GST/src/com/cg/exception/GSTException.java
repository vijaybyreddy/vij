package com.cg.exception;

public class GSTException extends Exception {
	public GSTException(String message) {
		super(message);
	}

}
