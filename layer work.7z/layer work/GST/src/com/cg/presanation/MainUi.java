package com.cg.presanation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.bean.GSTBean;
import com.cg.exception.GSTException;
import com.cg.service.GSTService;
import com.cg.service.GSTServiceImpl;

public class MainUi {

	public static void main(String[] args) {
		GSTService service=new GSTServiceImpl();
		Scanner scanner=null;
		int choice=0;
		String name="";
		int weight=0;
		int distance=0;
		String continueChoice="";
		boolean continuevalue=false;
		boolean choiceflag=false;
		boolean distanceflag=false;
		boolean weightflag=false;
		boolean nameflag=false;
		do {
			System.out.println("*****Welcome to GST******");
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.exit");
			try {
				scanner = new Scanner(System.in);
				System.out.println("enter choice");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					do {
						scanner = new Scanner(System.in);

						try {
							System.out.println("enter product name");

							name = scanner.nextLine();
							service.validateName(name);
							nameflag = true;
						} catch (GSTException e) {
							nameflag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameflag);

					do {
						scanner = new Scanner(System.in);

						try {
							System.out.println("enter product weight");

							weight = scanner.nextInt();
							service.validateWeight(weight);
							weightflag = true;
						} catch (GSTException e) {
							weightflag = false;
							System.err.println(e.getMessage());
						}
					} while (!weightflag);
					do {
						scanner = new Scanner(System.in);

						try {
							System.out.println("enter product distance");

							distance = scanner.nextInt();
							service.validateDistance(distance);
							distanceflag = true;
						} catch (GSTException e) {
							distanceflag = false;
							System.err.println(e.getMessage());
						}
					} while (!distanceflag);

					GSTBean product = new GSTBean(name, weight, distance);
					try {
						int generatedId = service.addProduct(product);
						System.out.println("product added with id is:" + generatedId);
						double transportCharge = service.transportCalculation(weight, distance);
						System.out.println("transport charge for the given product is :" + transportCharge);
						double Gst = service.gstCalculation(transportCharge);
						System.out.println("Gst for the product is:" + Gst);
					} catch (GSTException e) {
						// TODO Auto-generated catch block
						System.err.println(e.getMessage());
					}
					break;
				case 2:
					Map<Integer, GSTBean> gstdetails = service.getAllProducts();
					Iterator<Integer> iterator = gstdetails.keySet().iterator();
					while (iterator.hasNext()) {
						int id = iterator.next();
						GSTBean gstData = gstdetails.get(id);
						System.out.println(id + ": " + gstData);
					}
					break;
				case 3:
					System.out.println("Thank u");
					System.exit(0);
					break;
				default:
					System.err.println("enter 1 or 2 or 3 only");
					break;
				}
			} catch (InputMismatchException e) {
				// TODO Auto-generated catch block
				System.err.println("enter only digits");
			}
			
		} while (!choiceflag);
       scanner.close();
	}

}

