package com.cg.service;

import java.util.Map;

import com.cg.bean.GSTBean;
import com.cg.exception.GSTException;

public interface GSTService {
	boolean validateName(String name)throws GSTException;

	boolean validateWeight(int weight)throws GSTException;

	boolean validateDistance(int distance)throws GSTException;

	int addProduct(GSTBean product)throws GSTException;

	double transportCalculation(int weight, int distance);

	double gstCalculation(double transportCharge);

	Map<Integer, GSTBean> getAllProducts();
}
