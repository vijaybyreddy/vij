package com.cg.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bean.GSTBean;
import com.cg.dao.GSTDao;
import com.cg.dao.GSTDaoImpl;
import com.cg.exception.GSTException;

public class GSTServiceImpl implements GSTService {
	GSTDao dao=new GSTDaoImpl();

	@Override
	public boolean validateName(String name) throws GSTException{
		String regx="^[A-Z]{1}[a-zA-Z]{4,}$";
		boolean nameflag=false;
		if(!Pattern.matches(regx, name))
			throw new GSTException("first letter should be capital and followed by 4 characters");
		else
			nameflag=true;
		return nameflag;
	}

	@Override
	public boolean validateWeight(int weight) throws GSTException {
		boolean weightflag=false;
		if(weight <1)
			throw new GSTException("weight should be greater than 1");
		else
			weightflag=true;
		return weightflag;
	}

	@Override
	public boolean validateDistance(int distance) throws GSTException {
		if(distance<100)
			throw new GSTException("distance should be gretaer than 100");
		return false;
	}

	@Override
public int addProduct(GSTBean product) throws GSTException {
		
		return dao.addProduct(product);
	}
	@Override
	public double transportCalculation(int weight, int distance) {
		
		return dao.transportCalculation(weight,distance);
	}


	@Override
public double gstCalculation(double transportCharge) {
		
		return dao.gstCalculation(transportCharge);
	}

	@Override
public Map<Integer, GSTBean> getAllProducts() {
		
		return dao.getAllProducts();
	}
}
