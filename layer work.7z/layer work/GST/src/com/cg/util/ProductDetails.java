package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.GSTBean;

public class ProductDetails {
	static Map<Integer, GSTBean> map=new HashMap<>();
	 static {
		  map.put(121, new GSTBean(121,"rice",10,200));
		  map.put(222, new GSTBean(222,"rice",11,400));
		  map.put(333, new GSTBean(333,"rice",12,250));
		  map.put(444, new GSTBean(444,"rice",20,150));
	  }
	public static Map<Integer, GSTBean> getMap() {
		return map;
	}
	public static void setMap(Map<Integer, GSTBean> map) {
		ProductDetails.map = map;
	}
}
