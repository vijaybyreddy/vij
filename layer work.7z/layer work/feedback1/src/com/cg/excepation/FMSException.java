package com.cg.excepation;

public class FMSException extends Exception{

	public FMSException(String message) {
		super(message);
		
	}

}
