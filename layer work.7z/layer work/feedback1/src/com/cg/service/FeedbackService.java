package com.cg.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.dao.FeedbackDAO;
import com.cg.dao.IFeedbackDAO;
import com.cg.excepation.FMSException;

public class FeedbackService implements IFeedbackService {
	IFeedbackDAO dao=new FeedbackDAO();

	@Override
	public boolean isNameValid(String teacherName) throws FMSException{
		String regex="^[A-Z]{1}[a-zA-Z]{4,}$";
		boolean nameFlag=false;
		if(!Pattern.matches(regex, teacherName)) {
			throw new FMSException("First letter should be capital and followed by 4 characters");	
		}
		else
			nameFlag=true;
		return nameFlag;
	}

	@Override
	public boolean isRatingValid(int rating) throws FMSException {
		boolean ratingFlag=false;
		if(rating<1 || rating>5)
			throw new FMSException("Rating should be between 1 and 5");
		else
			ratingFlag=true;
		return ratingFlag;
	}

	@Override
	public boolean isTopicValid(String topic) throws FMSException {
		boolean topicFlag=false;
		if(topic.equals("English") || topic.equals("Maths"))
			topicFlag=true;
		else
		    throw new FMSException("Topic should be English or Maths only");
		return topicFlag;
	}

	@Override
	public Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic) {
		return dao.addFeedbackDetails(teacherName, rating, topic);
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		return dao.getFeedbackReport();
	}

}
