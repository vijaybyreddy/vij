package com.capgemini.bean;

public class Customer {
	private String name;
	private int mobilenumber;
	private int wallet;
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobilenumber=" + mobilenumber + ", wallet=" + wallet + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(int mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public int getWallet() {
		return wallet;
	}
	public void setWallet(int wallet) {
		this.wallet = wallet;
	}
	public Customer(String name, int mobilenumber, int wallet) {
		super();
		this.name = name;
		this.mobilenumber = mobilenumber;
		this.wallet = wallet;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

}
