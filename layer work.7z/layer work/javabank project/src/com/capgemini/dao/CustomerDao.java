package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bean.Customer;

public interface CustomerDao {
	int addCustomer(Customer customer);
	 Map<Integer, Customer> map = new HashMap<>();
	 Map<Integer, Customer> getAlldetails();

}
