package com.capgemini.dao;

import java.util.Map;

import com.capgemini.bean.Customer;

public class CutomerDaoImpl implements CustomerDao {

	@Override
	public int addCustomer(Customer customer) {
		Customer i=map.put(customer.getMobilenumber(), customer);
		return 0;
	}

	@Override
	public Map<Integer, Customer> getAlldetails() {
		// TODO Auto-generated method stub
		return map;
	}

}
