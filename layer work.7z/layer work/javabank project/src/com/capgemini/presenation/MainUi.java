package com.capgemini.presenation;

import java.util.Map;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.service.CustomerServiceImpl;

public class MainUi {
	static CustomerServiceImpl service = new CustomerServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	public static void addingcustomer() {
		System.out.println("enter the name");
		String name = scanner.next();
		System.out.println("enter the phone number");
		int mobilenumber = scanner.nextInt();
		System.out.println("enter the amount");
		int wallet = scanner.nextInt();
		 System.out.println("customer added successfully and your customer is:"+mobilenumber+name+wallet);

	}

	public static void main(String[] args) {
		String option = null;
		do {
			System.out.println("Welcome to my World");
			System.out.println("1.Add Customer\n2.Display Customer\n");
			int choice=scanner.nextInt();
			 switch(choice) {
	            case 0: 
	                System.out.println("Thank You");
	            System.exit(0);
	            case 1:{
	            	addingcustomer();
	                }break;
	            case 2: {
	            	Map<Integer, Customer>  customerdetails = service.getAlldetails();
	        	    System.out.println(customerdetails);
		}
			 }
			 System.out.println("Press y to continue");
		        option = scanner.next();
		
		       
		}
		 while(option.equalsIgnoreCase("Choice number"));
		scanner.close();
			 
	}
}
