package com.capgemini.service;

import java.util.Map;

import com.capgemini.bean.Customer;

public interface CustomerService {
	 public int addCustomer(Customer customer);
	    public Map<Integer, Customer> getAlldetails();

}
