package com.capgemini.service;

import java.util.Map;

import com.capgemini.bean.Customer;
import com.capgemini.dao.CustomerDao;
import com.capgemini.dao.CutomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {
	CustomerDao customerdao = new CutomerDaoImpl();
	@Override
	public int addCustomer(Customer customer) {
		
		return customerdao.addCustomer(customer);
	}

	@Override
	public Map<Integer, Customer> getAlldetails() {
		
		return customerdao.getAlldetails();
	}

}
