package com.capgemini.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
	
	static Map<String,String> productDetails;
	static Map<String, Integer> salesDetails;
	static Map<String, String> products=new HashMap<>();
	static {
		productDetails=new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");
		products.putAll(productDetails);
		salesDetails=new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);
	}
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		int updatedPrice=0;
		Iterator<String> productName=productDetails.keySet().iterator();
		while(productName.hasNext()) {
			String name1=productName.next();
			String category=productDetails.get(name1);
			if(category.equals(Category)) {
				Iterator<String> productName2=salesDetails.keySet().iterator();
				while(productName2.hasNext()) {
					updatedPrice=0;
					String name2=productName2.next();
					if(name1==name2) {
						int productPrice=salesDetails.get(name2);
						updatedPrice=productPrice+((hike*productPrice)/100);
						salesDetails.replace(name2, updatedPrice);
					}
				}
			}
		}
		return updatedPrice;
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		return salesDetails;
	}

	public static Map<String, String> getProducts() {
		return products;
	}

	public static void setProducts(Map<String, String> products) {
		ProductDAO.products = products;
	}

	
}
