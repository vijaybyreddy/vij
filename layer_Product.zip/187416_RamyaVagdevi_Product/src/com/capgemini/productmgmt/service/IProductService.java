package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductService {
	public int updateProducts(String Category,int hike) throws ProductException;
	public Map<String, Integer> getProductDetails() throws ProductException;
	public boolean validateCategory(String category) throws ProductException;
	public boolean validateHike(int hike) throws ProductException;
}
