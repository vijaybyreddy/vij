package com.capgemini.productmgmt.service;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.productmgmt.dao.IProductDAO;
import com.capgemini.productmgmt.dao.ProductDAO;
import com.capgemini.productmgmt.exception.ProductException;

public class ProductService implements IProductService{
	
	IProductDAO productDao=new ProductDAO();
	ProductDAO dao=new ProductDAO();
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		
		return productDao.updateProducts(Category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		return productDao.getProductDetails();
	}

	@Override
	public boolean validateCategory(String category) throws ProductException {
		boolean categoryFlag=false;
		Collection<String> productDetails=dao.getProducts().values();
		//System.out.println(productDetails);
		if(productDetails.contains(category)) {
			categoryFlag=true;
		}
		else {
			throw new ProductException("Enter category which already exists");
		}
		return categoryFlag;
	}

	@Override
	public boolean validateHike(int hike) throws ProductException {
		boolean hikeFlag=false;
		if(hike>0) {
			hikeFlag=true;
		}
		else {
			throw new ProductException("hike rate should not be less than 0");
		}
		return hikeFlag;
	}

}
