package com.capgemini.productmgmt.ui;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.productmgmt.exception.ProductException;
import com.capgemini.productmgmt.service.ProductService;

public class Client {
	static Scanner scanner=null;
	static ProductService service=new ProductService();
	static String continueChoice="";
	static boolean continueValue=false;
	public static void main(String[] args) {
		boolean choiceFlag=false;
		do {
			scanner=new Scanner(System.in);
			System.out.println("1) Update Product Price\n2) Display Product List\n3) Exit");
			int choice=scanner.nextInt();
			switch(choice) {
			case 1: updateProductPrice();
			break;
			case 2: DisplayProductList();
			break;
			case 3: System.exit(0);
			default: System.out.println("Enter 1/2/3");
			choiceFlag=false;
			break;
			}
			do {
				scanner=new Scanner(System.in);
				System.out.println("Do you want to continue [Yes/No]:");
				continueChoice = scanner.next();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.err.println("Thank You");
					choiceFlag=true;
					continueValue = true;
				} else {
					System.err.println("Enter yes or no only");
					continueValue = false;
				}
			} while (!continueValue);
		}while(!choiceFlag);
		
			
	}
	private static void DisplayProductList() {
		Map<String, Integer> salesDetails=new HashMap<>();
		try {
			salesDetails=service.getProductDetails();
			System.out.println(salesDetails);
		} catch (ProductException e) {
			System.out.println(e.getMessage());
		}
		
	}
	private static void updateProductPrice() {
		boolean categoryFlag=false;
		String productCategory="";
		/*loop will run until the user enters correct category which already exists*/
		do {
			scanner=new Scanner(System.in);
			System.out.println("Enter the Product Category: ");
			try {
				productCategory=scanner.nextLine();
				/*to check whether the category exists are not*/
				service.validateCategory(productCategory);
				categoryFlag=true;
			} catch (ProductException e) {
				categoryFlag=false;
				System.err.println(e.getMessage());
			}
		}while(!categoryFlag);
		boolean hikeFlag=false;
		int hikeRate=0;
		/*loop will run until the user enter number greater than zero*/
		do {
			scanner=new Scanner(System.in);
			System.out.println("Enter hike rate:");
			try {
				hikeRate=scanner.nextInt();
				service.validateHike(hikeRate);
				hikeFlag=true;
			}
			/*if the user enters string then it will catch the exception*/
			catch(InputMismatchException e) {
				hikeFlag=false;
				System.err.println("hike rate should be in digits only");
			} catch (ProductException e) {
				hikeFlag=false;
				System.err.println(e.getMessage());
			}
			
		}while(!hikeFlag);
		try {
			int productPrice=service.updateProducts(productCategory, hikeRate);
		} catch (ProductException e) {
			System.err.println(e.getMessage());
		}
	}

}
