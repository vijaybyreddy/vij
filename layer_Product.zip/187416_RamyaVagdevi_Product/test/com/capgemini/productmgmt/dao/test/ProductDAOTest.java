package com.capgemini.productmgmt.dao.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.productmgmt.dao.ProductDAO;
import com.capgemini.productmgmt.exception.ProductException;

class ProductDAOTest {
	ProductDAO productDao=null;
	@BeforeEach
	void setUp() throws Exception {
		productDao=new ProductDAO();
	}

	@AfterEach
	void tearDown() throws Exception {
		productDao=null;
	}

	@Test
	void testUpdateProducts() {
		try {
			assertNotNull(productDao.updateProducts("paste",10));
		} catch (ProductException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	void testGetProductDetails() {
		try {
			assertEquals(7, productDao.getProductDetails().size());
		} catch (ProductException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	void testGetProducts() {
		assertEquals(7, productDao.getProducts().size());
	}


}
