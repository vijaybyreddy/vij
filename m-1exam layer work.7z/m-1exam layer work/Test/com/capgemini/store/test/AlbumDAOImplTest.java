package com.capgemini.store.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.store.bean.Album;
import com.capgemini.store.dao.AlbumDao;
import com.capgemini.store.dao.AlbumDaoImpl;
import com.capgemini.store.exception.InvalidAlbumIdException;
 

class AlbumDAOImplTest {
static AlbumDao dao = null;
Album album;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao = new AlbumDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		/*album = new Album(7,"Comrade,"Susanth",150,3);
*/	}

	@AfterEach
	void tearDown() throws Exception {
		dao = null;
	}

	@Test
	void testPersist() {
		 assertNotEquals(7,dao.persist(album));
	}

	@Test
	void testFind() {
		try {
			assertEquals(album, dao.find(7));
		} catch (InvalidAlbumIdException e) {
			 
			e.printStackTrace();
		}
	}

}
