package com.capgemini.store.dao;

import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.InvalidAlbumIdException;

public interface AlbumDao {
	public int persist(Album album);//Method for adding album

	public Album find(int id) throws InvalidAlbumIdException;
//Method for finding album with given id
}
