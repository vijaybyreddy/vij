package com.capgemini.store.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.InvalidAlbumIdException;

public class AlbumDaoImpl implements AlbumDao {
	// taking a HashMap called albums
	static Map<Integer, Album> albums = new HashMap<>();
	static {
		albums.put(15, new Album(15, "Lemonade", "Beyonce", 250, 4.5));
		albums.put(16, new Album(16, "Lionking", "Thomas", 670, 2.8));
		albums.put(17, new Album(17, "Harrypotter", "Edward", 1200, 5));
		albums.put(18, new Album(18, "Lemonade", "Thomas", 120, 3.5));
	}

	public static Map<Integer, Album> getAlbums() {
		return albums;
	}

	public static void setAlbums(Map<Integer, Album> albums) {
		AlbumDaoImpl.albums = albums;
	}

	@Override
	public int persist(Album album) {
		// generating album id using Math.random()
		int generatedId = (int) (Math.random() * 100);
		albums.put(generatedId, album);
		return generatedId;
	}

	@Override
	public Album find(int id) throws InvalidAlbumIdException {
		// searching for the album with specified album id
		Album albumdata = null;
		Iterator<Integer> iterator = albums.keySet().iterator();
		while (iterator.hasNext()) {
			int key = iterator.next();
			if (key == id) {
				albumdata = albums.get(key);
				break;

			} else {
				throw new InvalidAlbumIdException("Oops! No album found with this id.\n");
			}
		}
		return albumdata;
	}
}
