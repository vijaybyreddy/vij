package com.capgemini.store.exception;

public class InvalidAlbumIdException extends Exception{
// creating exception class for handling exceptions
	public InvalidAlbumIdException() {
		super();
		 
	}

	public InvalidAlbumIdException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		 
	}

	public InvalidAlbumIdException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		 
	}

	public InvalidAlbumIdException(String message) {
		super(message);
		 
	}

	public InvalidAlbumIdException(Throwable arg0) {
		super(arg0);
		 
	}

}
