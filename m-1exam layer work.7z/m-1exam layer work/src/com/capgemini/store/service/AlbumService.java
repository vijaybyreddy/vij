package com.capgemini.store.service;

import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.InvalidAlbumIdException;

public interface AlbumService {
  public int saveAlbum(Album album);//method for adding the album
  public Album findById(int id) throws InvalidAlbumIdException;
  //method to find album by id
  public boolean validatename(String name) throws InvalidAlbumIdException;
  //validation for name
}
