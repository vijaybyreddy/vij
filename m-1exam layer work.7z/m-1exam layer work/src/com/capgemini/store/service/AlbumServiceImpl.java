package com.capgemini.store.service;

import java.util.regex.Pattern;

import com.capgemini.store.bean.Album;
import com.capgemini.store.dao.AlbumDao;
import com.capgemini.store.dao.AlbumDaoImpl;
import com.capgemini.store.exception.InvalidAlbumIdException;


public class AlbumServiceImpl implements AlbumService {
	AlbumDao albumdao = new AlbumDaoImpl();

	@Override
	public int saveAlbum(Album album) {
	return albumdao.persist(album);
	}
	@Override
	public Album findById(int id) throws InvalidAlbumIdException{
		return   albumdao.find(id);
		//returning the album
	}

	@Override
	public boolean validatename(String name) throws InvalidAlbumIdException {
//implementation for validating name
		boolean NameFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new InvalidAlbumIdException("first letter should be capital");
		} else {
			NameFlag = true;
		}
		return  NameFlag;
	}    
		
	}


