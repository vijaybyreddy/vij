package com.capgemini.store.ui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.InvalidAlbumIdException;
import com.capgemini.store.service.AlbumServiceImpl;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws InvalidAlbumIdException {
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println("*** Main Menu***");
			System.out.println("1.Add Music Album");
			System.out.println("2.Find Album by Id");
			System.out.println("3.exit");

			AlbumServiceImpl service = new AlbumServiceImpl();
			// creating service object in main method
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				// Taking input from the user
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean NameFlag = false;

					String title = "";
					switch (choice) {
					// implementation of case 1
					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Title:");
							title = scanner.nextLine();
							// validating the title
							try {
								service.validatename(title);
								NameFlag = true;
							} catch (InvalidAlbumIdException e) {
								NameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!NameFlag);

						String artist = "";
						boolean NameFlag1 = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Artist:");
							// validating artist name
							try {
								artist = scanner.nextLine();
								service.validatename(artist);
								NameFlag1 = true;
							} catch (InputMismatchException e) {
								NameFlag1 = false;
								System.err.println("Artist name should be in letters");
							} catch (InvalidAlbumIdException e) {
								NameFlag1 = false;
								System.err.println(e.getMessage());
							}
						} while (!NameFlag1);

						scanner = new Scanner(System.in);
						System.out.println("Enter Price:");
						double price = scanner.nextDouble();
						System.out.println("Enter rating:");
						double rating = scanner.nextDouble();

						Album album = new Album(0, title, artist, price, rating);
						
						int albumId = service.saveAlbum(album);
						//printing the generated album id by calling service method
						System.out.println("Album stored with the Id: " + albumId);

						break;

					case 2: {

						System.out.println("Enter album id to search:");
                   // taking album id to search from the user
						try {
							int albumid = scanner.nextInt();
							Album album1 = service.findById(albumid);
							System.out.println(album1);
						} catch (InvalidAlbumIdException e) {
							//handling the exception
							System.err.println(e.getMessage());

						}
					}
						break;

					case 3:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}

}
