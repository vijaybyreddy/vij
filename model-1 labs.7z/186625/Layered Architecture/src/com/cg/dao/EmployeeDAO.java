package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Employee;

 

public interface EmployeeDAO {
    public int addEmployee(Employee employee);
    Employee getEmployee(int employeeId);
     HashMap<Integer, Employee> getEmployee();

 

}
