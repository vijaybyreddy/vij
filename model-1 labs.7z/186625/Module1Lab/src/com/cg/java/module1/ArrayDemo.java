package com.cg.java.module1;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
