package com.cg.java.module1;
import java.util.*;
public class SumSquareNumberDifferencesNumbers {
	int sum1=0;
	int sum2=0;
	
	public static void main (String[] args) {
		int n;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a number:");
		n=scanner.nextInt();
		SumSquareNumberDifferencesNumbers d=new SumSquareNumberDifferencesNumbers();
		int sum11=d.sumofn2(n);
		int sum21=d.sumofn2(n);
		int result=sum11-sum21;
		System.out.println(result);
		
	}
	int sumofn1(int n) {
		for(int i=1;i<=n;i++) {
			sum1=sumofn1(0)+(i)^2;
		}
		System.out.println("sum1 is:"+ sum1);
		return sum1;
	}
	int sumofn2(int n) {
		int sum2 = 0;
		for(int i=1;i<n;i++) {
			sum2=sumofn2(0)+(i*i);
		}
		System.out.println("sum2 is :"+sum2);
		return sum2;
	}
 }
