package com.cg.lab10;

import java.util.Date;



class ThreadDemo implements Runnable {
   public void run() {
      
       while(true)
	   {
	        System.out.println("Timer task started at:"+new Date());
	   Thread.Sleep(1000);
	   }
   }
   
}


 

