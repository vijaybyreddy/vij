package com.cg.lab13;

import java.util.function.Predicate;

public class AcceptUsernamePassword {
	public static void main(String[] args) {
		Predicate<String> getUserName = (name) -> name == "VijayRamaRao Byreddy";

		Predicate<String> getPassword = (password) -> password == "7981361415";
		boolean result = getUserName.test("VijayRamaRao. Byreddy");
		System.out.println(result);

		boolean result2 = getPassword.test("7981361415");
		System.out.println(result2);
	}
}