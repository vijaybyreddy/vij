package com.cg.lab2;

public class CD extends Media2 {
	private String artist;
	private String genre;
	CD(int idNumber, String title, int numOfCopies) {
		super(numOfCopies, title, numOfCopies);
	
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}

}
