package com.cg.lab2;

public class NofBooks extends WrittenItem {
	public NofBooks(int identificationNumber, String title, int numOfCopies) {
		super(identificationNumber, title, numOfCopies);
	}
}
	
