package com.cg.lab4;

import java.util.Scanner;

class Cube {
	int digit, sum = 0, remender;

	public int cubeSum(int digit) {
		if (digit > 0) {
			while (digit != 0) {
				remender = digit % 10;
				sum = sum + remender * remender * remender;
				digit = digit / 10;
			}
		}
		return sum;
	}
}

public class SumOfCubes {

	public static void main(String[] args) {
		int digit;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		digit = scanner.nextInt();
		Cube cube = new Cube();
		int result = cube.cubeSum(digit);
		System.out.println(result);

	}

}
