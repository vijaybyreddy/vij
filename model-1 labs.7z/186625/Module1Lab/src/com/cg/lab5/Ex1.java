package com.cg.lab5;

import java.util.Scanner;

public class Ex1 {
	// letting user select any value between
	public static void main(String[] args) {

		System.out.println("Enter your choice between 1 to 3");
		System.out.println("\n1.Red" + "\n2.Yellow" + "\n3.Green");

		Scanner scanner = new Scanner(System.in);
		int input = scanner.nextInt();
		switch (input) {
		case 1:
			System.out.println("STOP");
			break;
		case 2:
			System.out.println("RAEDY");
			break;
		case 3:
			System.out.println("GO");
			break;

		default:
			System.out.println("Please enter a valid input");
			break;
		}
	}
}
