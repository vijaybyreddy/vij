package com.cg.lab5;

import java.util.Scanner;

{ 
    public MyException(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
} 

// A Class that uses above MyException 
public class Ex4 
{ 
    // Driver Program 
    public static void main(String args[]) 
    {
    	Scanner scanner = new Scanner(System.in);
    	//String input = scanner.nextLine();
//    	scanner.nextLine();
    	try
        {  
    		System.out.println("Enter First Name");
        	String first = scanner.nextLine();
        	if(first.equals(""))
        	{
            throw new Ex4Exception("Please enter a valid First Name"); 
        	}
        	System.out.println("Enter Last Name");
        	String last = scanner.nextLine();
            
        	
        	if(last.equals(""))
        	{
            throw new Ex4Exception("Please enter a valid Last Name"); 
        	}
        } 
        catch (Ex4Exception ex) 
        { 
           // System.out.println("Caught"); 
  
            // Print the message from MyException object 
            System.out.println(ex.getMessage()); 
        } 
    } 
} 
