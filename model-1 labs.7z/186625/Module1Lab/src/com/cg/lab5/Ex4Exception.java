package com.cg.lab5;

class Ex4Exception extends Exception
{ 
    public Ex4Exception(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
}