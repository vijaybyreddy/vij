package com.cg.lab5;

import java.util.Scanner;

public class Ex5 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
    	//String input = scanner.nextLine();
//    	scanner.nextLine();
    	try
        {  
    		System.out.println("Enter Your age");
    		int age = scanner.nextInt();
        	if(age < 15)
        	{
            throw new Ex4Exception("Please enter a valid Age"); 
        	}
        	
        } 
        catch (Ex4Exception ex) 
        { 
           // System.out.println("Caught"); 
  
            // Print the message from MyException object 
            System.out.println(ex.getMessage()); 
        }
	}
}

