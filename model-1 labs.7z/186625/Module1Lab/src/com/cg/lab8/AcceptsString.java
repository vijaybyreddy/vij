package com.cg.lab8;

import java.util.Scanner;



public class AcceptsString{
    public static void main(String args[]) {
        String str;
        int c=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string");
        str = sc.next();
        char[] ch = str.toCharArray();
        for(int i = 0;i<(str.length()-1);i++) {
            if(ch[i]<ch[i+1])
                c++;
        }
        if(c==(str.length()-1)) {
            System.out.println("Positive String");
        }
        else
            System.out.println("Not Positive String");
        sc.close();
            
    }
}
 