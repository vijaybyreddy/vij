package com.cg.lab8;

import java.io.*;
public class Displays {
    public static int lines=0;
    public static int Chars=0;
    public static int words=0;
    public static void wc(InputStreamReader isr)throws IOException{
        int c =0;
        boolean lastwhite=true;
        while((c=isr.read())!=-1) {
            Chars++;
            if(c=='\n')
                lines++;
            if(c=='\t'||c==' '||c=='\n')
                ++words;
            if(Chars!=0)
                ++Chars;
        }
    }
public static void main(String args[]) {
    FileReader fr;
    try {
        if(args.length==0)
        {
            wc(new InputStreamReader(System.in));
        }
        else
        {
            for(int i=0;i<args.length;i++)
            {
                fr=new FileReader(args[i]);
                wc(fr);
            }
        }
    }
    catch(IOException ie)
    {
        return;
    }
    System.out.println(lines+""+words+' '+Chars);
}
    

 


}
