package com.capgemini.labbook;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CrudOpeartionReading1 {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter authorId");
		int authorId=scan.nextInt();
		Author author=em.find(Author.class, authorId);
		
		System.out.println(author);
	}

}
