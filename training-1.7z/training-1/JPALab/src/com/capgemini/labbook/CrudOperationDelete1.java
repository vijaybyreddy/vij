package com.capgemini.labbook;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CrudOperationDelete1 {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter authorId");
		int authorId=scan.nextInt();
		em.getTransaction().begin();
		Author e=em.find(Author.class, authorId);
		em.remove(e);
		em.getTransaction().commit();
		System.out.println("employee with Id"+authorId+"removed");

	}

}
