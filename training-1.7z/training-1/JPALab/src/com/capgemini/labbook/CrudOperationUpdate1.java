package com.capgemini.labbook;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CrudOperationUpdate1 {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager au=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter authorId");
		int authorId=scan.nextInt();
		au.getTransaction().begin();
		Author e=au.find(Author.class, authorId);
		e.setPhoneNo(9949697377L);
		e.setFirstName("Teddy");
		au.getTransaction().commit();
		System.out.println(authorId+" is updated");

	}

}
