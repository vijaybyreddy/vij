package com.capgemini.labbook;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CrudOperations {

	public static void main(String[] args) {
		Author auth=new Author(007, "Park", "Jimin", "ho", 9618985436L);
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager au=factory.createEntityManager();
		au.getTransaction().begin();
		au.persist(auth);
		au.getTransaction().commit();
		System.out.println("Data Saved......");

	}

}
