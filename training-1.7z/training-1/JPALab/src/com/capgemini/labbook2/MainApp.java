package com.capgemini.labbook2;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class MainApp {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		AuthorDeep auth=new AuthorDeep();
		AuthorDeep auth1=new AuthorDeep();
		Book book=new Book();
		Book book1=new Book();
		Book book2=new Book();
		auth.setName("thuuu");
		auth1.setName("Deepika");
		book.setISBN(1213);
		book.setTitle("sachin");
		book.setPrice(10000);
		book.setAuth(auth);
		auth.getBook().add(book);
		book1.setISBN(1413);
		book1.setTitle("uma");
		book1.setPrice(5000);
		book1.setAuth(auth1);
		auth1.getBook().add(book1);
		book2.setISBN(12);
		book2.setTitle("Gandhi");
		book2.setPrice(300);
		book2.setAuth(auth1);
		auth1.getBook().add(book2);
		
		em.getTransaction().begin();
		em.persist(book);
		em.persist(auth);
		em.persist(book1);
		em.persist(book2);
		em.persist(auth1);
		em.getTransaction().commit();
		System.out.println("data entered");
		
		/*TypedQuery<Book> query=em.createQuery("from Book",Book.class);
		List<Book> employees=query.getResultList();
		for (Book employee : employees) {
			System.out.println(employee);
		}*/
		/*Scanner scan=new Scanner(System.in);
		System.out.println("enter name");
		String name=scan.nextLine();
		TypedQuery<AuthorDeep> query=em.createQuery("from AuthorDeep where name=:gen",AuthorDeep.class);
		query.setParameter("gen", name);
		List<AuthorDeep> employees=query.getResultList();
		for (AuthorDeep employee : employees) {
			System.out.println(employee);
		}*/
		
		TypedQuery<Book> query=em.createNamedQuery("getAllBooksByPrice", Book.class);
		
		List<Book> employees=query.getResultList();
		for (Book employee : employees) {
			System.out.println(employee);
		}
		
		/*Scanner scan=new Scanner(System.in);
		System.out.println("enter employee Id");
		int id=scan.nextInt();
		TypedQuery<AuthorDeep> query=em.createQuery(" from AuthorDeep where authorId=:eno",AuthorDeep.class);
		query.setParameter("eno", id);
		List<AuthorDeep> employees=query.getResultList();
		for (AuthorDeep employee : employees) {
			System.out.println(employee);
		}*/
		
	}

}
