package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankDAO {
	public long getBalance(long accountNo);

	public void addAccount(long accountNo, Account account);
	public long deposit(long accountNumber, long depositedAmount);
	public long withdrawl(long accountNo, long amountWithdrawl);
	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount);
	public Set<Transaction> printTransaction() throws BankException;
	boolean addTraansaction(Transaction transaction) throws BankException;

	
}
