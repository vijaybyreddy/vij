package com.cg.shapes;

import java.awt.Point;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//@Component
//@Service
public class Circle {

	//@Resource
	@Autowired
	private Point center;
	@Autowired
	MessageSource messageSource;
	public Point getCenter() {
		return center;
	}
	
	public void setCenter(Point center) {
		this.center = center;
	}
	public void draw() {
		String msg=messageSource.getMessage("greeting", null, "Default Greeting", null);
		System.out.println(msg);
		String draw=messageSource.getMessage("circle.drawing", null, "default", null);
		String points=messageSource.getMessage("circle.points", new Object[] {center.getX(),center.getY()}, "default", null);
		System.out.println(draw);
		System.out.println(points);
	}
//	@PostConstruct
//	public void myInit() {
//		System.out.println("My Init Method executed");
//	}
//	@PreDestroy
//	public void MyDestroy() {
//		System.out.println("My Destroy Method executed");
//	}
}
