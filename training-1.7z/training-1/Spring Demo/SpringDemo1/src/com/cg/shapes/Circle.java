package com.cg.shapes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;

public class Circle {
private Point center;
//@Required
@Autowired
//@Resource
public Point getCenter() {
	return center;
}

public void setCenter(Point center) {
	this.center = center;
}

public void draw() {
	System.out.println("Circle Drawn");
	System.out.println("Circle Points("+center.getX()+","+center.getY());
}

public void myInit() {
	System.out.println("My Intit method executed");
}


public void myDestroy() {
	System.out.println("My Destroy method executed");
}
}
