package com.capgemini;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
	public static void main(String[] args) {
		//add

		
		        Author auth=new Author(1008,"Sunil","gfnvk","gnkf",7600085236L);
		        Author auth1=new Author(1009,"King","BYREDDY","VIJAY",7981361415L);
		        EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		        EntityManager au=factory.createEntityManager();
	        au.getTransaction().begin();
		        au.persist(auth);
		        au.persist(auth1);
		        au.getTransaction().commit();
	        System.out.println("Data Saved......");
		
	}

}
