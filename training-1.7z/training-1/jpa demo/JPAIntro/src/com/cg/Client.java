package com.cg;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Greet greet = new Greet();
		greet.setMessage("Byreddy Vijay Rama Rao");
		em.persist(greet);
		em.getTransaction().commit();
		System.out.println("Added greeting to database.");
		
		
	}
}
