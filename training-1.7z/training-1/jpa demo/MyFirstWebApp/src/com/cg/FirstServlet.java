package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet(urlPatterns={"/FirstServlet"}
/*initParams= {
		@WebInitParam(name="userName",value="Byreddy"),
		@WebInitParam(name="city",value="palakol")
}*/
)
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		/*
		 * out.println("<h1>Welcome from First Servlet</h1>"); ServletConfig
		 * config=getServletConfig(); String name=config.getInitParameter("userName");
		 * String city=config.getInitParameter("city"); ServletContext
		 * context=getServletContext(); String comp=context.getInitParameter("company");
		 * out.println("<h3>Your company is"+comp);
		 * out.println("<h3>Welcome"+name+"Your are from"+city+"</h3>");
		 */
		out.println(request.getServerName());
		out.println("<br/>");
		out.println(request.getServerPort());
		out.println("<br/>");
		out.println(request.getRemoteHost());
		out.println("<br/>");
		out.println(request.getRemoteAddr());
		request.setAttribute("name", "vijay");
		String name=(String) request.getAttribute("name");
		out.println("<br/>");
		out.println("Name"+name);
		out.println(request.getRemoteUser());
		
		String query=request.getQueryString();
		out.println("<br/>");
		out.println(query);
		name=request.getParameter("name");
		int age=Integer.parseInt(request.getParameter("age"));
		out.println("<br/>");
		out.println(name+" "+age);
		out.println(request.getPathInfo());
		out.println(request.getRealPath("/SimpleServlet"));
	}
	

	@Override
	protected void doPost(HttpServletRequest requset, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(requset, response);
	}

	
}
