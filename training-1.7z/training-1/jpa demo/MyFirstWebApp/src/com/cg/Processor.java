package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Processor
 */
@WebServlet("/Processor")
public class Processor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	Enumeration<String> name=request.getParameterNames();
	while(name.hasMoreElements());
	String firstName=request.getParameter("fname");
	String lastName=request.getParameter("lname");
	String userId=request.getParameter("userId");
	String password=request.getParameter("password");
	String gender=request.getParameter("gender");
	String city=request.getParameter("city");
	String[]skills=request.getParameterValues("skills");
	StringBuilder sb=new StringBuilder();
	for(String skill : skills) {
		sb.append(skill+",");
	}
	String comments=request.getParameter("comments");
	out.println("<table borad=1>");
	out.print("<tr>");
	out.print("<td>First Name</td>");
	out.print("<td>"+firstName+"</td>");
	out.print("</tr>");
	out.print("<td>Last Name</td>");
	out.print("<td>"+lastName+"</td>");
	out.print("</tr>");
	out.print("<td>User Id</td>");
	out.print("<td>"+userId+"</td>");
	out.print("</tr>");
	out.print("<td>Password</td>");
	out.print("<td>"+password+"</td>");
	out.print("</tr>");
	out.print("<td>Gender</td>");
	out.print("<td>"+gender+"</td>");
	out.print("</tr>");
	out.print("<td>User Id</td>");
	out.print("<td>"+userId+"</td>");
	out.print("</tr>");
	out.print("<td>City</td>");
	out.print("<td>"+city+"</td>");
	out.print("</tr>");
	out.print("<td>Skills</td>");
	out.print("<td>"+sb.toString()+"</td>");
	out.print("</tr>");
	out.print("<td>Comments</td>");
	out.print("<td>"+comments+"</td>");
	out.print("</tr>");
	out.print("</table");
	out.println(request.getMethod());
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
