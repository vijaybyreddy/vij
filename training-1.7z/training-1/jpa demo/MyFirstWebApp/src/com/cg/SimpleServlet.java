package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ServletConfig config=getServletConfig();
		String name=config.getInitParameter("userName");
		String city=config.getInitParameter("city");
		ServletContext context=getServletContext();
		String comp=context.getInitParameter("company");
		out.println("<html>");
		out.println("<head><title>MyApp</title></head>");
		out.println("<boby>");
		out.println("<h1>Hello from Simple servlet</h1>");
		out.print("<h3>Welcome "+name+"Your from"+city+"</h3>");
		out.println("</body></html>");
		out.println("<h3>Your company is"+comp);
	}

}
