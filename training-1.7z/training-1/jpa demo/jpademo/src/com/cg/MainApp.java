package com.cg;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class MainApp {

	public static void main(String[] args) {

		
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");// to get data for data base
		EntityManager em = fac.createEntityManager();
		Vehicle vehicle=new Vehicle();
		vehicle.setVechicleName("Car");
		vehicle.setLicenseNumber("KA 01 2345");
		TwoWheeler tw=new TwoWheeler();
		tw.setVechicleName("Bike");
		tw.setLicenseNumber("KL-26-3282");
		tw.setStreeingHandle("Bike Steering Handle");
		FourWheeler fw=new FourWheeler();
		fw.setVechicleName("Porsche");
		fw.setLicenseNumber("KA-51 8878");
		fw.setSteeringWheel("car Steering Wheel");
		em.getTransaction().begin();
		em.persist(vehicle);
		em.getTransaction().begin();
		
		em.persist(fw);
		em.getTransaction().commit();
		System.out.println("Done");
		
			
	}
}
