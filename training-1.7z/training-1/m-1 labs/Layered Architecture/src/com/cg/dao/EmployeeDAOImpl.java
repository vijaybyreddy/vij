package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {
	HashMap<Integer, Employee> employeeList = new HashMap<Integer, Employee>();

	public int addEmployee(Employee employee) {
		employeeList.put(employee.getId(), employee);
		return employee.getId();
	}

	public HashMap<Integer, Employee> getEmployee() {
		return employeeList;
	}

	public Employee getEmployee(int employeeId) {
		
		return null;
	}

}
