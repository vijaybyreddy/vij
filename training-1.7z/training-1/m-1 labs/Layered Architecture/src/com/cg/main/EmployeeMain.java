package com.cg.main;

import java.util.Scanner;

import com.cg.bean.Employee;
import com.cg.service.EmployeeServiceImpl;




 

public class EmployeeMain {
    static EmployeeServiceImpl service = new EmployeeServiceImpl();
    static Scanner scanner = new Scanner(System.in);
    static String designation=null;
    static String insuranceScheme=null;

 

    static void AllEmployees() {
        System.out.println("Enter EmpId");
        int Id = scanner.nextInt();
        System.out.println("Enter EmpName");
        String name = scanner.next();
        System.out.println("Enter salary");
        double salary = scanner.nextDouble();
        if(salary>50000 && salary<20000) {
            designation="Manager";
            insuranceScheme="Scheme A";
        }
        else if(salary>=20000 && salary<40000) {
            designation="Programmer";
            insuranceScheme="Scheme B";
        }
        else if(salary>5000  && salary < 20000) {
            designation="System Associate";
            insuranceScheme="Scheme C";
        }
        else if(salary<5000) {
            designation="Clerk";
            insuranceScheme="No Scheme";
        }
        
        
        
        if (!service.isNameValid(name))
            try {
                throw new Exception("Invalid credentials");
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        else {
            Employee employee = new Employee(0, name, salary, designation, insuranceScheme);
            int employeeId = service.addEmployee(employee);
            System.out.println("Employee Registered Successfully and your id is:" + employeeId);
        }
    }

 

    public static void main(String[] args) {
        String option = null;
        do {
            System.out.println("1.EmployeeDetails\n2.ViewAll\n");
            int choice = scanner.nextInt();
            switch (choice) {
            case 0: {
                System.exit(0);
            }
            case 1: {
                AllEmployees();
            }
                break;

 

            case 2: {
                System.out.println("Enter employee Id to view");
                int empId = scanner.nextInt();
                Employee c = service.getEmployee(empId);
                System.out.println(c);
            }
                break;
            }
            System.out.println("press y to continue");
            option = scanner.next();
        } while (option.equalsIgnoreCase("y"));
    }

 

}
