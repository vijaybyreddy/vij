package com.cg.java.module1;

import java.util.Scanner;

public class ArrayDemo1 {

	int i;

	public static int[] reverseOfArray(int array[], int[] array2) {
		int reverse[]=new int[array.length];
		reverse = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			while (array[i] < array.length) {
				int remainder = array[i] % 10;
				reverse[i] = reverse[i] * 10 + remainder;
				array[i] = array[i] / 10;
			}

		}
		
		return array2;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("size");
		int size = scanner.nextInt();

		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
		}
		int output[] = new int[array.length];
		ArrayDemo1 array1 = new ArrayDemo1();
		for (int i = 0; i < array.length; i++) {
			System.out.println("reverse");
		}

	}

}
