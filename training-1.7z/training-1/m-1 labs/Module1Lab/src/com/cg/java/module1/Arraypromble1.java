package com.cg.java.module1;

public class Arraypromble1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
