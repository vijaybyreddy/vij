package com.cg.java.module1;
import java.util.*;
public class Check {

	public static void main(String[] args) {
		int number;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter number:");
		number=scanner.nextInt();                                                               
		Check n=new Check();
		n.inc(number);

	}
	boolean inc(int number) {
		boolean increasing =true;
		int number1,number2;
		number1=number%10;
		number=number/10;
		number2=number%10;
		while(number>0) {
			if(number2>number1) {
				System.out.println("false");
				break;
			}
			else
				System.out.println("increasing");
			break;
		}
		return true;
	}

}
