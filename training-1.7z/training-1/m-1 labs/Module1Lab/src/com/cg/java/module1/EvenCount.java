package com.cg.java.module1;

import java.util.Scanner;

class Even{
	int number,count=0,remainder;
			public int count(int number) {
				while(number>=0) {
					remainder=number%10;
					number=number/10;
					if(remainder%2==0)
					count++;
	
				}
				return count;
			}
}

public class EvenCount {

	public static void main(String[] args) {
		int number,count=0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter a number");
		number=scanner.nextInt();
		Even n1=new Even();
		int s1=n1.count(number);
		System.out.println(s1);
		
	}

}
