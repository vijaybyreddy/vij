package com.cg.java.module1;

import java.util.Scanner;

class Sum{
	int n,i,sum=0;
	public int sumNumber(int n) {
		for(i=0;i<=n;i++) {
			if(i%3==0 || i%5==0) {
				sum=sum+i;
			}
		}
		return sum;
	}
}
public class SumofNumbers {

	public static void main(String[] args) {
		int n,i,sum=0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("number:");
		n=scanner.nextInt();
		Sum sum1=new Sum();
		int s=sum1.sumNumber(n);
		System.out.println(s);
		

	}

}
