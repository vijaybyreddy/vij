package com.cg.lab10;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Thread {

	public static void main(String[] args) {

		try {
			FileReader filereader = new FileReader("C:\\Users\\vibyredd\\Desktop\\source.txt");
			BufferedReader bufferreader = new BufferedReader(filereader);
			FileWriter filewrite = new FileWriter("C:\\Users\\vibyredd\\Desktop\\target.txt", true);
			String string;

			while ((string= bufferreader.readLine()) != null) { 
				filewrite.write(string); 
				filewrite.flush();
			}
			bufferreader.close();
			filewrite.close();
			System.out.println(filereader);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	public static void Sleep(int i) {
		
		
	}
}