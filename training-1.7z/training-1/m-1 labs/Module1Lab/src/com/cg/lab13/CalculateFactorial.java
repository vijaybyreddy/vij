package com.cg.lab13;

import java.util.Scanner;

@FunctionalInterface
interface Factorial {
	public int factcalc(int value);
}

public class CalculateFactorial {
	public static void main(String args[]) {
		Factorial fact = (int number) -> {
			int number1 = 1;
			for (int i = 1; i <= number; i++)
				number1 =number1* i;
			return number1;
		};
		System.out.println("Enter your number");
		Scanner scanner = new Scanner(System.in);
		int value = scanner.nextInt();
		System.out.println(fact.factcalc(value));
		scanner.close();
	}
}