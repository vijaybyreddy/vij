package com.cg.lab13;

import java.util.function.Consumer;
interface Number
{
    public void getNumber();
}
 class MethodRefrenceDemoMain {
    int number;
        public int getNum() {
        return number;
    }
    public void setNum(int num) {
        this.number = number;
    }
}
class MethodRefrenceDemo
{
    public static void main(String[] args) {
        MethodRefrenceDemoMain mrd=new MethodRefrenceDemoMain();
        mrd.setNum(567);
        Consumer<MethodRefrenceDemoMain> c = MethodRefrenceDemoMain::getNum;
        //System.out.println(c.accept(mrd));
    }
}
 