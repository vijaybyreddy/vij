package com.cg.lab13;
@FunctionalInterface
interface StringSpace
{
    String getString(String name);
}
public class LambdaString {
    public static void main(String[] args) {
       
StringSpace stringspace=(v)->v.replace("", " ").trim();
String name=stringspace.getString("Vijay");
System.out.println(name);
    }
}