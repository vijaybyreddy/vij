package com.cg.lab2;

public abstract class Item {
	private int identificationNumber;
	private String title;
	private int numOfCopies;
	public Item(int identificationNumber, String title, int numOfCopies) {
		super();
		this.identificationNumber = identificationNumber;
		this.title = title;
		this.numOfCopies = numOfCopies;
	}
	

	public int getIdNumber() {
		return identificationNumber;
	}
	public void setIdentificationNumber(int identificationNumber) {
		this.identificationNumber = identificationNumber;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNumberOfCopies() {
		return numOfCopies;
	}
	public void setNumberOfCopies(int numOfCopies) {
		this.numOfCopies = numOfCopies;
	}
	@Override
	public String toString() {
		return "Item [idNum=" + identificationNumber + ", title=" + title + ", numOfCopies=" + numOfCopies + "]";
	}


	public boolean equals(Item i) {
		return this.equals(i);
	}
	
	public void print(){
		System.out.println();
	}
	
	public boolean checkIn() {
		return true;
	}
	
	public boolean checkOut() {
		return true;
	}

	public void addItem() {
		
	}

}