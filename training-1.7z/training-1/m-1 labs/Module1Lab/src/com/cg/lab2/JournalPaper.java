package com.cg.lab2;

public class JournalPaper extends WrittenItem {
	private int publishedYear;
	public JournalPaper(int identificationNumber,String title,int numOfCopies){
		super(identificationNumber,title,numOfCopies);
		
	}
	public int getPublishedYear() {
		return publishedYear;
	}
	public void setPublishedYear(int publishedYear) {
		this.publishedYear = publishedYear;
	}

}
