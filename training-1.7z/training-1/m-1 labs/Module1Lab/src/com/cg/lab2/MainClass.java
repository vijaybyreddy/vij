package com.cg.lab2;

public class MainClass {

	public static void main(String[] args) {
		

	}

}
