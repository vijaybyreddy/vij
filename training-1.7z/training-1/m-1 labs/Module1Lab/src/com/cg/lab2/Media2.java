package com.cg.lab2;

public class Media2 {

	public Media2(int identificationNumber, String title, int numOfCopies) {
		super();
	}

}
