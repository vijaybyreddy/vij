package com.cg.lab2;

public class Viedo extends Media2 {
	private String director;
	private String genre;
	private int yearPublished;
	Viedo(int identificationNumber, String title, int numOfCopies) {
		super(identificationNumber, title, numOfCopies);
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}
	

}
