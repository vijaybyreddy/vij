package com.cg.lab2;

public abstract class WrittenItem extends Item{
	private String author;
public WrittenItem(int identificationNumber, String title, int numOfCopies) {
		super(identificationNumber, title, numOfCopies);
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}

}