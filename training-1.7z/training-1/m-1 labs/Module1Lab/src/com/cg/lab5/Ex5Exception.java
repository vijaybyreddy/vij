package com.cg.lab5;

public class Ex5Exception extends Exception {
	public Ex5Exception(String s) {
		super(s);
	}
}

