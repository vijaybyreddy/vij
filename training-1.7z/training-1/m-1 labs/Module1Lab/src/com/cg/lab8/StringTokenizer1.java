package com.cg.lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

class ReadNumber {
	int number = 0, sum = 0;

	public int Input(String input) {
		StringTokenizer st = new StringTokenizer(input);
		int sum = 0;
		while (st.hasMoreTokens()) {
			number = Integer.parseInt(st.nextToken());
			System.out.print("Number is: " + number + " ");
			sum = sum + number;
		}
		return sum;
	}
}

public class StringTokenizer1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a line of numbers: ");
		String input = scanner.nextLine();
		ReadNumber number1 = new ReadNumber();
		int result = number1.Input(input);
		System.out.println("Sum is:" + result);

	}

}