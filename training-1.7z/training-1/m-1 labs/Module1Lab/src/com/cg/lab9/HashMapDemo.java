package com.cg.lab9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
public class HashMapDemo {
	public static <getValues> void main(String[] args) {
		LinkedHashMap<Integer,String> map=new LinkedHashMap<>();
		map.put(5,"vijay");
		map.put(3,"Ram");
		map.put(3,"html");
		map.put(4,"spring");
		System.out.println(map);
		ArrayList<String> arraylist=new ArrayList<>();
		 for(Entry<Integer, String> m:map.entrySet()) {
	            arraylist.add((String) m.getValue());
	            }
		  System.out.println(arraylist);
		   Collections.sort(arraylist);
		   System.out.println(arraylist);
	}
	

}
