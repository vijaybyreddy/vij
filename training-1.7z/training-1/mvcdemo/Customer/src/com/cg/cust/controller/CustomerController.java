package com.cg.cust.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.cust.dto.Customer;
import com.cg.cust.expcetion.CustomerExpection;
import com.cg.cust.service.CustomerService;

@Controller
//@RequestMapping("/greet")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@RequestMapping("/hello")
public String sayHello() {
	return "greet";
	
}
	@RequestMapping("/")
	public ModelAndView showAllCustomers() {
		try {
			List<Customer> customers= customerService.getAllCustomers();
			ModelAndView mv=new ModelAndView("index");
			mv.addObject("customers",customers);
			return mv;
		} catch (CustomerExpection e) {
		ModelAndView mv=new ModelAndView("error");
		mv.addObject("error",e);
		return mv;
		}
		
	}
	@RequestMapping("/delete")
	public ModelAndView deleteCustomer(@RequestParam int id) {
		try {
			List<Customer> customers=customerService.deletCustomer(id);
			ModelAndView mv=new ModelAndView("index");
			mv.addObject("customers",customers);
			return mv;
		} catch (CustomerExpection e) {
			ModelAndView mv=new ModelAndView("error");
			mv.addObject("error",e);
			return mv;
		}
		
	}
	@RequestMapping("/addCustomer")
	public String showAddForm(Model model) {
		model.addAttribute("customer",new Customer());
		return "add";
		
	}
	 @RequestMapping(value="/add",method = RequestMethod.POST)
	    public ModelAndView addCustomer(@Valid @ModelAttribute Customer customer,BindingResult result) {
	        if(result.hasErrors()) {
	            return new ModelAndView("add","customer",customer);
	           
	        }
	        try {
	            List<Customer> customers=customerService.addCustomer(customer);
	            ModelAndView mv=new ModelAndView("index");
	            mv.addObject("customers",customers);
	            return mv;
	        } catch (CustomerExpection e) {
	            ModelAndView mv=new ModelAndView("error");
	            mv.addObject("error",e);
	            return mv;
	        }
	       
	 }
	 @RequestMapping(value="/update",method = RequestMethod.POST)
	    public ModelAndView UpdateCustomer(@Valid @ModelAttribute Customer customer,BindingResult result) {
	        if(result.hasErrors()) {
	            return new ModelAndView("update","customer",customer);
	           
	        }
	        try {
	            List<Customer> customers=customerService.addCustomer(customer);
	            ModelAndView mv=new ModelAndView("index");
	            mv.addObject("customers",customers);
	            return mv;
	        } catch (CustomerExpection e) {
	            ModelAndView mv=new ModelAndView("error");
	            mv.addObject("error",e);
	            return mv;
	        }
	 }
	    @RequestMapping(value ="/updateCustomer",method =RequestMethod.POST)
	    public ModelAndView updateCustomer(@Valid@ModelAttribute Customer customer,BindingResult result) {
			try {
				if(result.hasErrors()) {
					 new ModelAndView("update","customer",customer);
				}
				List<Customer> customers=customerService.updateCustomer(customer);
				return new ModelAndView("update","customers",customers);
			} catch (CustomerExpection e) {
				 ModelAndView mv=new ModelAndView("error");
		            mv.addObject("error",e);
		            return mv; 
			}
			
	    	
	    }
}