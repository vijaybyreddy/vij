package com.cg.cust.expcetion;

public class CustomerExpection extends Exception{
	public CustomerExpection() {
		super();
	}
	public CustomerExpection(String message) {
		super(message);
	}

	}
