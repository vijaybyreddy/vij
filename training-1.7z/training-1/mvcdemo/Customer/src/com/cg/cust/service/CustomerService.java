package com.cg.cust.service;

import java.util.List;

import com.cg.cust.dto.Customer;
import com.cg.cust.expcetion.CustomerExpection;



public interface CustomerService {
List<Customer>getAllCustomers() throws CustomerExpection;
List<Customer>deletCustomer(int id) throws CustomerExpection;
List<Customer>addCustomer(Customer customer) throws CustomerExpection;
List<Customer> updateCustomer(Customer customer) throws CustomerExpection;
Customer getCustomerId(int id) throws CustomerExpection;
}
