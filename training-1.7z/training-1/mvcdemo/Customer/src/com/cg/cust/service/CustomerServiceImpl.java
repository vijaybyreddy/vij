package com.cg.cust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cust.dao.CustomerRespository;
import com.cg.cust.dto.Customer;
import com.cg.cust.expcetion.CustomerExpection;
@Service
public class CustomerServiceImpl implements CustomerService {
@Autowired
private CustomerRespository customerDao;
	@Override
	public List<Customer> getAllCustomers() throws CustomerExpection {
		
		try {
			return customerDao.findAll();
		} catch (Exception e) {
			throw new CustomerExpection(e.getMessage());
		}
	}
	@Override
	public List<Customer> deletCustomer(int id) throws CustomerExpection {
		// TODO Auto-generated method stub
		try {
			customerDao.delete(id);
			return getAllCustomers();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new CustomerExpection(e.getMessage());
		}
	}
	@Override
	public List<Customer> addCustomer(Customer customer) throws CustomerExpection {
		try {
			customerDao.save(customer);
			return getAllCustomers();
		} catch (Exception e) {
			throw new CustomerExpection(e.getMessage());
		}
	}
	@Override
	public List<Customer> updateCustomer(Customer customer) throws CustomerExpection {
		try {
			customerDao.save(customer);
			return getAllCustomers();
		} catch (Exception e) {
			throw new CustomerExpection(e.getMessage());
		}
	}
	@Override
	public Customer getCustomerId(int id) throws CustomerExpection {
		// TODO Auto-generated method stub
		return customerDao.findOne(id);
	}
}
