package com.cg.emp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
EmployeeDao employeedao;
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		  return employeedao.getAllEmployees();
	}
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.deleteEmployee(id);
	}
	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.addEmployee(employee);
	}
	@Override
	public Employee getEmployeeId(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.getEmployeeId(id);
	}
	@Override
	public List<Employee> updateEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao.updateEmployee(employee);
	}

}
