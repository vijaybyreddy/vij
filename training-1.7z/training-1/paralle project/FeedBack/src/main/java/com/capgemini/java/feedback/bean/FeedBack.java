package com.capgemini.java.feedback.bean;

public class FeedBack {
private String teacherName;
private int rating;
private String topic;
public FeedBack() {
	super();
	// TODO Auto-generated constructor stub
}
public FeedBack(String teacherName, int rating, String topic) {
	super();
	this.teacherName = teacherName;
	this.rating = rating;
	this.topic = topic;
}
public String getTeacherName() {
	return teacherName;
}
public void setTeacherName(String teacherName) {
	this.teacherName = teacherName;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
public String getTopic() {
	return topic;
}
public void setTopic(String topic) {
	this.topic = topic;
}
@Override
public String toString() {
	return "FeedBack [teacherName=" + teacherName + ", rating=" + rating + ", topic=" + topic + "]";
}

}
