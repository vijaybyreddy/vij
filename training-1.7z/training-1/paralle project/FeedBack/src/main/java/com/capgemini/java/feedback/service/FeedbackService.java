package com.capgemini.java.feedback.service;

import java.util.Map;

import com.capgemini.java.feedback.dao.FeedbackDAO;
import com.capgemini.java.feedback.dao.IFeedbackDAO;

public class FeedbackService implements IFeedbackService {
	
IFeedbackDAO dao=new FeedbackDAO();


	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		
		return dao.addFeedbackDetails(name, rating, subject);
	}

	public Map<String, Integer> getFeedbackReport() {
		
		return dao.getFeedbackReport();
	}

}
